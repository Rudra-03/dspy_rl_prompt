"""Simple task runner that executes instructions and returns results."""

import time
from typing import Dict, Any, List
import dspy

class SimpleTaskRunner:
    """Simple task runner for executing instructions."""
    
    def __init__(self):
        """Initialize the task runner."""
        self.predictor = dspy.Predict("instruction, task_input -> response")
        
    def run_task(self, instruction: str, task_input: str) -> Dict[str, Any]:
        """
        Run a single task with the given instruction.
        
        Args:
            instruction: The instruction to follow
            task_input: The input for the task
            
        Returns:
            Dictionary with response and metadata
        """
        start_time = time.time()
        
        try:
            # Execute the task using DSPy
            result = self.predictor(instruction=instruction, task_input=task_input)
            response = result.response
            
            execution_time = time.time() - start_time
            
            return {
                "response": response,
                "execution_time": execution_time,
                "success": True,
                "error": None
            }
            
        except Exception as e:
            execution_time = time.time() - start_time
            
            return {
                "response": "",
                "execution_time": execution_time,
                "success": False,
                "error": str(e)
            }
    
    def run_multiple_tasks(self, instruction: str, task_inputs: List[str]) -> List[Dict[str, Any]]:
        """
        Run multiple tasks with the same instruction.
        
        Args:
            instruction: The instruction to follow
            task_inputs: List of inputs for the tasks
            
        Returns:
            List of results for each task
        """
        results = []
        
        for task_input in task_inputs:
            result = self.run_task(instruction, task_input)
            results.append(result)
            
        return results
    
    def get_average_performance(self, results: List[Dict[str, Any]]) -> Dict[str, float]:
        """
        Calculate average performance metrics from results.
        
        Args:
            results: List of task results
            
        Returns:
            Dictionary with average metrics
        """
        if not results:
            return {"success_rate": 0.0, "avg_execution_time": 0.0}
        
        successful_results = [r for r in results if r["success"]]
        success_rate = len(successful_results) / len(results)
        
        if successful_results:
            avg_execution_time = sum(r["execution_time"] for r in successful_results) / len(successful_results)
        else:
            avg_execution_time = 0.0
        
        return {
            "success_rate": success_rate,
            "avg_execution_time": avg_execution_time,
            "total_tasks": len(results),
            "successful_tasks": len(successful_results)
        }