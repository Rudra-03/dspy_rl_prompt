Simple DSPy RL Optimizer
A beginner-friendly implementation of LLM instruction optimization using DSPy and reinforcement learning concepts. This system automatically improves instructions based on performance feedback.

🎯 What This Does
This system takes a basic instruction (like “Answer the question”) and automatically improves it based on how well it performs on test tasks. It uses reward signals to guide the optimization process.

Example:

Initial: “Answer the question”
Optimized: “Answer the question clearly and accurately, providing specific details when needed”
🚀 Quick Start
1. Install Dependencies
pip install -r requirements.txt
2. Set Up API Key
Get an OpenAI API key from https://platform.openai.com/api-keys

Then either:

Set environment variable: export OPENAI_API_KEY="your-key-here"
Or edit config.py and replace "your-openai-api-key-here" with your actual key
3. Run the System
python main.py
Choose from:

Single Task Example - Quick test with one task
Single Task Type Optimization - Optimize for one type of task (Q&A, summarization, etc.)
Comprehensive Demo - Run optimization on all task types
📁 File Structure
simple_dspy_optimizer/
├── main.py              # Main execution script
├── config.py            # Configuration settings
├── task_runner.py       # Executes tasks with instructions
├── reward_calculator.py # Calculates performance rewards
├── instructor.py        # Optimizes instructions based on feedback
├── examples.py          # Sample tasks for testing
├── requirements.txt     # Python dependencies
└── README.md           # This file
🔧 How It Works
Step 1: Run Initial Tasks
The system runs your initial instruction on test tasks and measures performance.

Step 2: Calculate Rewards
Performance is measured using task-specific reward functions:

Q&A: Accuracy of answers
Summarization: Length appropriateness and content quality
Creative Writing: Creativity indicators and structure
Math: Correctness of numerical answers
Step 3: Optimize Instruction
The LLM analyzes performance feedback and creates an improved instruction.

Step 4: Repeat
The process repeats for multiple rounds until performance is satisfactory.

📊 Example Output
🚀 OPTIMIZATION EXAMPLE: QA
============================================================
📋 Task: Answer factual questions accurately
🎯 Initial Instruction: 'Answer the following question.'
📊 Test Cases: 4

--- Round 1 ---
Average reward: 0.650
Success rate: 100.0%

--- Round 2 ---
Optimized instruction: 'Answer the following question clearly and accurately with specific details.'
Average reward: 0.825
Success rate: 100.0%

📈 OPTIMIZATION RESULTS:
   Rounds Completed: 2
   Initial Performance: 0.650
   Final Performance: 0.825
   Improvement: +0.175
🎮 Task Types
1. Question Answering (Q&A)
Purpose: Answer factual questions accurately
Reward: Based on answer correctness and completeness
Example: “What is the capital of France?” → “Paris”
2. Text Summarization
Purpose: Create concise summaries of longer texts
Reward: Based on length appropriateness and content preservation
Example: Long article → 2-3 sentence summary
3. Creative Writing
Purpose: Generate creative and engaging content
Reward: Based on creativity indicators, length, and structure
Example: “Write a story about a robot” → Creative narrative
4. Math Problems
Purpose: Solve mathematical problems with explanations
Reward: Based on answer correctness and reasoning shown
Example: “What is 15% of 80?” → “12”
⚙️ Configuration
Edit config.py to customize:

# Model settings
DEFAULT_MODEL = "gpt-3.5-turbo"  # Change model
MAX_OPTIMIZATION_ROUNDS = 3      # Number of optimization rounds
REWARD_THRESHOLD = 0.8          # Target performance level
🔍 Understanding the Code
SimpleTaskRunner (task_runner.py)
Executes instructions on tasks and returns results with timing information.

SimpleRewardCalculator (reward_calculator.py)
Calculates performance rewards based on task type and response quality.

SimpleInstructor (instructor.py)
Uses DSPy to optimize instructions based on performance feedback.

🎯 Adding Your Own Tasks
Create a new task set in examples.py:

def get_my_custom_examples():
    return {
        "task_type": "my_task",
        "description": "Description of what this task does",
        "initial_instruction": "Your starting instruction",
        "test_cases": [
            {
                "input": "Test input 1",
                "expected_output": "Expected output 1"
            },
            # Add more test cases...
        ]
    }
Then add a reward calculation method in reward_calculator.py:

def _calculate_my_task_reward(self, response: str, expected_output: str) -> Dict[str, Any]:
    # Your custom reward logic here
    return {"reward": score, "details": "explanation"}
🐛 Troubleshooting
“Please set your OPENAI_API_KEY”
Get an API key from OpenAI and set it in config.py or as an environment variable
“No successful responses”
Check your API key is valid
Try a simpler model like “gpt-3.5-turbo”
Check your internet connection
Low performance improvements
Try more optimization rounds in config.py
Use more diverse test cases
Check if your reward function is appropriate for the task
🎓 Learning More
This is a simplified version of instruction optimization. For more advanced features, check out:

DSPy Documentation
OpenAI API Documentation
Research papers on prompt optimization and reinforcement learning
📝 License
This project is open source and available under the MIT License.