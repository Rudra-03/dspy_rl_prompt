"""Simple instructor that optimizes instructions based on rewards."""

import dspy
from typing import Dict, Any, List

class SimpleInstructor:
    """Simple instructor that improves instructions based on performance feedback."""
    
    def __init__(self):
        """Initialize the instructor."""
        # Simple DSPy signature for instruction optimization
        self.optimizer = dspy.Predict(
            "current_instruction, performance_feedback, task_examples -> improved_instruction, reasoning"
        )
        
    def optimize_instruction(self, 
                           current_instruction: str,
                           performance_data: Dict[str, Any],
                           task_examples: List[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Optimize an instruction based on performance feedback.
        
        Args:
            current_instruction: The current instruction to improve
            performance_data: Performance metrics and feedback
            task_examples: Example tasks and their results (optional)
            
        Returns:
            Dictionary with improved instruction and reasoning
        """
        
        # Create performance feedback text
        feedback = self._create_performance_feedback(performance_data)
        
        # Create examples text
        examples_text = self._create_examples_text(task_examples) if task_examples else "No examples provided"
        
        try:
            # Use DSPy to optimize the instruction
            result = self.optimizer(
                current_instruction=current_instruction,
                performance_feedback=feedback,
                task_examples=examples_text
            )
            
            return {
                "improved_instruction": result.improved_instruction,
                "reasoning": result.reasoning,
                "success": True,
                "error": None
            }
            
        except Exception as e:
            return {
                "improved_instruction": current_instruction,  # Return original if optimization fails
                "reasoning": f"Optimization failed: {str(e)}",
                "success": False,
                "error": str(e)
            }
    
    def _create_performance_feedback(self, performance_data: Dict[str, Any]) -> str:
        """Create human-readable performance feedback."""
        
        feedback_parts = []
        
        # Overall performance
        avg_reward = performance_data.get("average_reward", 0.0)
        if avg_reward >= 0.8:
            feedback_parts.append("Performance is good overall.")
        elif avg_reward >= 0.6:
            feedback_parts.append("Performance is moderate, with room for improvement.")
        else:
            feedback_parts.append("Performance is poor and needs significant improvement.")
        
        # Success rate
        success_rate = performance_data.get("success_rate", 0.0)
        if success_rate < 1.0:
            feedback_parts.append(f"Success rate is {success_rate:.1%}, indicating some failures.")
        
        # Execution time
        avg_time = performance_data.get("avg_execution_time", 0.0)
        if avg_time > 10:
            feedback_parts.append("Responses are taking too long to generate.")
        
        # Specific issues from reward details
        reward_details = performance_data.get("reward_details", [])
        common_issues = self._identify_common_issues(reward_details)
        if common_issues:
            feedback_parts.append(f"Common issues: {', '.join(common_issues)}")
        
        return " ".join(feedback_parts)
    
    def _identify_common_issues(self, reward_details: List[str]) -> List[str]:
        """Identify common issues from reward details."""
        
        issues = []
        details_text = " ".join(reward_details).lower()
        
        if "too short" in details_text:
            issues.append("responses are too brief")
        if "too long" in details_text:
            issues.append("responses are too verbose")
        if "no overlap" in details_text or "low overlap" in details_text:
            issues.append("responses don't match expected content")
        if "no response" in details_text:
            issues.append("failing to generate responses")
        
        return issues
    
    def _create_examples_text(self, task_examples: List[Dict[str, Any]]) -> str:
        """Create examples text for the optimizer."""
        
        examples_parts = []
        
        for i, example in enumerate(task_examples[:3], 1):  # Limit to first 3 examples
            task_input = example.get("task_input", "")
            response = example.get("response", "")
            expected = example.get("expected_output", "")
            reward = example.get("reward", 0.0)
            
            example_text = f"Example {i}:\n"
            example_text += f"  Input: {task_input}\n"
            example_text += f"  Response: {response}\n"
            if expected:
                example_text += f"  Expected: {expected}\n"
            example_text += f"  Reward: {reward:.2f}\n"
            
            examples_parts.append(example_text)
        
        return "\n".join(examples_parts)
    
    def optimize_multiple_rounds(self,
                                initial_instruction: str,
                                task_runner,
                                reward_calculator,
                                task_type: str,
                                test_inputs: List[str],
                                expected_outputs: List[str] = None,
                                max_rounds: int = 3) -> Dict[str, Any]:
        """
        Perform multiple rounds of optimization.
        
        Args:
            initial_instruction: Starting instruction
            task_runner: Task runner instance
            reward_calculator: Reward calculator instance
            task_type: Type of task
            test_inputs: List of test inputs
            expected_outputs: List of expected outputs (optional)
            max_rounds: Maximum number of optimization rounds
            
        Returns:
            Dictionary with optimization history and final results
        """
        
        current_instruction = initial_instruction
        optimization_history = []
        
        print(f"Starting optimization with instruction: '{current_instruction}'")
        
        for round_num in range(max_rounds):
            print(f"\n--- Round {round_num + 1} ---")
            
            # Run tasks with current instruction
            results = task_runner.run_multiple_tasks(current_instruction, test_inputs)
            
            # Calculate rewards
            responses = [r["response"] for r in results if r["success"]]
            if not responses:
                print("No successful responses, stopping optimization.")
                break
            
            rewards = reward_calculator.calculate_batch_rewards(
                task_type, responses, expected_outputs, test_inputs
            )
            
            # Calculate performance metrics
            avg_reward = reward_calculator.get_average_reward(rewards)
            performance_metrics = task_runner.get_average_performance(results)
            
            performance_data = {
                "average_reward": avg_reward,
                "success_rate": performance_metrics["success_rate"],
                "avg_execution_time": performance_metrics["avg_execution_time"],
                "reward_details": [r["details"] for r in rewards]
            }
            
            print(f"Average reward: {avg_reward:.3f}")
            print(f"Success rate: {performance_metrics['success_rate']:.1%}")
            
            # Store round results
            round_data = {
                "round": round_num + 1,
                "instruction": current_instruction,
                "performance": performance_data,
                "individual_rewards": rewards
            }
            optimization_history.append(round_data)
            
            # Check if we should stop (good enough performance)
            if avg_reward >= 0.9:
                print("Excellent performance achieved, stopping optimization.")
                break
            
            # Optimize instruction for next round
            if round_num < max_rounds - 1:  # Don't optimize on the last round
                task_examples = []
                for i, (result, reward) in enumerate(zip(results, rewards)):
                    if result["success"]:
                        example = {
                            "task_input": test_inputs[i],
                            "response": result["response"],
                            "expected_output": expected_outputs[i] if expected_outputs else "",
                            "reward": reward["reward"]
                        }
                        task_examples.append(example)
                
                optimization_result = self.optimize_instruction(
                    current_instruction, performance_data, task_examples
                )
                
                if optimization_result["success"]:
                    new_instruction = optimization_result["improved_instruction"]
                    print(f"Optimized instruction: '{new_instruction}'")
                    print(f"Reasoning: {optimization_result['reasoning']}")
                    current_instruction = new_instruction
                else:
                    print(f"Optimization failed: {optimization_result['error']}")
                    break
        
        # Return final results
        final_performance = optimization_history[-1]["performance"] if optimization_history else {}
        
        return {
            "initial_instruction": initial_instruction,
            "final_instruction": current_instruction,
            "optimization_history": optimization_history,
            "final_performance": final_performance,
            "total_rounds": len(optimization_history),
            "improvement": (final_performance.get("average_reward", 0) - 
                          optimization_history[0]["performance"]["average_reward"] 
                          if optimization_history else 0)
        }