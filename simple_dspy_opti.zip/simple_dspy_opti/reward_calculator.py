"""Simple reward calculator for evaluating task performance."""

from typing import Dict, Any, List
import re

class SimpleRewardCalculator:
    """Simple reward calculator for different task types."""
    
    def calculate_reward(self, 
                        task_type: str,
                        response: str, 
                        expected_output: str = None,
                        task_input: str = None) -> Dict[str, Any]:
        """
        Calculate reward for a task response.
        
        Args:
            task_type: Type of task (qa, summarization, creative, math)
            response: The model's response
            expected_output: Expected output (if available)
            task_input: Original task input
            
        Returns:
            Dictionary with reward score and details
        """
        
        if task_type == "qa":
            return self._calculate_qa_reward(response, expected_output)
        elif task_type == "summarization":
            return self._calculate_summarization_reward(response, task_input)
        elif task_type == "creative":
            return self._calculate_creative_reward(response)
        elif task_type == "math":
            return self._calculate_math_reward(response, expected_output)
        else:
            return self._calculate_general_reward(response, expected_output)
    
    def _calculate_qa_reward(self, response: str, expected_output: str) -> Dict[str, Any]:
        """Calculate reward for question-answering tasks."""
        
        if not response or not expected_output:
            return {"reward": 0.0, "details": "Missing response or expected output"}
        
        response_lower = response.lower().strip()
        expected_lower = expected_output.lower().strip()
        
        # Exact match gets full reward
        if response_lower == expected_lower:
            return {"reward": 1.0, "details": "Exact match"}
        
        # Partial match based on key words
        expected_words = set(expected_lower.split())
        response_words = set(response_lower.split())
        
        if expected_words:
            overlap = len(expected_words.intersection(response_words))
            overlap_ratio = overlap / len(expected_words)
            
            if overlap_ratio >= 0.8:
                return {"reward": 0.9, "details": f"High overlap ({overlap_ratio:.2f})"}
            elif overlap_ratio >= 0.5:
                return {"reward": 0.7, "details": f"Medium overlap ({overlap_ratio:.2f})"}
            elif overlap_ratio >= 0.2:
                return {"reward": 0.4, "details": f"Low overlap ({overlap_ratio:.2f})"}
        
        return {"reward": 0.1, "details": "No significant overlap"}
    
    def _calculate_summarization_reward(self, response: str, original_text: str) -> Dict[str, Any]:
        """Calculate reward for summarization tasks."""
        
        if not response:
            return {"reward": 0.0, "details": "No response provided"}
        
        response_length = len(response.split())
        original_length = len(original_text.split()) if original_text else 100
        
        # Good summary should be 10-30% of original length
        compression_ratio = response_length / original_length
        
        reward = 0.5  # Base reward
        details = []
        
        # Length appropriateness
        if 0.1 <= compression_ratio <= 0.3:
            reward += 0.3
            details.append("Good length")
        elif compression_ratio < 0.05:
            reward -= 0.2
            details.append("Too short")
        elif compression_ratio > 0.5:
            reward -= 0.2
            details.append("Too long")
        
        # Basic quality checks
        if len(response.split('.')) >= 2:  # Multiple sentences
            reward += 0.1
            details.append("Multiple sentences")
        
        if any(word in response.lower() for word in ['therefore', 'however', 'moreover', 'furthermore']):
            reward += 0.1
            details.append("Good connectors")
        
        return {"reward": min(reward, 1.0), "details": "; ".join(details)}
    
    def _calculate_creative_reward(self, response: str) -> Dict[str, Any]:
        """Calculate reward for creative writing tasks."""
        
        if not response:
            return {"reward": 0.0, "details": "No response provided"}
        
        reward = 0.3  # Base reward for any response
        details = []
        
        # Length check
        word_count = len(response.split())
        if word_count >= 50:
            reward += 0.2
            details.append("Good length")
        elif word_count < 20:
            reward -= 0.1
            details.append("Too short")
        
        # Creativity indicators
        creative_words = ['imagine', 'suddenly', 'mysterious', 'adventure', 'magical', 'wonder']
        if any(word in response.lower() for word in creative_words):
            reward += 0.2
            details.append("Creative language")
        
        # Narrative structure
        if '"' in response:  # Has dialogue
            reward += 0.1
            details.append("Includes dialogue")
        
        if len(response.split('.')) >= 3:  # Multiple sentences
            reward += 0.2
            details.append("Good structure")
        
        return {"reward": min(reward, 1.0), "details": "; ".join(details)}
    
    def _calculate_math_reward(self, response: str, expected_output: str) -> Dict[str, Any]:
        """Calculate reward for math tasks."""
        
        if not response:
            return {"reward": 0.0, "details": "No response provided"}
        
        # Extract numbers from response and expected output
        response_numbers = re.findall(r'-?\d+\.?\d*', response)
        expected_numbers = re.findall(r'-?\d+\.?\d*', expected_output) if expected_output else []
        
        if expected_numbers and response_numbers:
            # Check if the final answer matches
            try:
                expected_answer = float(expected_numbers[-1])  # Last number is usually the answer
                response_answer = float(response_numbers[-1])
                
                if abs(expected_answer - response_answer) < 0.01:  # Allow small floating point errors
                    return {"reward": 1.0, "details": "Correct answer"}
                elif abs(expected_answer - response_answer) / max(abs(expected_answer), 1) < 0.1:  # Within 10%
                    return {"reward": 0.7, "details": "Close answer"}
            except (ValueError, IndexError):
                pass
        
        # Check for mathematical reasoning indicators
        math_keywords = ['solve', 'calculate', 'equation', 'formula', 'step', 'therefore']
        if any(word in response.lower() for word in math_keywords):
            return {"reward": 0.4, "details": "Shows mathematical reasoning"}
        
        return {"reward": 0.1, "details": "Minimal mathematical content"}
    
    def _calculate_general_reward(self, response: str, expected_output: str = None) -> Dict[str, Any]:
        """Calculate reward for general tasks."""
        
        if not response:
            return {"reward": 0.0, "details": "No response provided"}
        
        reward = 0.5  # Base reward
        details = []
        
        # Basic quality checks
        if len(response.split()) >= 10:
            reward += 0.2
            details.append("Adequate length")
        
        if response.endswith('.') or response.endswith('!') or response.endswith('?'):
            reward += 0.1
            details.append("Proper ending")
        
        # If expected output is provided, check similarity
        if expected_output:
            expected_words = set(expected_output.lower().split())
            response_words = set(response.lower().split())
            
            if expected_words:
                overlap = len(expected_words.intersection(response_words))
                overlap_ratio = overlap / len(expected_words)
                
                if overlap_ratio >= 0.3:
                    reward += 0.2
                    details.append(f"Good similarity ({overlap_ratio:.2f})")
        
        return {"reward": min(reward, 1.0), "details": "; ".join(details)}
    
    def calculate_batch_rewards(self, 
                               task_type: str,
                               responses: List[str],
                               expected_outputs: List[str] = None,
                               task_inputs: List[str] = None) -> List[Dict[str, Any]]:
        """
        Calculate rewards for a batch of responses.
        
        Args:
            task_type: Type of task
            responses: List of model responses
            expected_outputs: List of expected outputs (optional)
            task_inputs: List of task inputs (optional)
            
        Returns:
            List of reward dictionaries
        """
        rewards = []
        
        for i, response in enumerate(responses):
            expected = expected_outputs[i] if expected_outputs and i < len(expected_outputs) else None
            task_input = task_inputs[i] if task_inputs and i < len(task_inputs) else None
            
            reward = self.calculate_reward(task_type, response, expected, task_input)
            rewards.append(reward)
        
        return rewards
    
    def get_average_reward(self, rewards: List[Dict[str, Any]]) -> float:
        """Calculate average reward from a list of reward dictionaries."""
        
        if not rewards:
            return 0.0
        
        total_reward = sum(reward["reward"] for reward in rewards)
        return total_reward / len(rewards)