"""Simple configuration for DSPy RL Optimizer."""

import os
from typing import Dict, Any

# API Configuration
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "your-openai-api-key-here")
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "your-anthropic-api-key-here")

# Model Configuration
DEFAULT_MODEL = "gpt-3.5-turbo"  # Simple, fast, and cost-effective
BACKUP_MODEL = "gpt-4o-mini"     # Fallback option

# Optimization Settings
MAX_OPTIMIZATION_ROUNDS = 3      # Keep it simple with few rounds
REWARD_THRESHOLD = 0.8          # Target performance threshold
IMPROVEMENT_THRESHOLD = 0.1     # Minimum improvement to continue

# Task Settings
DEFAULT_TIMEOUT = 30            # Seconds to wait for responses
MAX_RESPONSE_LENGTH = 500       # Keep responses concise

def get_model_config() -> Dict[str, Any]:
    """Get simple model configuration."""
    return {
        "model": DEFAULT_MODEL,
        "temperature": 0.7,
        "max_tokens": MAX_RESPONSE_LENGTH,
        "timeout": DEFAULT_TIMEOUT
    }

def get_optimization_config() -> Dict[str, Any]:
    """Get optimization configuration."""
    return {
        "max_rounds": MAX_OPTIMIZATION_ROUNDS,
        "reward_threshold": REWARD_THRESHOLD,
        "improvement_threshold": IMPROVEMENT_THRESHOLD
    }