"""Simple DSPy RL Optimizer - Main execution script."""

import os
import dspy
from typing import Dict, Any

# Import our simple components
from config import get_model_config, get_optimization_config, OPENAI_API_KEY
from task_runner import SimpleTaskRunner
from reward_calculator import SimpleRewardCalculator
from instructor import SimpleInstructor
from examples import get_all_examples

def setup_dspy():
    """Set up DSPy with OpenAI."""
    if OPENAI_API_KEY == "your-openai-api-key-here":
        print("⚠️  Please set your OPENAI_API_KEY in config.py or as an environment variable")
        print("   You can get an API key from: https://platform.openai.com/api-keys")
        return False
    
    # Configure DSPy to use OpenAI
    model_config = get_model_config()
    lm = dspy.OpenAI(
        model=model_config["model"],
        api_key=OPENAI_API_KEY,
        temperature=model_config["temperature"],
        max_tokens=model_config["max_tokens"]
    )
    dspy.settings.configure(lm=lm)
    
    print(f"✅ DSPy configured with {model_config['model']}")
    return True

def run_single_task_example():
    """Run a simple single task example."""
    print("\n" + "="*50)
    print("🔬 SINGLE TASK EXAMPLE")
    print("="*50)
    
    # Initialize components
    task_runner = SimpleTaskRunner()
    reward_calculator = SimpleRewardCalculator()
    
    # Simple Q&A task
    instruction = "Answer the following question clearly and accurately."
    task_input = "What is the capital of France?"
    expected_output = "Paris"
    
    print(f"Instruction: {instruction}")
    print(f"Task Input: {task_input}")
    print(f"Expected Output: {expected_output}")
    
    # Run the task
    result = task_runner.run_task(instruction, task_input)
    
    if result["success"]:
        print(f"\n✅ Response: {result['response']}")
        print(f"⏱️  Execution Time: {result['execution_time']:.2f} seconds")
        
        # Calculate reward
        reward = reward_calculator.calculate_reward("qa", result["response"], expected_output)
        print(f"🎯 Reward: {reward['reward']:.2f}")
        print(f"📝 Details: {reward['details']}")
    else:
        print(f"❌ Task failed: {result['error']}")

def run_optimization_example(task_set: Dict[str, Any]):
    """Run optimization example for a specific task set."""
    print(f"\n" + "="*60)
    print(f"🚀 OPTIMIZATION EXAMPLE: {task_set['task_type'].upper()}")
    print("="*60)
    
    # Initialize components
    task_runner = SimpleTaskRunner()
    reward_calculator = SimpleRewardCalculator()
    instructor = SimpleInstructor()
    
    # Extract test data
    test_inputs = [case["input"] for case in task_set["test_cases"]]
    expected_outputs = [case["expected_output"] for case in task_set["test_cases"]]
    
    print(f"📋 Task: {task_set['description']}")
    print(f"🎯 Initial Instruction: '{task_set['initial_instruction']}'")
    print(f"📊 Test Cases: {len(test_inputs)}")
    
    # Run optimization
    optimization_config = get_optimization_config()
    results = instructor.optimize_multiple_rounds(
        initial_instruction=task_set["initial_instruction"],
        task_runner=task_runner,
        reward_calculator=reward_calculator,
        task_type=task_set["task_type"],
        test_inputs=test_inputs,
        expected_outputs=expected_outputs,
        max_rounds=optimization_config["max_rounds"]
    )
    
    # Display results
    print(f"\n📈 OPTIMIZATION RESULTS:")
    print(f"   Rounds Completed: {results['total_rounds']}")
    print(f"   Initial Performance: {results['optimization_history'][0]['performance']['average_reward']:.3f}")
    print(f"   Final Performance: {results['final_performance']['average_reward']:.3f}")
    print(f"   Improvement: +{results['improvement']:.3f}")
    print(f"   Final Instruction: '{results['final_instruction']}'")
    
    return results

def run_comprehensive_demo():
    """Run comprehensive demonstration with all task types."""
    print("\n" + "="*70)
    print("🎯 COMPREHENSIVE OPTIMIZATION DEMO")
    print("="*70)
    
    # Get all example task sets
    all_examples = get_all_examples()
    all_results = []
    
    for task_set in all_examples:
        try:
            results = run_optimization_example(task_set)
            all_results.append({
                "task_type": task_set["task_type"],
                "results": results
            })
        except Exception as e:
            print(f"❌ Error optimizing {task_set['task_type']}: {str(e)}")
    
    # Summary
    print(f"\n" + "="*70)
    print("📊 OVERALL SUMMARY")
    print("="*70)
    
    if all_results:
        total_improvement = sum(r["results"]["improvement"] for r in all_results)
        avg_improvement = total_improvement / len(all_results)
        
        print(f"Tasks Optimized: {len(all_results)}")
        print(f"Average Improvement: +{avg_improvement:.3f}")
        
        print(f"\nTask-by-Task Results:")
        for result in all_results:
            task_type = result["task_type"]
            improvement = result["results"]["improvement"]
            final_perf = result["results"]["final_performance"]["average_reward"]
            print(f"  {task_type.upper()}: {final_perf:.3f} (+{improvement:.3f})")
    
    return all_results

def main():
    """Main execution function."""
    print("🎯 Simple DSPy RL Optimizer")
    print("=" * 40)
    
    # Setup DSPy
    if not setup_dspy():
        return
    
    # Ask user what they want to run
    print("\nWhat would you like to run?")
    print("1. Single Task Example (quick test)")
    print("2. Single Task Type Optimization")
    print("3. Comprehensive Demo (all task types)")
    
    try:
        choice = input("\nEnter your choice (1-3): ").strip()
        
        if choice == "1":
            run_single_task_example()
        
        elif choice == "2":
            # Show available task types
            examples = get_all_examples()
            print("\nAvailable task types:")
            for i, example in enumerate(examples, 1):
                print(f"{i}. {example['task_type'].upper()} - {example['description']}")
            
            task_choice = input(f"\nChoose task type (1-{len(examples)}): ").strip()
            try:
                task_index = int(task_choice) - 1
                if 0 <= task_index < len(examples):
                    run_optimization_example(examples[task_index])
                else:
                    print("Invalid choice!")
            except ValueError:
                print("Please enter a valid number!")
        
        elif choice == "3":
            run_comprehensive_demo()
        
        else:
            print("Invalid choice! Please run the script again.")
    
    except KeyboardInterrupt:
        print("\n\n👋 Goodbye!")
    except Exception as e:
        print(f"\n❌ An error occurred: {str(e)}")
        print("Please check your configuration and try again.")

if __name__ == "__main__":
    main()