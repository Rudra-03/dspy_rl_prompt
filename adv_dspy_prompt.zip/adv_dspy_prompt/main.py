"""Streamlined DSPy RL Optimizer - Direct LLM-based instruction optimization without separate RL agent."""

import asyncio
import json
import time
from typing import Dict, List, Any, Optional
from dataclasses import dataclass

# Import DSPy and configuration
import dspy
from utils.dspy_config import initialize_dspy, config

# Import streamlined modules
from modules.streamlined_instructor_module import StreamlinedInstructorModule
from modules.responder_module import ResponderModule

# Import traditional optimizers for comparison
from optimizers.gepa_optimizer import GEPAOptimizer
from optimizers.miprov2_optimizer import Miprov2Optimizer

@dataclass
class StreamlinedOptimizationTask:
    """Streamlined optimization task with direct reward processing."""
    task_id: str
    task_description: str
    base_instruction: str
    evaluation_data: List[Dict]
    success_criteria: List[str]
    target_metrics: List[str]
    optimization_methods: List[str]

class StreamlinedDSPyPipeline:
    """Streamlined pipeline with direct LLM-based instruction optimization."""
    
    def __init__(self, 
                 instructor_model: str = "openai",
                 responder_model: str = "openai"):
        """
        Initialize the streamlined DSPy optimization pipeline.
        
        Args:
            instructor_model: Model to use for direct instruction optimization
            responder_model: Model to use for task execution
        """
        
        # Initialize DSPy configuration
        self.config = initialize_dspy(instructor_model, responder_model)
        
        # Initialize streamlined modules
        self.streamlined_instructor = StreamlinedInstructorModule()
        self.responder = ResponderModule()
        
        # Initialize traditional optimizers for comparison
        self.gepa_optimizer = GEPAOptimizer(
            population_size=8,
            mutation_rate=0.3,
            crossover_rate=0.7,
            max_generations=4
        )
        
        self.miprov2_optimizer = Miprov2Optimizer(
            max_steps=5,
            optimization_rounds=3
        )
        
        # Pipeline state
        self.optimization_history = []
        self.accumulated_traces = []
        
    async def run_streamlined_optimization_pipeline(self, task: StreamlinedOptimizationTask) -> Dict[str, Any]:
        """
        Run the streamlined optimization pipeline with direct LLM optimization.
        
        Args:
            task: StreamlinedOptimizationTask containing all necessary information
            
        Returns:
            Dictionary containing comprehensive optimization results
        """
        
        print(f"🚀 Starting Streamlined DSPy Optimization Pipeline")
        print(f"📋 Task: {task.task_description}")
        print(f"🧠 Direct LLM-based optimization (no separate RL agent)")
        
        start_time = time.time()
        results = {
            'task_id': task.task_id,
            'task_description': task.task_description,
            'base_instruction': task.base_instruction,
            'optimization_results': {},
            'performance_comparison': {},
            'best_instruction': task.base_instruction,
            'best_performance': 0.0,
            'execution_time': 0.0,
            'streamlined_insights': {}
        }
        
        # Evaluate base instruction performance
        print("\n📊 Evaluating base instruction...")
        base_performance = await self._evaluate_instruction_comprehensive(
            task.base_instruction, task
        )
        results['base_performance'] = base_performance
        print(f"Base performance: {base_performance.get('overall_score', 0):.3f}")
        
        # Generate initial traces and rewards from base instruction
        initial_traces = await self._generate_traces_from_evaluation(
            task.base_instruction, task, base_performance
        )
        
        initial_rewards = self._generate_reward_signals_from_performance(
            base_performance, task.base_instruction, task.task_description
        )
        
        # Accumulate traces for optimization
        self.accumulated_traces.extend(initial_traces)
        
        # Run each optimization method
        for method in task.optimization_methods:
            print(f"\n🔧 Running {method.upper()} optimization...")
            
            try:
                if method == 'direct_llm':
                    method_results = await self._run_direct_llm_optimization(
                        task, self.accumulated_traces, initial_rewards
                    )
                elif method == 'gepa':
                    method_results = await self._run_gepa_optimization(task)
                elif method == 'miprov2':
                    method_results = await self._run_miprov2_optimization(task)
                else:
                    print(f"❌ Unknown optimization method: {method}")
                    continue
                
                results['optimization_results'][method] = method_results
                
                # Check if this is the best result so far
                method_performance = method_results.get('performance', {}).get('overall_score', 0)
                if method_performance > results['best_performance']:
                    results['best_performance'] = method_performance
                    results['best_instruction'] = method_results.get('optimized_instruction', task.base_instruction)
                    results['best_method'] = method
                
                print(f"✅ {method.upper()} completed. Performance: {method_performance:.3f}")
                
                # Add optimization results to traces for subsequent methods
                if method == 'direct_llm':
                    optimization_traces = await self._generate_traces_from_optimization(
                        method_results, task
                    )
                    self.accumulated_traces.extend(optimization_traces)
                
            except Exception as e:
                print(f"❌ Error in {method} optimization: {e}")
                results['optimization_results'][method] = {'error': str(e)}
        
        # Generate performance comparison
        results['performance_comparison'] = self._generate_performance_comparison(results)
        
        # Extract streamlined optimization insights
        if 'direct_llm' in results['optimization_results']:
            results['streamlined_insights'] = self._extract_streamlined_insights(
                results['optimization_results']['direct_llm']
            )
        
        # Calculate total execution time
        results['execution_time'] = time.time() - start_time
        
        # Store in history
        self.optimization_history.append(results)
        
        print(f"\n🎉 Streamlined pipeline completed in {results['execution_time']:.2f}s")
        print(f"🏆 Best method: {results.get('best_method', 'None')}")
        print(f"📈 Best performance: {results['best_performance']:.3f}")
        
        # Display streamlined insights
        if results['streamlined_insights']:
            print(f"\n🧠 Direct LLM Optimization Insights:")
            insights = results['streamlined_insights']
            if 'strategy_used' in insights:
                print(f"   • Strategy: {insights['strategy_used']}")
            if 'key_improvements' in insights:
                for improvement in insights['key_improvements'][:2]:
                    print(f"   • {improvement}")
        
        return results
    
    async def _run_direct_llm_optimization(self,
                                         task: StreamlinedOptimizationTask,
                                         trace_history: List[Dict],
                                         reward_signals: List[Dict]) -> Dict[str, Any]:
        """Run direct LLM-based optimization without separate RL agent."""
        
        print("🧠 Activating Direct LLM Optimization (no RL agent)...")
        
        # Prepare optimization context
        optimization_context = {
            'task_complexity': self._assess_task_complexity(task),
            'performance_baseline': self._calculate_baseline_performance(reward_signals),
            'optimization_urgency': self._determine_optimization_urgency(reward_signals)
        }
        
        # Run direct optimization
        optimization_result = self.streamlined_instructor.optimize_instruction_directly(
            task_description=task.task_description,
            current_instruction=task.base_instruction,
            instruction_outcome_traces=trace_history,
            raw_reward_signals=reward_signals,
            optimization_context=optimization_context
        )
        
        # Evaluate optimized instruction
        optimized_instruction = optimization_result['optimized_instruction']
        final_performance = await self._evaluate_instruction_comprehensive(
            optimized_instruction, task
        )
        
        return {
            'optimized_instruction': optimized_instruction,
            'performance': final_performance,
            'optimization_details': optimization_result,
            'method': 'Direct LLM Optimization',
            'streamlined_metrics': {
                'strategy_selected': optimization_result['chosen_strategy'],
                'confidence_score': optimization_result['confidence_score'],
                'traces_processed': optimization_result['optimization_metadata']['traces_analyzed'],
                'patterns_discovered': optimization_result['optimization_metadata']['patterns_discovered'],
                'processing_approach': 'direct_reward_to_llm'
            }
        }
    
    async def _generate_traces_from_evaluation(self,
                                             instruction: str,
                                             task: StreamlinedOptimizationTask,
                                             performance: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate instruction-outcome traces from evaluation results."""
        
        traces = []
        
        for i, data_point in enumerate(task.evaluation_data):
            # Execute instruction on data point
            result = self.responder.forward(
                instruction=instruction,
                task_input=data_point.get('input', ''),
                tools_available=data_point.get('tools', {})
            )
            
            trace = {
                'instruction': instruction,
                'task_input': data_point.get('input', ''),
                'expected_output': data_point.get('expected_output', ''),
                'actual_output': result.get('response', ''),
                'performance_metrics': {
                    'accuracy': self._calculate_accuracy(
                        result.get('response', ''), 
                        data_point.get('expected_output', '')
                    ),
                    'confidence': result.get('confidence', 0.5),
                    'execution_time': result.get('execution_time', 0.0)
                },
                'execution_time': result.get('execution_time', 0.0),
                'timestamp': str(time.time()),
                'task_context': {
                    'task_id': task.task_id,
                    'task_description': task.task_description,
                    'evaluation_index': i
                }
            }
            traces.append(trace)
        
        return traces
    
    def _generate_reward_signals_from_performance(self,
                                                performance: Dict[str, Any],
                                                instruction: str,
                                                task_description: str) -> List[Dict[str, Any]]:
        """Generate reward signals from performance metrics."""
        
        rewards = []
        metrics = performance.get('metrics', {})
        
        for metric_name, metric_value in metrics.items():
            reward = {
                'reward_value': metric_value,
                'reward_type': metric_name,
                'task_context': task_description,
                'instruction_used': instruction,
                'performance_metrics': metrics,
                'timestamp': str(time.time())
            }
            rewards.append(reward)
        
        return rewards
    
    async def _generate_traces_from_optimization(self,
                                               optimization_result: Dict[str, Any],
                                               task: StreamlinedOptimizationTask) -> List[Dict[str, Any]]:
        """Generate traces from optimization results."""
        
        optimized_instruction = optimization_result.get('optimized_instruction', '')
        performance = optimization_result.get('performance', {})
        
        return await self._generate_traces_from_evaluation(
            optimized_instruction, task, performance
        )
    
    def _assess_task_complexity(self, task: StreamlinedOptimizationTask) -> str:
        """Assess the complexity of the optimization task."""
        
        complexity_factors = 0
        
        if len(task.evaluation_data) > 5:
            complexity_factors += 1
        if len(task.success_criteria) > 3:
            complexity_factors += 1
        if len(task.target_metrics) > 3:
            complexity_factors += 1
        if len(task.task_description.split()) > 20:
            complexity_factors += 1
        
        if complexity_factors >= 3:
            return 'high'
        elif complexity_factors >= 2:
            return 'medium'
        else:
            return 'low'
    
    def _calculate_baseline_performance(self, reward_signals: List[Dict]) -> float:
        """Calculate baseline performance from reward signals."""
        
        if not reward_signals:
            return 0.0
        
        reward_values = [r.get('reward_value', 0) for r in reward_signals]
        return sum(reward_values) / len(reward_values)
    
    def _determine_optimization_urgency(self, reward_signals: List[Dict]) -> str:
        """Determine optimization urgency based on performance."""
        
        baseline = self._calculate_baseline_performance(reward_signals)
        
        if baseline < 0.3:
            return 'critical'
        elif baseline < 0.6:
            return 'high'
        elif baseline < 0.8:
            return 'moderate'
        else:
            return 'low'
    
    def _calculate_accuracy(self, actual: str, expected: str) -> float:
        """Calculate accuracy between actual and expected outputs."""
        
        if not actual and not expected:
            return 1.0
        if not actual or not expected:
            return 0.0
        
        actual_lower = actual.lower().strip()
        expected_lower = expected.lower().strip()
        
        if actual_lower == expected_lower:
            return 1.0
        elif expected_lower in actual_lower or actual_lower in expected_lower:
            return 0.8
        else:
            # Use word overlap
            actual_words = set(actual_lower.split())
            expected_words = set(expected_lower.split())
            
            if not expected_words:
                return 0.0
            
            overlap = len(actual_words.intersection(expected_words))
            return overlap / len(expected_words)
    
    def _extract_streamlined_insights(self, optimization_result: Dict[str, Any]) -> Dict[str, Any]:
        """Extract insights from streamlined optimization results."""
        
        insights = {}
        
        # Extract optimization details
        opt_details = optimization_result.get('optimization_details', {})
        
        insights['strategy_used'] = opt_details.get('chosen_strategy', 'unknown')
        insights['confidence_score'] = opt_details.get('confidence_score', 0)
        insights['optimization_approach'] = 'Direct LLM Processing'
        
        # Extract key improvements
        expected_improvements = opt_details.get('expected_improvements', [])
        insights['key_improvements'] = expected_improvements[:3]
        
        # Extract reward insights
        reward_insights = opt_details.get('reward_insights', {})
        insights['performance_interpretation'] = reward_insights.get('performance_interpretation', '')
        
        # Extract self-evaluation
        self_eval = opt_details.get('self_evaluation', {})
        insights['quality_assessment'] = self_eval.get('quality_assessment', '')
        
        return insights
    
    async def _evaluate_instruction_comprehensive(self, 
                                                instruction: str, 
                                                task: StreamlinedOptimizationTask) -> Dict[str, Any]:
        """Comprehensively evaluate an instruction's performance."""
        
        results = []
        total_time = 0
        
        for data_point in task.evaluation_data:
            start_time = time.time()
            
            # Execute instruction
            result = self.responder.forward(
                instruction=instruction,
                task_input=data_point.get('input', ''),
                tools_available=data_point.get('tools', {})
            )
            
            execution_time = time.time() - start_time
            total_time += execution_time
            
            # Calculate performance
            performance = self._calculate_task_performance(result, data_point)
            performance['execution_time'] = execution_time
            
            results.append(performance)
        
        # Aggregate metrics
        if results:
            metrics = {
                'accuracy': sum(r.get('accuracy', 0) for r in results) / len(results),
                'efficiency': sum(r.get('efficiency', 0) for r in results) / len(results),
                'completeness': sum(r.get('completeness', 0) for r in results) / len(results),
                'confidence': sum(r.get('confidence', 0) for r in results) / len(results),
                'total_execution_time': total_time,
                'average_execution_time': total_time / len(results),
                'success_rate': sum(1 for r in results if r.get('accuracy', 0) > 0.7) / len(results)
            }
            
            # Calculate overall score
            metrics['overall_score'] = (
                metrics['accuracy'] * 0.4 +
                metrics['efficiency'] * 0.2 +
                metrics['completeness'] * 0.2 +
                metrics['confidence'] * 0.2
            )
        else:
            metrics = {
                'accuracy': 0.0, 'efficiency': 0.0, 'completeness': 0.0,
                'confidence': 0.0, 'overall_score': 0.0, 'success_rate': 0.0
            }
        
        return {
            'metrics': metrics,
            'individual_results': results,
            'evaluation_count': len(results)
        }
    
    def _calculate_task_performance(self, result: Dict, expected: Dict) -> Dict[str, float]:
        """Calculate performance metrics for a task result."""
        
        performance = {}
        
        # Accuracy
        if 'expected_output' in expected:
            expected_output = expected['expected_output'].lower()
            actual_output = result.get('response', '').lower()
            
            if expected_output in actual_output:
                performance['accuracy'] = 1.0
            else:
                # Use word overlap as similarity measure
                expected_words = set(expected_output.split())
                actual_words = set(actual_output.split())
                if expected_words:
                    overlap = len(expected_words.intersection(actual_words))
                    performance['accuracy'] = overlap / len(expected_words)
                else:
                    performance['accuracy'] = 0.0
        else:
            performance['accuracy'] = result.get('confidence', 0.5)
        
        # Efficiency (based on execution time and response length)
        execution_time = result.get('execution_time', 1.0)
        response_length = len(result.get('response', ''))
        
        # Normalize efficiency (lower time and appropriate length = higher efficiency)
        time_efficiency = 1.0 / (1.0 + execution_time)
        length_efficiency = min(1.0, response_length / 500) if response_length > 0 else 0.0
        performance['efficiency'] = (time_efficiency + length_efficiency) / 2
        
        # Completeness (based on response length and structure)
        if response_length > 50:
            performance['completeness'] = min(1.0, response_length / 200)
        else:
            performance['completeness'] = response_length / 50
        
        # Confidence (from model or heuristic)
        performance['confidence'] = result.get('confidence', 0.5)
        
        return performance
    
    async def _run_gepa_optimization(self, task: StreamlinedOptimizationTask) -> Dict[str, Any]:
        """Run GEPA optimization for comparison."""
        
        def task_function(instruction: str, data_point: Dict) -> Dict:
            result = self.responder.forward(
                instruction=instruction,
                task_input=data_point.get('input', ''),
                tools_available=data_point.get('tools', {})
            )
            performance = self._calculate_task_performance(result, data_point)
            return performance
        
        gepa_results = self.gepa_optimizer.optimize(
            base_prompt=task.base_instruction,
            task_function=task_function,
            evaluation_data=task.evaluation_data,
            target_metric="accuracy"
        )
        
        final_performance = await self._evaluate_instruction_comprehensive(
            gepa_results['best_prompt'], task
        )
        
        return {
            'optimized_instruction': gepa_results['best_prompt'],
            'performance': final_performance,
            'optimization_details': gepa_results,
            'method': 'GEPA'
        }
    
    async def _run_miprov2_optimization(self, task: StreamlinedOptimizationTask) -> Dict[str, Any]:
        """Run Miprov2 optimization for comparison."""
        
        def task_function(instruction: str, data_point: Dict) -> Dict:
            result = self.responder.forward(
                instruction=instruction,
                task_input=data_point.get('input', ''),
                tools_available=data_point.get('tools', {})
            )
            performance = self._calculate_task_performance(result, data_point)
            return performance
        
        miprov2_results = self.miprov2_optimizer.optimize(
            base_instruction=task.base_instruction,
            task_function=task_function,
            evaluation_data=task.evaluation_data,
            success_criteria=task.success_criteria,
            target_metrics=task.target_metrics
        )
        
        final_performance = await self._evaluate_instruction_comprehensive(
            miprov2_results['optimized_instruction'], task
        )
        
        return {
            'optimized_instruction': miprov2_results['optimized_instruction'],
            'performance': final_performance,
            'optimization_details': miprov2_results,
            'method': 'Miprov2'
        }
    
    def _generate_performance_comparison(self, results: Dict) -> Dict[str, Any]:
        """Generate performance comparison between optimization methods."""
        
        comparison = {
            'method_rankings': [],
            'metric_comparison': {},
            'approach_comparison': {}
        }
        
        base_performance = results.get('base_performance', {}).get('metrics', {})
        optimization_results = results.get('optimization_results', {})
        
        # Rank methods by overall performance
        method_performances = []
        for method, method_results in optimization_results.items():
            if 'error' not in method_results:
                performance = method_results.get('performance', {}).get('metrics', {})
                overall_score = performance.get('overall_score', 0)
                
                # Add approach classification
                approach = 'Direct LLM' if method == 'direct_llm' else 'Traditional Algorithm'
                
                method_performances.append((method, overall_score, performance, approach))
        
        method_performances.sort(key=lambda x: x[1], reverse=True)
        comparison['method_rankings'] = [
            {
                'method': method, 
                'score': score, 
                'rank': i+1,
                'approach': approach
            }
            for i, (method, score, _, approach) in enumerate(method_performances)
        ]
        
        # Compare metrics across methods
        metrics = ['accuracy', 'efficiency', 'completeness', 'confidence', 'overall_score']
        for metric in metrics:
            comparison['metric_comparison'][metric] = {
                'base': base_performance.get(metric, 0),
                'methods': {}
            }
            
            for method, _, performance, _ in method_performances:
                comparison['metric_comparison'][metric]['methods'][method] = performance.get(metric, 0)
        
        # Approach comparison
        for method, _, _, approach in method_performances:
            if method == 'direct_llm':
                comparison['approach_comparison'][method] = {
                    'approach': approach,
                    'intelligence_level': 'high',
                    'adaptability': 'high',
                    'complexity': 'low',
                    'requires_rl_agent': 'no'
                }
            else:
                comparison['approach_comparison'][method] = {
                    'approach': approach,
                    'intelligence_level': 'medium',
                    'adaptability': 'medium',
                    'complexity': 'high',
                    'requires_rl_agent': 'no'
                }
        
        return comparison

# Streamlined demo function
def create_streamlined_sample_tasks() -> List[StreamlinedOptimizationTask]:
    """Create streamlined sample tasks."""
    
    tasks = []
    
    # Streamlined QA Task
    qa_task = StreamlinedOptimizationTask(
        task_id="streamlined_qa_001",
        task_description="Answer factual questions accurately using direct LLM optimization",
        base_instruction="Answer the following question based on your knowledge.",
        evaluation_data=[
            {
                'input': 'What is the capital of France?',
                'expected_output': 'Paris',
                'tools': {}
            },
            {
                'input': 'Who wrote Romeo and Juliet?',
                'expected_output': 'William Shakespeare',
                'tools': {}
            },
            {
                'input': 'What is 15 * 23?',
                'expected_output': '345',
                'tools': {}
            }
        ],
        success_criteria=['Accuracy > 0.8', 'Response time < 2s', 'Concise answers'],
        target_metrics=['accuracy', 'efficiency', 'completeness'],
        optimization_methods=['direct_llm', 'gepa', 'miprov2']
    )
    tasks.append(qa_task)
    
    return tasks

async def run_streamlined_demo():
    """Run streamlined demonstration of the DSPy pipeline."""
    
    print("🎯 Streamlined DSPy Optimization Pipeline Demo")
    print("🧠 Direct LLM-based optimization (No separate RL agent)")
    print("=" * 60)
    
    # Initialize streamlined pipeline
    pipeline = StreamlinedDSPyPipeline()
    
    # Create streamlined sample tasks
    tasks = create_streamlined_sample_tasks()
    
    # Run optimization for each task
    all_results = []
    
    for task in tasks:
        print(f"\n{'='*70}")
        results = await pipeline.run_streamlined_optimization_pipeline(task)
        all_results.append(results)
        
        # Print streamlined summary
        print(f"\n📊 Streamlined Task {task.task_id} Summary:")
        print(f"Base Performance: {results['base_performance']['metrics']['overall_score']:.3f}")
        print(f"Best Performance: {results['best_performance']:.3f}")
        print(f"Best Method: {results.get('best_method', 'None')}")
        
        if 'direct_llm' in results['optimization_results']:
            direct_result = results['optimization_results']['direct_llm']
            streamlined_metrics = direct_result.get('streamlined_metrics', {})
            print(f"\n🧠 Direct LLM Optimization Metrics:")
            print(f"   Strategy Selected: {streamlined_metrics.get('strategy_selected', 'unknown')}")
            print(f"   Confidence Score: {streamlined_metrics.get('confidence_score', 0):.2f}")
            print(f"   Traces Processed: {streamlined_metrics.get('traces_processed', 0)}")
            print(f"   Processing Approach: {streamlined_metrics.get('processing_approach', 'unknown')}")
        
        improvement = ((results['best_performance'] - results['base_performance']['metrics']['overall_score']) / results['base_performance']['metrics']['overall_score'] * 100)
        print(f"Overall Improvement: {improvement:.1f}%")
    
    # Print streamlined statistics
    print(f"\n{'='*70}")
    print("🏆 Streamlined Pipeline Statistics")
    
    # Get streamlined statistics
    streamlined_stats = pipeline.streamlined_instructor.get_optimization_statistics()
    print(f"Total Optimizations: {streamlined_stats['total_optimizations']}")
    print(f"Processing Approach: {streamlined_stats['processing_approach']}")
    print(f"Task Types Handled: {', '.join(streamlined_stats['task_types_handled'])}")
    print(f"Traces Analyzed: {streamlined_stats['traces_analyzed']}")
    
    return all_results

if __name__ == "__main__":
    # Run the streamlined demo
    results = asyncio.run(run_streamlined_demo())
    
    # Save streamlined results
    with open('streamlined_optimization_results.json', 'w') as f:
        json.dump(results, f, indent=2, default=str)
    
    print("\n✅ Streamlined demo completed! Results saved to 'streamlined_optimization_results.json'")
    print("\n🧠 The system now uses Direct LLM Optimization:")
    print("   • No separate RL agent needed")
    print("   • LLM directly processes rewards and selects strategies")
    print("   • Simpler architecture with higher intelligence")
    print("   • Full LLM reasoning capabilities for optimization")