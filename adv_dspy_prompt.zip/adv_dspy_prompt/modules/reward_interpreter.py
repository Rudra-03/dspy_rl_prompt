"""Reward interpreter for converting reward signals into natural language feedback."""

import json
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
import numpy as np

@dataclass
class RewardSignal:
    """Represents a reward signal with context."""
    reward_value: float
    reward_type: str  # 'accuracy', 'efficiency', 'completeness', 'overall'
    task_context: str
    instruction_used: str
    performance_metrics: Dict[str, float]
    timestamp: str

@dataclass
class RewardFeedback:
    """Natural language feedback derived from reward signals."""
    feedback_text: str
    improvement_suggestions: List[str]
    strength_areas: List[str]
    weakness_areas: List[str]
    confidence_level: float

class RewardInterpreter:
    """Converts reward signals into natural language feedback for instruction optimization."""
    
    def __init__(self):
        self.reward_history: List[RewardSignal] = []
        self.feedback_templates = self._initialize_feedback_templates()
        self.improvement_strategies = self._initialize_improvement_strategies()
        
    def interpret_reward_signals(self, 
                                reward_signals: List[RewardSignal],
                                current_instruction: str,
                                optimization_context: Dict[str, Any]) -> RewardFeedback:
        """
        Convert reward signals into natural language feedback for instruction optimization.
        
        Args:
            reward_signals: List of recent reward signals
            current_instruction: Current instruction being optimized
            optimization_context: Additional context for optimization
            
        Returns:
            RewardFeedback with natural language guidance
        """
        
        if not reward_signals:
            return RewardFeedback(
                feedback_text="No reward signals available for analysis.",
                improvement_suggestions=["Gather performance data to enable optimization"],
                strength_areas=[],
                weakness_areas=[],
                confidence_level=0.0
            )
        
        # Store signals in history
        self.reward_history.extend(reward_signals)
        
        # Analyze reward patterns
        reward_analysis = self._analyze_reward_patterns(reward_signals)
        
        # Generate performance assessment
        performance_assessment = self._assess_performance(reward_signals, optimization_context)
        
        # Identify strengths and weaknesses
        strengths = self._identify_strengths(reward_signals, current_instruction)
        weaknesses = self._identify_weaknesses(reward_signals, current_instruction)
        
        # Generate improvement suggestions
        suggestions = self._generate_improvement_suggestions(
            reward_analysis, performance_assessment, weaknesses, optimization_context
        )
        
        # Create comprehensive feedback text
        feedback_text = self._create_feedback_narrative(
            reward_analysis, performance_assessment, strengths, weaknesses, suggestions
        )
        
        # Calculate confidence level
        confidence = self._calculate_feedback_confidence(reward_signals, optimization_context)
        
        return RewardFeedback(
            feedback_text=feedback_text,
            improvement_suggestions=suggestions,
            strength_areas=strengths,
            weakness_areas=weaknesses,
            confidence_level=confidence
        )
    
    def get_optimization_guidance(self, 
                                 target_metrics: List[str],
                                 current_performance: Dict[str, float],
                                 performance_history: List[Dict[str, float]]) -> Dict[str, Any]:
        """
        Provide specific optimization guidance based on performance targets.
        
        Args:
            target_metrics: Metrics to optimize for
            current_performance: Current performance scores
            performance_history: Historical performance data
            
        Returns:
            Dictionary with optimization guidance
        """
        
        guidance = {
            'priority_areas': [],
            'optimization_strategies': {},
            'expected_improvements': {},
            'risk_areas': []
        }
        
        # Analyze each target metric
        for metric in target_metrics:
            current_score = current_performance.get(metric, 0)
            
            # Determine priority based on current performance
            if current_score < 0.3:
                priority = 'critical'
            elif current_score < 0.6:
                priority = 'high'
            elif current_score < 0.8:
                priority = 'medium'
            else:
                priority = 'low'
            
            guidance['priority_areas'].append({
                'metric': metric,
                'current_score': current_score,
                'priority': priority,
                'target_improvement': self._calculate_target_improvement(metric, current_score)
            })
            
            # Get specific strategies for this metric
            guidance['optimization_strategies'][metric] = self._get_metric_strategies(
                metric, current_score, performance_history
            )
        
        # Identify potential risks
        guidance['risk_areas'] = self._identify_optimization_risks(
            current_performance, performance_history
        )
        
        return guidance
    
    def _analyze_reward_patterns(self, signals: List[RewardSignal]) -> Dict[str, Any]:
        """Analyze patterns in reward signals."""
        
        if not signals:
            return {}
        
        # Group signals by type
        signals_by_type = {}
        for signal in signals:
            if signal.reward_type not in signals_by_type:
                signals_by_type[signal.reward_type] = []
            signals_by_type[signal.reward_type].append(signal.reward_value)
        
        # Analyze each reward type
        analysis = {}
        for reward_type, values in signals_by_type.items():
            analysis[reward_type] = {
                'average': np.mean(values),
                'trend': self._calculate_trend(values),
                'stability': np.std(values),
                'best_score': max(values),
                'worst_score': min(values),
                'improvement_potential': 1.0 - max(values)  # How much room for improvement
            }
        
        # Overall pattern analysis
        all_values = [s.reward_value for s in signals]
        analysis['overall'] = {
            'performance_level': self._categorize_performance_level(np.mean(all_values)),
            'consistency': 'high' if np.std(all_values) < 0.1 else 'medium' if np.std(all_values) < 0.2 else 'low',
            'trajectory': self._calculate_trend(all_values)
        }
        
        return analysis
    
    def _assess_performance(self, 
                          signals: List[RewardSignal], 
                          context: Dict[str, Any]) -> Dict[str, Any]:
        """Assess overall performance based on reward signals and context."""
        
        # Calculate weighted performance score
        metric_weights = {'accuracy': 0.4, 'efficiency': 0.2, 'completeness': 0.2, 'confidence': 0.2}
        
        weighted_score = 0
        total_weight = 0
        
        for signal in signals:
            weight = metric_weights.get(signal.reward_type, 0.1)
            weighted_score += signal.reward_value * weight
            total_weight += weight
        
        overall_score = weighted_score / total_weight if total_weight > 0 else 0
        
        # Determine performance category
        if overall_score >= 0.8:
            category = 'excellent'
        elif overall_score >= 0.6:
            category = 'good'
        elif overall_score >= 0.4:
            category = 'fair'
        else:
            category = 'poor'
        
        # Analyze performance relative to context
        optimization_priority = context.get('optimization_priority', 'unknown')
        performance_trend = context.get('performance_trend', {})
        
        assessment = {
            'overall_score': overall_score,
            'category': category,
            'meets_expectations': self._check_expectations(overall_score, optimization_priority),
            'trend_alignment': self._assess_trend_alignment(performance_trend),
            'improvement_urgency': self._determine_improvement_urgency(overall_score, category)
        }
        
        return assessment
    
    def _identify_strengths(self, 
                          signals: List[RewardSignal], 
                          instruction: str) -> List[str]:
        """Identify strength areas based on reward signals."""
        
        strengths = []
        
        # Analyze high-performing metrics
        for signal in signals:
            if signal.reward_value >= 0.7:
                strength_desc = self._describe_metric_strength(signal.reward_type, signal.reward_value)
                if strength_desc not in strengths:
                    strengths.append(strength_desc)
        
        # Analyze instruction characteristics that correlate with good performance
        if any(s.reward_value >= 0.7 for s in signals):
            instruction_strengths = self._analyze_instruction_strengths(instruction, signals)
            strengths.extend(instruction_strengths)
        
        return strengths[:5]  # Top 5 strengths
    
    def _identify_weaknesses(self, 
                           signals: List[RewardSignal], 
                           instruction: str) -> List[str]:
        """Identify weakness areas based on reward signals."""
        
        weaknesses = []
        
        # Analyze low-performing metrics
        for signal in signals:
            if signal.reward_value < 0.5:
                weakness_desc = self._describe_metric_weakness(signal.reward_type, signal.reward_value)
                if weakness_desc not in weaknesses:
                    weaknesses.append(weakness_desc)
        
        # Analyze instruction characteristics that may cause poor performance
        if any(s.reward_value < 0.5 for s in signals):
            instruction_weaknesses = self._analyze_instruction_weaknesses(instruction, signals)
            weaknesses.extend(instruction_weaknesses)
        
        return weaknesses[:5]  # Top 5 weaknesses
    
    def _generate_improvement_suggestions(self, 
                                        reward_analysis: Dict[str, Any],
                                        performance_assessment: Dict[str, Any],
                                        weaknesses: List[str],
                                        context: Dict[str, Any]) -> List[str]:
        """Generate specific improvement suggestions."""
        
        suggestions = []
        
        # Performance-based suggestions
        overall_score = performance_assessment.get('overall_score', 0)
        category = performance_assessment.get('category', 'poor')
        
        if category == 'poor':
            suggestions.extend(self.improvement_strategies['major_overhaul'])
        elif category == 'fair':
            suggestions.extend(self.improvement_strategies['significant_improvement'])
        elif category == 'good':
            suggestions.extend(self.improvement_strategies['fine_tuning'])
        else:
            suggestions.extend(self.improvement_strategies['optimization'])
        
        # Metric-specific suggestions
        for metric, analysis in reward_analysis.items():
            if metric != 'overall' and analysis.get('average', 0) < 0.6:
                metric_suggestions = self._get_metric_improvement_suggestions(metric, analysis)
                suggestions.extend(metric_suggestions)
        
        # Context-based suggestions
        if 'similar_instructions' in context:
            similar_suggestions = self._get_similarity_based_suggestions(context['similar_instructions'])
            suggestions.extend(similar_suggestions)
        
        if 'successful_elements' in context:
            element_suggestions = self._get_element_based_suggestions(context['successful_elements'])
            suggestions.extend(element_suggestions)
        
        # Remove duplicates and limit
        unique_suggestions = list(dict.fromkeys(suggestions))
        return unique_suggestions[:8]  # Top 8 suggestions
    
    def _create_feedback_narrative(self, 
                                 reward_analysis: Dict[str, Any],
                                 performance_assessment: Dict[str, Any],
                                 strengths: List[str],
                                 weaknesses: List[str],
                                 suggestions: List[str]) -> str:
        """Create a comprehensive feedback narrative."""
        
        narrative_parts = []
        
        # Overall performance summary
        overall_score = performance_assessment.get('overall_score', 0)
        category = performance_assessment.get('category', 'unknown')
        
        narrative_parts.append(
            f"Current instruction performance is {category} with an overall score of {overall_score:.2f}."
        )
        
        # Performance trend
        overall_analysis = reward_analysis.get('overall', {})
        trajectory = overall_analysis.get('trajectory', 'stable')
        consistency = overall_analysis.get('consistency', 'medium')
        
        narrative_parts.append(
            f"Performance trajectory is {trajectory} with {consistency} consistency across evaluations."
        )
        
        # Strengths summary
        if strengths:
            narrative_parts.append(
                f"Key strengths include: {', '.join(strengths[:3])}."
            )
        
        # Weaknesses summary
        if weaknesses:
            narrative_parts.append(
                f"Primary areas for improvement: {', '.join(weaknesses[:3])}."
            )
        
        # Improvement focus
        if suggestions:
            narrative_parts.append(
                f"Recommended optimization focus: {suggestions[0]}."
            )
        
        return " ".join(narrative_parts)
    
    def _calculate_feedback_confidence(self, 
                                     signals: List[RewardSignal], 
                                     context: Dict[str, Any]) -> float:
        """Calculate confidence level for the feedback."""
        
        confidence = 0.5  # Base confidence
        
        # More signals = higher confidence
        if len(signals) >= 5:
            confidence += 0.2
        elif len(signals) >= 3:
            confidence += 0.1
        
        # Consistent signals = higher confidence
        signal_values = [s.reward_value for s in signals]
        if len(signal_values) > 1:
            consistency = 1 - np.std(signal_values)
            confidence += consistency * 0.2
        
        # Rich context = higher confidence
        if len(context) > 3:
            confidence += 0.1
        
        # Historical data = higher confidence
        if len(self.reward_history) > 10:
            confidence += 0.1
        
        return min(confidence, 1.0)
    
    def _calculate_trend(self, values: List[float]) -> str:
        """Calculate trend direction from a list of values."""
        
        if len(values) < 2:
            return 'stable'
        
        # Simple linear trend
        x = list(range(len(values)))
        slope = np.polyfit(x, values, 1)[0] if len(values) > 1 else 0
        
        if slope > 0.05:
            return 'improving'
        elif slope < -0.05:
            return 'declining'
        else:
            return 'stable'
    
    def _categorize_performance_level(self, score: float) -> str:
        """Categorize performance level based on score."""
        
        if score >= 0.8:
            return 'high'
        elif score >= 0.6:
            return 'medium'
        elif score >= 0.4:
            return 'low'
        else:
            return 'very_low'
    
    def _check_expectations(self, score: float, priority: str) -> bool:
        """Check if performance meets expectations based on optimization priority."""
        
        expectations = {
            'maintenance': 0.8,
            'fine_tuning': 0.6,
            'significant_improvement': 0.4,
            'major_overhaul': 0.2
        }
        
        expected_threshold = expectations.get(priority, 0.5)
        return score >= expected_threshold
    
    def _assess_trend_alignment(self, performance_trend: Dict[str, Any]) -> str:
        """Assess how current performance aligns with historical trends."""
        
        trend = performance_trend.get('trend', 'unknown')
        current_score = performance_trend.get('current_score', 0)
        average_score = performance_trend.get('average_score', 0)
        
        if trend == 'improving' and current_score > average_score:
            return 'positive_alignment'
        elif trend == 'declining' and current_score < average_score:
            return 'concerning_decline'
        elif trend == 'stable':
            return 'consistent_performance'
        else:
            return 'mixed_signals'
    
    def _determine_improvement_urgency(self, score: float, category: str) -> str:
        """Determine urgency of improvement needed."""
        
        if category == 'poor' or score < 0.3:
            return 'urgent'
        elif category == 'fair' or score < 0.6:
            return 'high'
        elif category == 'good' or score < 0.8:
            return 'moderate'
        else:
            return 'low'
    
    def _describe_metric_strength(self, metric: str, score: float) -> str:
        """Describe strength in a specific metric."""
        
        strength_descriptions = {
            'accuracy': f"High accuracy performance ({score:.2f}) - instructions produce correct results",
            'efficiency': f"Excellent efficiency ({score:.2f}) - instructions are processed quickly and effectively",
            'completeness': f"Strong completeness ({score:.2f}) - instructions generate comprehensive responses",
            'confidence': f"High confidence scores ({score:.2f}) - instructions produce reliable outputs"
        }
        
        return strength_descriptions.get(metric, f"Strong {metric} performance ({score:.2f})")
    
    def _describe_metric_weakness(self, metric: str, score: float) -> str:
        """Describe weakness in a specific metric."""
        
        weakness_descriptions = {
            'accuracy': f"Low accuracy ({score:.2f}) - instructions may be unclear or misleading",
            'efficiency': f"Poor efficiency ({score:.2f}) - instructions may be too complex or verbose",
            'completeness': f"Incomplete responses ({score:.2f}) - instructions may lack necessary detail",
            'confidence': f"Low confidence ({score:.2f}) - instructions produce uncertain outputs"
        }
        
        return weakness_descriptions.get(metric, f"Underperforming {metric} ({score:.2f})")
    
    def _analyze_instruction_strengths(self, 
                                     instruction: str, 
                                     signals: List[RewardSignal]) -> List[str]:
        """Analyze instruction characteristics that correlate with good performance."""
        
        strengths = []
        high_performing_signals = [s for s in signals if s.reward_value >= 0.7]
        
        if not high_performing_signals:
            return strengths
        
        instruction_lower = instruction.lower()
        
        # Check for structural strengths
        if any(word in instruction_lower for word in ['step', 'first', 'then', 'finally']):
            strengths.append("Clear step-by-step structure enhances performance")
        
        if any(word in instruction_lower for word in ['specific', 'detailed', 'precise']):
            strengths.append("Specificity and detail contribute to success")
        
        if any(word in instruction_lower for word in ['example', 'instance', 'case']):
            strengths.append("Use of examples improves instruction effectiveness")
        
        # Check length appropriateness
        word_count = len(instruction.split())
        if 15 <= word_count <= 50:
            strengths.append("Instruction length is well-balanced for comprehension")
        
        return strengths
    
    def _analyze_instruction_weaknesses(self, 
                                      instruction: str, 
                                      signals: List[RewardSignal]) -> List[str]:
        """Analyze instruction characteristics that may cause poor performance."""
        
        weaknesses = []
        low_performing_signals = [s for s in signals if s.reward_value < 0.5]
        
        if not low_performing_signals:
            return weaknesses
        
        instruction_lower = instruction.lower()
        word_count = len(instruction.split())
        
        # Check for structural weaknesses
        if word_count < 8:
            weaknesses.append("Instruction may be too brief and lack necessary detail")
        elif word_count > 100:
            weaknesses.append("Instruction may be too verbose and complex")
        
        if instruction.count('?') > 3:
            weaknesses.append("Excessive questioning may create confusion")
        
        if not any(word in instruction_lower for word in ['clear', 'specific', 'step', 'example']):
            weaknesses.append("Instruction lacks clarity and structure indicators")
        
        # Check for ambiguous language
        ambiguous_words = ['maybe', 'perhaps', 'might', 'could', 'possibly']
        if sum(1 for word in ambiguous_words if word in instruction_lower) > 2:
            weaknesses.append("Ambiguous language may reduce instruction effectiveness")
        
        return weaknesses
    
    def _get_metric_improvement_suggestions(self, 
                                          metric: str, 
                                          analysis: Dict[str, Any]) -> List[str]:
        """Get improvement suggestions for a specific metric."""
        
        suggestions_map = {
            'accuracy': [
                "Add specific examples to clarify expected outcomes",
                "Include verification steps to ensure correctness",
                "Use more precise and unambiguous language"
            ],
            'efficiency': [
                "Simplify instruction language and structure",
                "Remove unnecessary complexity and verbosity",
                "Focus on essential steps and requirements"
            ],
            'completeness': [
                "Add detailed requirements and expectations",
                "Include comprehensive coverage criteria",
                "Specify all necessary components for complete responses"
            ],
            'confidence': [
                "Use more definitive and authoritative language",
                "Provide clear guidance and decision criteria",
                "Reduce ambiguity and uncertainty in instructions"
            ]
        }
        
        base_suggestions = suggestions_map.get(metric, [])
        
        # Customize based on analysis
        avg_score = analysis.get('average', 0)
        if avg_score < 0.3:
            return base_suggestions  # Use all suggestions for very low scores
        else:
            return base_suggestions[:2]  # Use top suggestions for moderate scores
    
    def _get_similarity_based_suggestions(self, similar_instructions: List[Dict]) -> List[str]:
        """Generate suggestions based on similar high-performing instructions."""
        
        suggestions = []
        
        high_performing = [
            inst for inst in similar_instructions 
            if inst.get('performance', 0) > 0.7
        ]
        
        if high_performing:
            suggestions.append(
                f"Consider adapting patterns from high-performing similar instruction "
                f"(performance: {high_performing[0]['performance']:.2f})"
            )
        
        return suggestions
    
    def _get_element_based_suggestions(self, successful_elements: List[str]) -> List[str]:
        """Generate suggestions based on successful instruction elements."""
        
        suggestions = []
        
        for element in successful_elements[:3]:
            suggestions.append(f"Incorporate '{element}' which shows strong performance correlation")
        
        return suggestions
    
    def _calculate_target_improvement(self, metric: str, current_score: float) -> float:
        """Calculate realistic target improvement for a metric."""
        
        # Conservative improvement targets
        if current_score < 0.3:
            return min(0.6, current_score + 0.3)
        elif current_score < 0.6:
            return min(0.8, current_score + 0.2)
        else:
            return min(1.0, current_score + 0.1)
    
    def _get_metric_strategies(self, 
                             metric: str, 
                             current_score: float, 
                             history: List[Dict[str, float]]) -> List[str]:
        """Get optimization strategies for a specific metric."""
        
        strategies = {
            'accuracy': [
                "Enhance instruction clarity and specificity",
                "Add examples and concrete guidance",
                "Include verification and validation steps"
            ],
            'efficiency': [
                "Streamline instruction language",
                "Remove redundant information",
                "Optimize instruction structure"
            ],
            'completeness': [
                "Expand instruction scope and detail",
                "Add comprehensive requirements",
                "Include all necessary context"
            ],
            'confidence': [
                "Use more authoritative language",
                "Provide clear decision criteria",
                "Reduce ambiguous phrasing"
            ]
        }
        
        return strategies.get(metric, ["General optimization needed"])
    
    def _identify_optimization_risks(self, 
                                   current_performance: Dict[str, float],
                                   history: List[Dict[str, float]]) -> List[str]:
        """Identify potential risks in optimization."""
        
        risks = []
        
        # Check for performance volatility
        if len(history) >= 3:
            recent_scores = [h.get('overall_score', 0) for h in history[-3:]]
            if np.std(recent_scores) > 0.2:
                risks.append("High performance volatility - changes may have unpredictable effects")
        
        # Check for metric trade-offs
        accuracy = current_performance.get('accuracy', 0)
        efficiency = current_performance.get('efficiency', 0)
        
        if accuracy > 0.8 and efficiency < 0.4:
            risks.append("Risk of accuracy-efficiency trade-off during optimization")
        
        # Check for over-optimization
        if current_performance.get('overall_score', 0) > 0.9:
            risks.append("Risk of over-optimization - small changes may reduce performance")
        
        return risks
    
    def _initialize_feedback_templates(self) -> Dict[str, List[str]]:
        """Initialize feedback templates for different scenarios."""
        
        return {
            'excellent_performance': [
                "Outstanding instruction performance across all metrics.",
                "Instruction demonstrates exceptional effectiveness.",
                "Near-optimal performance achieved with current approach."
            ],
            'good_performance': [
                "Strong instruction performance with room for refinement.",
                "Solid foundation with opportunities for enhancement.",
                "Good results that can be further optimized."
            ],
            'fair_performance': [
                "Moderate instruction effectiveness requiring improvement.",
                "Acceptable baseline with significant optimization potential.",
                "Performance indicates need for strategic enhancements."
            ],
            'poor_performance': [
                "Instruction performance requires substantial improvement.",
                "Current approach needs fundamental restructuring.",
                "Major optimization needed to achieve target performance."
            ]
        }
    
    def _initialize_improvement_strategies(self) -> Dict[str, List[str]]:
        """Initialize improvement strategies for different optimization levels."""
        
        return {
            'major_overhaul': [
                "Completely restructure instruction approach and language",
                "Implement step-by-step methodology with clear guidance",
                "Add comprehensive examples and detailed requirements",
                "Simplify complex concepts and improve clarity"
            ],
            'significant_improvement': [
                "Enhance instruction clarity and specificity",
                "Add structured approach with logical flow",
                "Include relevant examples and context",
                "Improve language precision and reduce ambiguity"
            ],
            'fine_tuning': [
                "Refine instruction language for better precision",
                "Optimize instruction length and complexity",
                "Enhance specific weak areas while maintaining strengths",
                "Add minor clarifications and improvements"
            ],
            'optimization': [
                "Make subtle improvements to maintain high performance",
                "Optimize for consistency and reliability",
                "Fine-tune language for maximum effectiveness",
                "Preserve successful elements while enhancing details"
            ]
        }