"""Enhanced Instructor Module with intelligent trace-based optimization."""

import dspy
from typing import Dict, List, Optional, Any, Tuple
import json
import numpy as np
from dataclasses import dataclass
from collections import defaultdict
import time

from modules.trace_analyzer import TraceAnalyzer, InstructionTrace
from modules.reward_interpreter import RewardInterpreter, RewardSignal, RewardFeedback
from signatures.instruction_signatures import InstructionGeneration, InstructionEvaluation

@dataclass
class OptimizationSession:
    """Represents an optimization session with full context."""
    session_id: str
    task_description: str
    base_instruction: str
    optimization_history: List[Dict[str, Any]]
    current_performance: Dict[str, float]
    target_metrics: List[str]
    success_criteria: List[str]

class EnhancedInstructorModule(dspy.Module):
    """
    Enhanced Instructor Module that acts as an intelligent prompt optimizer.
    Uses instruction-outcome traces and reward signals for optimization.
    """
    
    def __init__(self, model_config: Optional[Dict] = None):
        super().__init__()
        
        # Initialize DSPy predictors with enhanced signatures
        self.instruction_generator = dspy.Predict(InstructionGeneration)
        self.instruction_evaluator = dspy.Predict(InstructionEvaluation)
        self.trace_optimizer = dspy.Predict(self._create_trace_optimization_signature())
        self.reward_analyzer = dspy.Predict(self._create_reward_analysis_signature())
        self.self_reflector = dspy.Predict(self._create_self_reflection_signature())
        
        # Initialize analysis components
        self.trace_analyzer = TraceAnalyzer(max_trace_history=500)
        self.reward_interpreter = RewardInterpreter()
        
        # Optimization state
        self.optimization_sessions: Dict[str, OptimizationSession] = {}
        self.meta_learning_memory = defaultdict(list)
        self.successful_patterns = []
        
        # Configuration
        self.config = model_config or {}
        self.optimization_strategy = 'adaptive'  # 'conservative', 'aggressive', 'adaptive'
        self.learning_rate = 0.1
        
    def optimize_instruction(self, 
                           task_description: str,
                           current_instruction: str,
                           instruction_outcome_traces: List[Dict[str, Any]],
                           reward_signals: List[Dict[str, Any]],
                           optimization_context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Main optimization method using trace analysis and reward interpretation.
        
        Args:
            task_description: Description of the task
            current_instruction: Current instruction to optimize
            instruction_outcome_traces: Historical instruction-outcome pairs
            reward_signals: Performance reward signals
            optimization_context: Additional context for optimization
            
        Returns:
            Dictionary containing optimized instruction and reasoning
        """
        
        print(f"🧠 Starting intelligent instruction optimization...")
        
        # Convert traces to structured format
        structured_traces = self._convert_to_instruction_traces(instruction_outcome_traces)
        
        # Add traces to analyzer
        for trace in structured_traces:
            self.trace_analyzer.add_trace(trace)
        
        # Convert rewards to structured format
        structured_rewards = self._convert_to_reward_signals(reward_signals)
        
        # Analyze traces for optimization insights
        trace_analysis = self.trace_analyzer.analyze_traces(
            task_context=task_description,
            min_pattern_frequency=2
        )
        
        # Get optimization context from trace history
        optimization_context_enhanced = self.trace_analyzer.get_optimization_context(
            current_instruction=current_instruction,
            task_description=task_description,
            recent_performance=[r.get('reward_value', 0) for r in structured_rewards[-5:]]
        )
        
        # Interpret reward signals for natural language feedback
        reward_feedback = self.reward_interpreter.interpret_reward_signals(
            reward_signals=structured_rewards,
            current_instruction=current_instruction,
            optimization_context=optimization_context_enhanced
        )
        
        # Perform self-reflection on optimization approach
        self_reflection = self._perform_self_reflection(
            current_instruction, trace_analysis, reward_feedback, task_description
        )
        
        # Generate optimized instruction using LLM's full capabilities
        optimized_instruction_result = self._generate_optimized_instruction(
            task_description=task_description,
            current_instruction=current_instruction,
            trace_insights=trace_analysis,
            reward_feedback=reward_feedback,
            self_reflection=self_reflection,
            optimization_context=optimization_context_enhanced
        )
        
        # Validate and refine the optimized instruction
        validation_result = self._validate_optimized_instruction(
            optimized_instruction_result['optimized_instruction'],
            task_description,
            trace_analysis,
            reward_feedback
        )
        
        # Store optimization in memory for meta-learning
        self._store_optimization_experience(
            current_instruction,
            optimized_instruction_result['optimized_instruction'],
            trace_analysis,
            reward_feedback,
            task_description
        )
        
        # Compile comprehensive result
        optimization_result = {
            'optimized_instruction': optimized_instruction_result['optimized_instruction'],
            'optimization_reasoning': optimized_instruction_result['reasoning'],
            'confidence_score': optimized_instruction_result['confidence'],
            'trace_analysis_summary': self._summarize_trace_analysis(trace_analysis),
            'reward_interpretation': {
                'feedback_text': reward_feedback.feedback_text,
                'improvement_suggestions': reward_feedback.improvement_suggestions,
                'strength_areas': reward_feedback.strength_areas,
                'weakness_areas': reward_feedback.weakness_areas
            },
            'self_reflection_insights': self_reflection,
            'validation_results': validation_result,
            'optimization_metadata': {
                'traces_analyzed': len(structured_traces),
                'patterns_discovered': len(trace_analysis.get('patterns', [])),
                'optimization_strategy': self.optimization_strategy,
                'timestamp': time.time()
            }
        }
        
        print(f"✅ Optimization complete. Confidence: {optimized_instruction_result['confidence']:.2f}")
        
        return optimization_result
    
    def _generate_optimized_instruction(self,
                                      task_description: str,
                                      current_instruction: str,
                                      trace_insights: Dict[str, Any],
                                      reward_feedback: RewardFeedback,
                                      self_reflection: Dict[str, Any],
                                      optimization_context: Dict[str, Any]) -> Dict[str, Any]:
        """Generate optimized instruction using LLM's full reasoning capabilities."""
        
        # Prepare comprehensive optimization context
        optimization_prompt = self._create_optimization_prompt(
            task_description,
            current_instruction,
            trace_insights,
            reward_feedback,
            self_reflection,
            optimization_context
        )
        
        # Use trace optimization predictor
        result = self.trace_optimizer(
            task_description=task_description,
            current_instruction=current_instruction,
            trace_analysis=json.dumps(trace_insights, indent=2),
            reward_feedback=reward_feedback.feedback_text,
            optimization_insights=json.dumps(self_reflection, indent=2),
            optimization_context=json.dumps(optimization_context, indent=2)
        )
        
        return {
            'optimized_instruction': result.optimized_instruction,
            'reasoning': result.optimization_reasoning,
            'confidence': float(result.confidence_score)
        }
    
    def _perform_self_reflection(self,
                               current_instruction: str,
                               trace_analysis: Dict[str, Any],
                               reward_feedback: RewardFeedback,
                               task_description: str) -> Dict[str, Any]:
        """Perform self-reflection on optimization approach and history."""
        
        # Analyze own optimization history
        optimization_history = self._get_optimization_history(task_description)
        
        # Use self-reflection predictor
        reflection_result = self.self_reflector(
            current_instruction=current_instruction,
            task_context=task_description,
            performance_feedback=reward_feedback.feedback_text,
            trace_patterns=json.dumps(trace_analysis.get('patterns', []), indent=2),
            optimization_history=json.dumps(optimization_history, indent=2)
        )
        
        return {
            'self_assessment': reflection_result.self_assessment,
            'optimization_strategy': reflection_result.optimization_strategy,
            'learning_insights': reflection_result.learning_insights,
            'confidence_in_approach': float(reflection_result.confidence_level)
        }
    
    def _validate_optimized_instruction(self,
                                      optimized_instruction: str,
                                      task_description: str,
                                      trace_analysis: Dict[str, Any],
                                      reward_feedback: RewardFeedback) -> Dict[str, Any]:
        """Validate the optimized instruction before returning."""
        
        # Use instruction evaluator
        evaluation_result = self.instruction_evaluator(
            instruction=optimized_instruction,
            task_description=task_description,
            execution_result="Hypothetical execution for validation",
            expected_outcome="Improved performance based on trace analysis"
        )
        
        # Perform additional validation checks
        validation_checks = {
            'length_appropriate': self._check_instruction_length(optimized_instruction),
            'clarity_improved': self._check_clarity_improvement(optimized_instruction, trace_analysis),
            'addresses_weaknesses': self._check_weakness_addressing(optimized_instruction, reward_feedback),
            'maintains_strengths': self._check_strength_preservation(optimized_instruction, reward_feedback),
            'follows_patterns': self._check_pattern_adherence(optimized_instruction, trace_analysis)
        }
        
        overall_validation_score = sum(validation_checks.values()) / len(validation_checks)
        
        return {
            'quality_score': float(evaluation_result.quality_score),
            'effectiveness_score': float(evaluation_result.effectiveness_score),
            'validation_checks': validation_checks,
            'overall_validation_score': overall_validation_score,
            'improvement_suggestions': evaluation_result.improvement_suggestions,
            'validation_passed': overall_validation_score > 0.6
        }
    
    def _store_optimization_experience(self,
                                     original_instruction: str,
                                     optimized_instruction: str,
                                     trace_analysis: Dict[str, Any],
                                     reward_feedback: RewardFeedback,
                                     task_description: str):
        """Store optimization experience for meta-learning."""
        
        experience = {
            'original_instruction': original_instruction,
            'optimized_instruction': optimized_instruction,
            'task_type': self._classify_task_type(task_description),
            'optimization_changes': self._analyze_optimization_changes(original_instruction, optimized_instruction),
            'trace_patterns_used': trace_analysis.get('patterns', []),
            'reward_feedback_summary': {
                'strengths': reward_feedback.strength_areas,
                'weaknesses': reward_feedback.weakness_areas,
                'suggestions_used': reward_feedback.improvement_suggestions
            },
            'timestamp': time.time()
        }
        
        # Store in meta-learning memory
        task_type = experience['task_type']
        self.meta_learning_memory[task_type].append(experience)
        
        # Update successful patterns if this was a good optimization
        if len(reward_feedback.strength_areas) > len(reward_feedback.weakness_areas):
            self._update_successful_patterns(experience)
    
    def _convert_to_instruction_traces(self, traces: List[Dict[str, Any]]) -> List[InstructionTrace]:
        """Convert raw traces to InstructionTrace objects."""
        
        structured_traces = []
        
        for trace in traces:
            structured_trace = InstructionTrace(
                instruction=trace.get('instruction', ''),
                task_input=trace.get('task_input', ''),
                expected_output=trace.get('expected_output', ''),
                actual_output=trace.get('actual_output', ''),
                performance_metrics=trace.get('performance_metrics', {}),
                execution_time=trace.get('execution_time', 0.0),
                timestamp=trace.get('timestamp', str(time.time())),
                task_context=trace.get('task_context', {})
            )
            structured_traces.append(structured_trace)
        
        return structured_traces
    
    def _convert_to_reward_signals(self, rewards: List[Dict[str, Any]]) -> List[RewardSignal]:
        """Convert raw reward signals to RewardSignal objects."""
        
        structured_rewards = []
        
        for reward in rewards:
            structured_reward = RewardSignal(
                reward_value=reward.get('reward_value', 0.0),
                reward_type=reward.get('reward_type', 'overall'),
                task_context=reward.get('task_context', ''),
                instruction_used=reward.get('instruction_used', ''),
                performance_metrics=reward.get('performance_metrics', {}),
                timestamp=reward.get('timestamp', str(time.time()))
            )
            structured_rewards.append(structured_reward)
        
        return structured_rewards
    
    def _create_optimization_prompt(self,
                                  task_description: str,
                                  current_instruction: str,
                                  trace_insights: Dict[str, Any],
                                  reward_feedback: RewardFeedback,
                                  self_reflection: Dict[str, Any],
                                  optimization_context: Dict[str, Any]) -> str:
        """Create comprehensive optimization prompt for the LLM."""
        
        prompt_parts = [
            f"Task: {task_description}",
            f"Current Instruction: {current_instruction}",
            "",
            "Performance Analysis:",
            reward_feedback.feedback_text,
            "",
            "Key Insights from Trace Analysis:",
        ]
        
        # Add trace insights
        for insight in trace_insights.get('insights', []):
            prompt_parts.append(f"- {insight}")
        
        prompt_parts.extend([
            "",
            "Improvement Recommendations:",
        ])
        
        # Add improvement suggestions
        for suggestion in reward_feedback.improvement_suggestions:
            prompt_parts.append(f"- {suggestion}")
        
        # Add self-reflection insights
        if self_reflection.get('learning_insights'):
            prompt_parts.extend([
                "",
                "Self-Reflection Insights:",
                self_reflection['learning_insights']
            ])
        
        # Add optimization context
        if optimization_context.get('successful_elements'):
            prompt_parts.extend([
                "",
                "Successful Elements to Consider:",
            ])
            for element in optimization_context['successful_elements']:
                prompt_parts.append(f"- {element}")
        
        return "\n".join(prompt_parts)
    
    def _summarize_trace_analysis(self, trace_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Summarize trace analysis for the result."""
        
        return {
            'total_traces_analyzed': trace_analysis.get('total_traces', 0),
            'patterns_found': len(trace_analysis.get('patterns', [])),
            'key_insights': trace_analysis.get('insights', [])[:3],
            'top_recommendations': trace_analysis.get('recommendations', [])[:3],
            'performance_trend': trace_analysis.get('performance_trends', {})
        }
    
    def _get_optimization_history(self, task_description: str) -> List[Dict[str, Any]]:
        """Get optimization history for similar tasks."""
        
        task_type = self._classify_task_type(task_description)
        return self.meta_learning_memory.get(task_type, [])[-5:]  # Last 5 optimizations
    
    def _classify_task_type(self, task_description: str) -> str:
        """Classify task type for meta-learning."""
        
        description_lower = task_description.lower()
        
        if any(word in description_lower for word in ['question', 'answer', 'qa']):
            return 'question_answering'
        elif any(word in description_lower for word in ['math', 'calculate', 'solve']):
            return 'mathematical'
        elif any(word in description_lower for word in ['analyze', 'sentiment', 'text']):
            return 'text_analysis'
        elif any(word in description_lower for word in ['reason', 'logic', 'think']):
            return 'reasoning'
        elif any(word in description_lower for word in ['step', 'workflow', 'process']):
            return 'workflow'
        else:
            return 'general'
    
    def _analyze_optimization_changes(self, original: str, optimized: str) -> Dict[str, Any]:
        """Analyze what changed between original and optimized instructions."""
        
        original_words = set(original.lower().split())
        optimized_words = set(optimized.lower().split())
        
        return {
            'words_added': list(optimized_words - original_words),
            'words_removed': list(original_words - optimized_words),
            'length_change': len(optimized.split()) - len(original.split()),
            'structural_changes': self._detect_structural_changes(original, optimized)
        }
    
    def _detect_structural_changes(self, original: str, optimized: str) -> List[str]:
        """Detect structural changes between instructions."""
        
        changes = []
        
        # Check for step addition
        if 'step' not in original.lower() and 'step' in optimized.lower():
            changes.append('added_step_structure')
        
        # Check for example addition
        if 'example' not in original.lower() and 'example' in optimized.lower():
            changes.append('added_examples')
        
        # Check for specificity increase
        specificity_words = ['specific', 'detailed', 'precise', 'exact']
        orig_specificity = sum(1 for word in specificity_words if word in original.lower())
        opt_specificity = sum(1 for word in specificity_words if word in optimized.lower())
        
        if opt_specificity > orig_specificity:
            changes.append('increased_specificity')
        
        return changes
    
    def _update_successful_patterns(self, experience: Dict[str, Any]):
        """Update successful patterns based on optimization experience."""
        
        pattern = {
            'task_type': experience['task_type'],
            'optimization_changes': experience['optimization_changes'],
            'successful_elements': experience['reward_feedback_summary']['strengths'],
            'effectiveness_score': len(experience['reward_feedback_summary']['strengths'])
        }
        
        self.successful_patterns.append(pattern)
        
        # Keep only top patterns
        self.successful_patterns.sort(key=lambda p: p['effectiveness_score'], reverse=True)
        self.successful_patterns = self.successful_patterns[:20]
    
    def _check_instruction_length(self, instruction: str) -> float:
        """Check if instruction length is appropriate."""
        
        word_count = len(instruction.split())
        
        if 10 <= word_count <= 100:
            return 1.0
        elif 5 <= word_count <= 150:
            return 0.7
        else:
            return 0.3
    
    def _check_clarity_improvement(self, instruction: str, trace_analysis: Dict[str, Any]) -> float:
        """Check if instruction clarity has improved based on trace analysis."""
        
        clarity_indicators = ['clear', 'specific', 'step', 'example', 'detailed']
        clarity_score = sum(1 for indicator in clarity_indicators if indicator in instruction.lower())
        
        # Normalize score
        return min(clarity_score / 3, 1.0)
    
    def _check_weakness_addressing(self, instruction: str, reward_feedback: RewardFeedback) -> float:
        """Check if instruction addresses identified weaknesses."""
        
        if not reward_feedback.weakness_areas:
            return 1.0
        
        addressed_count = 0
        for weakness in reward_feedback.weakness_areas:
            # Simple keyword matching - could be more sophisticated
            if any(word in instruction.lower() for word in weakness.lower().split()[:3]):
                addressed_count += 1
        
        return addressed_count / len(reward_feedback.weakness_areas)
    
    def _check_strength_preservation(self, instruction: str, reward_feedback: RewardFeedback) -> float:
        """Check if instruction preserves identified strengths."""
        
        if not reward_feedback.strength_areas:
            return 1.0
        
        preserved_count = 0
        for strength in reward_feedback.strength_areas:
            # Simple keyword matching - could be more sophisticated
            if any(word in instruction.lower() for word in strength.lower().split()[:3]):
                preserved_count += 1
        
        return preserved_count / len(reward_feedback.strength_areas)
    
    def _check_pattern_adherence(self, instruction: str, trace_analysis: Dict[str, Any]) -> float:
        """Check if instruction follows successful patterns from trace analysis."""
        
        patterns = trace_analysis.get('patterns', [])
        successful_patterns = [p for p in patterns if p.get('pattern_type') == 'successful']
        
        if not successful_patterns:
            return 0.5  # Neutral score if no patterns
        
        adherence_score = 0
        for pattern in successful_patterns:
            features = pattern.get('instruction_features', [])
            if any(feature in instruction.lower() for feature in features):
                adherence_score += 1
        
        return min(adherence_score / len(successful_patterns), 1.0)
    
    def _create_trace_optimization_signature(self):
        """Create DSPy signature for trace-based optimization."""
        
        class TraceOptimization(dspy.Signature):
            """Optimize instruction based on comprehensive trace analysis and reward feedback."""
            
            task_description: str = dspy.InputField(desc="Description of the task")
            current_instruction: str = dspy.InputField(desc="Current instruction to optimize")
            trace_analysis: str = dspy.InputField(desc="JSON analysis of instruction-outcome traces")
            reward_feedback: str = dspy.InputField(desc="Natural language feedback from reward interpretation")
            optimization_insights: str = dspy.InputField(desc="Self-reflection insights on optimization approach")
            optimization_context: str = dspy.InputField(desc="Additional optimization context and similar instructions")
            
            optimized_instruction: str = dspy.OutputField(desc="Optimized instruction using full LLM vocabulary and reasoning")
            optimization_reasoning: str = dspy.OutputField(desc="Detailed reasoning behind optimization choices")
            confidence_score: float = dspy.OutputField(desc="Confidence in optimization effectiveness (0-1)")
        
        return TraceOptimization
    
    def _create_reward_analysis_signature(self):
        """Create DSPy signature for reward signal analysis."""
        
        class RewardAnalysis(dspy.Signature):
            """Analyze reward signals to understand instruction performance patterns."""
            
            reward_signals: str = dspy.InputField(desc="JSON array of reward signals with performance metrics")
            instruction_context: str = dspy.InputField(desc="Context about the instruction and task")
            
            performance_interpretation: str = dspy.OutputField(desc="Natural language interpretation of performance")
            optimization_priorities: str = dspy.OutputField(desc="Priority areas for optimization based on rewards")
            success_factors: str = dspy.OutputField(desc="Factors contributing to successful performance")
        
        return RewardAnalysis
    
    def _create_self_reflection_signature(self):
        """Create DSPy signature for self-reflection on optimization."""
        
        class SelfReflection(dspy.Signature):
            """Perform self-reflection on optimization approach and learning."""
            
            current_instruction: str = dspy.InputField(desc="Current instruction being optimized")
            task_context: str = dspy.InputField(desc="Context and description of the task")
            performance_feedback: str = dspy.InputField(desc="Feedback on current performance")
            trace_patterns: str = dspy.InputField(desc="Patterns discovered in trace analysis")
            optimization_history: str = dspy.InputField(desc="History of previous optimizations")
            
            self_assessment: str = dspy.OutputField(desc="Self-assessment of optimization approach")
            optimization_strategy: str = dspy.OutputField(desc="Strategy for optimizing this instruction")
            learning_insights: str = dspy.OutputField(desc="Insights learned from analysis and history")
            confidence_level: float = dspy.OutputField(desc="Confidence in optimization approach (0-1)")
        
        return SelfReflection
    
    def get_optimization_statistics(self) -> Dict[str, Any]:
        """Get comprehensive optimization statistics."""
        
        stats = {
            'total_optimizations': sum(len(experiences) for experiences in self.meta_learning_memory.values()),
            'task_types_handled': list(self.meta_learning_memory.keys()),
            'successful_patterns_learned': len(self.successful_patterns),
            'traces_analyzed': len(self.trace_analyzer.trace_history),
            'optimization_strategy': self.optimization_strategy
        }
        
        # Add task-specific statistics
        for task_type, experiences in self.meta_learning_memory.items():
            stats[f'{task_type}_optimizations'] = len(experiences)
        
        return stats