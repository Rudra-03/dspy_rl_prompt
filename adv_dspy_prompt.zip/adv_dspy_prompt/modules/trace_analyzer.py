"""Trace analyzer for instruction-outcome pattern analysis."""

import json
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from collections import defaultdict
import numpy as np

@dataclass
class InstructionTrace:
    """Represents a single instruction-outcome trace."""
    instruction: str
    task_input: str
    expected_output: str
    actual_output: str
    performance_metrics: Dict[str, float]
    execution_time: float
    timestamp: str
    task_context: Dict[str, Any] = field(default_factory=dict)

@dataclass
class TracePattern:
    """Represents a discovered pattern in instruction-outcome traces."""
    pattern_id: str
    pattern_type: str  # 'successful', 'failure', 'improvement'
    instruction_features: List[str]
    performance_correlation: float
    frequency: int
    examples: List[InstructionTrace]
    insights: str

class TraceAnalyzer:
    """Analyzes instruction-outcome traces to identify optimization patterns."""
    
    def __init__(self, max_trace_history: int = 1000):
        self.max_trace_history = max_trace_history
        self.trace_history: List[InstructionTrace] = []
        self.discovered_patterns: List[TracePattern] = []
        self.feature_performance_map = defaultdict(list)
        
    def add_trace(self, trace: InstructionTrace):
        """Add a new instruction-outcome trace to the history."""
        self.trace_history.append(trace)
        
        # Maintain maximum history size
        if len(self.trace_history) > self.max_trace_history:
            self.trace_history = self.trace_history[-self.max_trace_history:]
        
        # Extract and index instruction features
        self._extract_and_index_features(trace)
    
    def analyze_traces(self, 
                      task_context: Optional[str] = None,
                      min_pattern_frequency: int = 3) -> Dict[str, Any]:
        """
        Analyze traces to discover optimization patterns and insights.
        
        Args:
            task_context: Optional context to filter relevant traces
            min_pattern_frequency: Minimum frequency for pattern discovery
            
        Returns:
            Dictionary containing analysis results and insights
        """
        
        if len(self.trace_history) < 2:
            return {
                'patterns': [],
                'insights': ['Insufficient trace history for pattern analysis'],
                'recommendations': ['Collect more instruction-outcome data']
            }
        
        # Filter traces by context if provided
        relevant_traces = self._filter_traces_by_context(task_context)
        
        # Discover patterns
        patterns = self._discover_patterns(relevant_traces, min_pattern_frequency)
        
        # Generate insights
        insights = self._generate_insights(patterns, relevant_traces)
        
        # Create recommendations
        recommendations = self._generate_recommendations(patterns, insights)
        
        return {
            'total_traces': len(relevant_traces),
            'patterns': [self._pattern_to_dict(p) for p in patterns],
            'insights': insights,
            'recommendations': recommendations,
            'performance_trends': self._analyze_performance_trends(relevant_traces),
            'feature_correlations': self._analyze_feature_correlations(relevant_traces)
        }
    
    def get_optimization_context(self, 
                               current_instruction: str,
                               task_description: str,
                               recent_performance: List[float]) -> Dict[str, Any]:
        """
        Get optimization context for the current instruction based on trace history.
        
        Args:
            current_instruction: Current instruction to optimize
            task_description: Description of the current task
            recent_performance: Recent performance scores
            
        Returns:
            Context dictionary for optimization
        """
        
        # Find similar instructions in history
        similar_traces = self._find_similar_instructions(current_instruction)
        
        # Analyze performance trajectory
        performance_trend = self._analyze_recent_performance(recent_performance)
        
        # Identify relevant patterns
        relevant_patterns = self._get_relevant_patterns(task_description, current_instruction)
        
        # Extract successful elements from similar instructions
        successful_elements = self._extract_successful_elements(similar_traces)
        
        # Identify failure patterns to avoid
        failure_patterns = self._identify_failure_patterns(similar_traces)
        
        return {
            'similar_instructions': [
                {
                    'instruction': trace.instruction,
                    'performance': trace.performance_metrics.get('overall_score', 0),
                    'similarity_score': self._calculate_instruction_similarity(
                        current_instruction, trace.instruction
                    )
                }
                for trace in similar_traces[:5]  # Top 5 similar
            ],
            'performance_trend': performance_trend,
            'relevant_patterns': relevant_patterns,
            'successful_elements': successful_elements,
            'failure_patterns': failure_patterns,
            'optimization_priority': self._determine_optimization_priority(
                recent_performance, similar_traces
            )
        }
    
    def _extract_and_index_features(self, trace: InstructionTrace):
        """Extract features from instruction and index them with performance."""
        
        instruction = trace.instruction.lower()
        performance = trace.performance_metrics.get('overall_score', 0)
        
        # Extract various instruction features
        features = []
        
        # Length features
        word_count = len(instruction.split())
        features.append(f"word_count_{self._discretize_value(word_count, [10, 20, 50])}")
        
        # Structure features
        if any(word in instruction for word in ['step', 'first', 'then', 'finally']):
            features.append('structured_approach')
        
        if instruction.count('.') > 2:
            features.append('multi_sentence')
        
        # Tone features
        if any(word in instruction for word in ['please', 'carefully', 'thoroughly']):
            features.append('polite_tone')
        
        if any(word in instruction for word in ['must', 'ensure', 'make sure']):
            features.append('imperative_tone')
        
        # Specificity features
        if any(word in instruction for word in ['specific', 'detailed', 'precise']):
            features.append('specificity_emphasis')
        
        # Context features
        if any(word in instruction for word in ['context', 'background', 'information']):
            features.append('context_aware')
        
        # Example features
        if any(word in instruction for word in ['example', 'instance', 'case']):
            features.append('example_oriented')
        
        # Reasoning features
        if any(word in instruction for word in ['analyze', 'think', 'consider', 'evaluate']):
            features.append('reasoning_emphasis')
        
        # Index features with performance
        for feature in features:
            self.feature_performance_map[feature].append(performance)
    
    def _discretize_value(self, value: float, thresholds: List[float]) -> str:
        """Discretize a continuous value into categories."""
        for i, threshold in enumerate(thresholds):
            if value <= threshold:
                return f"low_{i}" if i == 0 else f"medium_{i}"
        return "high"
    
    def _filter_traces_by_context(self, task_context: Optional[str]) -> List[InstructionTrace]:
        """Filter traces by task context if provided."""
        
        if not task_context:
            return self.trace_history
        
        # Simple keyword-based filtering
        context_keywords = task_context.lower().split()
        filtered_traces = []
        
        for trace in self.trace_history:
            trace_context = (
                trace.task_input.lower() + " " + 
                trace.instruction.lower() + " " +
                str(trace.task_context).lower()
            )
            
            # Check if any context keywords appear in trace
            if any(keyword in trace_context for keyword in context_keywords):
                filtered_traces.append(trace)
        
        return filtered_traces if filtered_traces else self.trace_history
    
    def _discover_patterns(self, 
                          traces: List[InstructionTrace], 
                          min_frequency: int) -> List[TracePattern]:
        """Discover patterns in instruction-outcome traces."""
        
        patterns = []
        
        # Group traces by performance levels
        high_performance = [t for t in traces if t.performance_metrics.get('overall_score', 0) > 0.8]
        low_performance = [t for t in traces if t.performance_metrics.get('overall_score', 0) < 0.3]
        
        # Analyze high-performance patterns
        if len(high_performance) >= min_frequency:
            success_pattern = self._analyze_instruction_group(
                high_performance, 'successful', 'high_performance'
            )
            if success_pattern:
                patterns.append(success_pattern)
        
        # Analyze low-performance patterns
        if len(low_performance) >= min_frequency:
            failure_pattern = self._analyze_instruction_group(
                low_performance, 'failure', 'low_performance'
            )
            if failure_pattern:
                patterns.append(failure_pattern)
        
        # Analyze improvement patterns
        improvement_patterns = self._find_improvement_patterns(traces, min_frequency)
        patterns.extend(improvement_patterns)
        
        return patterns
    
    def _analyze_instruction_group(self, 
                                  traces: List[InstructionTrace],
                                  pattern_type: str,
                                  pattern_id: str) -> Optional[TracePattern]:
        """Analyze a group of instructions to find common patterns."""
        
        if not traces:
            return None
        
        # Extract common features
        all_instructions = [trace.instruction.lower() for trace in traces]
        common_words = self._find_common_words(all_instructions)
        common_structures = self._find_common_structures(all_instructions)
        
        # Calculate average performance
        avg_performance = np.mean([
            trace.performance_metrics.get('overall_score', 0) 
            for trace in traces
        ])
        
        # Generate insights
        insights = self._generate_pattern_insights(
            common_words, common_structures, avg_performance, pattern_type
        )
        
        return TracePattern(
            pattern_id=pattern_id,
            pattern_type=pattern_type,
            instruction_features=common_words + common_structures,
            performance_correlation=avg_performance,
            frequency=len(traces),
            examples=traces[:3],  # Keep top 3 examples
            insights=insights
        )
    
    def _find_common_words(self, instructions: List[str], min_frequency: float = 0.5) -> List[str]:
        """Find words that appear frequently across instructions."""
        
        word_counts = defaultdict(int)
        total_instructions = len(instructions)
        
        for instruction in instructions:
            words = set(instruction.split())  # Use set to avoid counting duplicates per instruction
            for word in words:
                if len(word) > 3:  # Skip short words
                    word_counts[word] += 1
        
        # Return words that appear in at least min_frequency of instructions
        threshold = total_instructions * min_frequency
        return [word for word, count in word_counts.items() if count >= threshold]
    
    def _find_common_structures(self, instructions: List[str]) -> List[str]:
        """Find common structural patterns in instructions."""
        
        structures = []
        
        # Check for common structural patterns
        step_count = sum(1 for inst in instructions if any(word in inst for word in ['step', 'first', 'then']))
        if step_count > len(instructions) * 0.5:
            structures.append('step_by_step_structure')
        
        question_count = sum(1 for inst in instructions if '?' in inst)
        if question_count > len(instructions) * 0.3:
            structures.append('question_based')
        
        example_count = sum(1 for inst in instructions if 'example' in inst)
        if example_count > len(instructions) * 0.3:
            structures.append('example_driven')
        
        return structures
    
    def _find_improvement_patterns(self, 
                                  traces: List[InstructionTrace], 
                                  min_frequency: int) -> List[TracePattern]:
        """Find patterns where instructions improved over time."""
        
        # Sort traces by timestamp
        sorted_traces = sorted(traces, key=lambda t: t.timestamp)
        
        improvement_sequences = []
        current_sequence = []
        
        # Find sequences of improving performance
        for i in range(1, len(sorted_traces)):
            prev_performance = sorted_traces[i-1].performance_metrics.get('overall_score', 0)
            curr_performance = sorted_traces[i].performance_metrics.get('overall_score', 0)
            
            if curr_performance > prev_performance + 0.1:  # Significant improvement
                if not current_sequence:
                    current_sequence = [sorted_traces[i-1]]
                current_sequence.append(sorted_traces[i])
            else:
                if len(current_sequence) >= min_frequency:
                    improvement_sequences.append(current_sequence)
                current_sequence = []
        
        # Add final sequence if valid
        if len(current_sequence) >= min_frequency:
            improvement_sequences.append(current_sequence)
        
        # Analyze improvement sequences
        patterns = []
        for i, sequence in enumerate(improvement_sequences):
            pattern = self._analyze_improvement_sequence(sequence, f"improvement_{i}")
            if pattern:
                patterns.append(pattern)
        
        return patterns
    
    def _analyze_improvement_sequence(self, 
                                    sequence: List[InstructionTrace],
                                    pattern_id: str) -> Optional[TracePattern]:
        """Analyze a sequence of improving instructions."""
        
        if len(sequence) < 2:
            return None
        
        # Analyze what changed between instructions
        changes = []
        for i in range(1, len(sequence)):
            prev_inst = sequence[i-1].instruction
            curr_inst = sequence[i].instruction
            change = self._analyze_instruction_change(prev_inst, curr_inst)
            changes.append(change)
        
        # Calculate improvement correlation
        performance_improvement = (
            sequence[-1].performance_metrics.get('overall_score', 0) -
            sequence[0].performance_metrics.get('overall_score', 0)
        )
        
        # Generate insights about what drove improvement
        insights = self._generate_improvement_insights(changes, performance_improvement)
        
        return TracePattern(
            pattern_id=pattern_id,
            pattern_type='improvement',
            instruction_features=changes,
            performance_correlation=performance_improvement,
            frequency=len(sequence),
            examples=sequence,
            insights=insights
        )
    
    def _analyze_instruction_change(self, prev_instruction: str, curr_instruction: str) -> str:
        """Analyze what changed between two instructions."""
        
        prev_words = set(prev_instruction.lower().split())
        curr_words = set(curr_instruction.lower().split())
        
        added_words = curr_words - prev_words
        removed_words = prev_words - curr_words
        
        if len(curr_instruction) > len(prev_instruction) * 1.2:
            return "instruction_expansion"
        elif len(curr_instruction) < len(prev_instruction) * 0.8:
            return "instruction_simplification"
        elif added_words:
            if any(word in added_words for word in ['step', 'first', 'then']):
                return "added_structure"
            elif any(word in added_words for word in ['specific', 'detailed', 'precise']):
                return "added_specificity"
            elif any(word in added_words for word in ['example', 'instance']):
                return "added_examples"
            else:
                return "vocabulary_enhancement"
        else:
            return "minor_refinement"
    
    def _generate_insights(self, 
                          patterns: List[TracePattern], 
                          traces: List[InstructionTrace]) -> List[str]:
        """Generate insights from discovered patterns."""
        
        insights = []
        
        if not patterns:
            insights.append("No clear patterns detected in current trace history")
            return insights
        
        # Analyze successful patterns
        successful_patterns = [p for p in patterns if p.pattern_type == 'successful']
        if successful_patterns:
            best_pattern = max(successful_patterns, key=lambda p: p.performance_correlation)
            insights.append(
                f"Most successful instruction pattern includes: {', '.join(best_pattern.instruction_features[:3])}"
            )
        
        # Analyze failure patterns
        failure_patterns = [p for p in patterns if p.pattern_type == 'failure']
        if failure_patterns:
            worst_pattern = min(failure_patterns, key=lambda p: p.performance_correlation)
            insights.append(
                f"Instructions to avoid typically include: {', '.join(worst_pattern.instruction_features[:3])}"
            )
        
        # Analyze improvement patterns
        improvement_patterns = [p for p in patterns if p.pattern_type == 'improvement']
        if improvement_patterns:
            insights.append(
                f"Performance improvements often result from: {', '.join(improvement_patterns[0].instruction_features[:2])}"
            )
        
        # Performance trend insights
        if len(traces) >= 5:
            recent_performance = [t.performance_metrics.get('overall_score', 0) for t in traces[-5:]]
            if len(set(recent_performance)) > 1:  # Performance varies
                trend = "improving" if recent_performance[-1] > recent_performance[0] else "declining"
                insights.append(f"Recent performance trend is {trend}")
        
        return insights
    
    def _generate_recommendations(self, 
                                patterns: List[TracePattern], 
                                insights: List[str]) -> List[str]:
        """Generate optimization recommendations based on patterns and insights."""
        
        recommendations = []
        
        # Feature-based recommendations
        if self.feature_performance_map:
            best_features = sorted(
                self.feature_performance_map.items(),
                key=lambda x: np.mean(x[1]) if x[1] else 0,
                reverse=True
            )[:3]
            
            for feature, performances in best_features:
                if np.mean(performances) > 0.7:
                    recommendations.append(f"Consider incorporating '{feature}' - shows high performance correlation")
        
        # Pattern-based recommendations
        successful_patterns = [p for p in patterns if p.pattern_type == 'successful']
        if successful_patterns:
            best_pattern = max(successful_patterns, key=lambda p: p.performance_correlation)
            recommendations.append(
                f"Adopt successful pattern elements: {', '.join(best_pattern.instruction_features[:2])}"
            )
        
        # Improvement-based recommendations
        improvement_patterns = [p for p in patterns if p.pattern_type == 'improvement']
        if improvement_patterns:
            recommendations.append(
                f"Focus optimization on: {', '.join(improvement_patterns[0].instruction_features[:2])}"
            )
        
        if not recommendations:
            recommendations.append("Experiment with different instruction styles to gather more optimization data")
        
        return recommendations
    
    def _find_similar_instructions(self, 
                                  instruction: str, 
                                  top_k: int = 10) -> List[InstructionTrace]:
        """Find traces with instructions similar to the given instruction."""
        
        similarities = []
        for trace in self.trace_history:
            similarity = self._calculate_instruction_similarity(instruction, trace.instruction)
            similarities.append((similarity, trace))
        
        # Sort by similarity and return top_k
        similarities.sort(key=lambda x: x[0], reverse=True)
        return [trace for _, trace in similarities[:top_k]]
    
    def _calculate_instruction_similarity(self, inst1: str, inst2: str) -> float:
        """Calculate similarity between two instructions using Jaccard similarity."""
        
        words1 = set(inst1.lower().split())
        words2 = set(inst2.lower().split())
        
        if not words1 and not words2:
            return 1.0
        if not words1 or not words2:
            return 0.0
        
        intersection = len(words1.intersection(words2))
        union = len(words1.union(words2))
        
        return intersection / union if union > 0 else 0.0
    
    def _analyze_recent_performance(self, recent_scores: List[float]) -> Dict[str, Any]:
        """Analyze recent performance trajectory."""
        
        if len(recent_scores) < 2:
            return {'trend': 'insufficient_data', 'stability': 'unknown'}
        
        # Calculate trend
        if len(recent_scores) >= 3:
            early_avg = np.mean(recent_scores[:len(recent_scores)//2])
            late_avg = np.mean(recent_scores[len(recent_scores)//2:])
            
            if late_avg > early_avg + 0.1:
                trend = 'improving'
            elif late_avg < early_avg - 0.1:
                trend = 'declining'
            else:
                trend = 'stable'
        else:
            trend = 'improving' if recent_scores[-1] > recent_scores[0] else 'declining'
        
        # Calculate stability
        std_dev = np.std(recent_scores)
        stability = 'stable' if std_dev < 0.1 else 'variable'
        
        return {
            'trend': trend,
            'stability': stability,
            'current_score': recent_scores[-1],
            'average_score': np.mean(recent_scores),
            'score_range': (min(recent_scores), max(recent_scores))
        }
    
    def _get_relevant_patterns(self, 
                              task_description: str, 
                              current_instruction: str) -> List[Dict]:
        """Get patterns relevant to current task and instruction."""
        
        relevant = []
        
        for pattern in self.discovered_patterns:
            relevance_score = 0
            
            # Check task context relevance
            task_words = set(task_description.lower().split())
            pattern_words = set(' '.join(pattern.instruction_features).lower().split())
            
            if task_words.intersection(pattern_words):
                relevance_score += 0.5
            
            # Check instruction similarity
            if any(feature in current_instruction.lower() for feature in pattern.instruction_features):
                relevance_score += 0.3
            
            # High-performance patterns are always relevant
            if pattern.performance_correlation > 0.7:
                relevance_score += 0.2
            
            if relevance_score > 0.3:
                relevant.append({
                    'pattern': self._pattern_to_dict(pattern),
                    'relevance_score': relevance_score
                })
        
        return sorted(relevant, key=lambda x: x['relevance_score'], reverse=True)
    
    def _extract_successful_elements(self, traces: List[InstructionTrace]) -> List[str]:
        """Extract elements from successful instructions."""
        
        successful_traces = [t for t in traces if t.performance_metrics.get('overall_score', 0) > 0.7]
        
        if not successful_traces:
            return []
        
        # Extract common successful elements
        elements = []
        instructions = [t.instruction.lower() for t in successful_traces]
        
        # Common phrases
        common_phrases = self._find_common_phrases(instructions)
        elements.extend(common_phrases)
        
        # Structural elements
        if sum(1 for inst in instructions if 'step' in inst) > len(instructions) * 0.5:
            elements.append('step-by-step approach')
        
        if sum(1 for inst in instructions if any(word in inst for word in ['specific', 'detailed'])) > len(instructions) * 0.4:
            elements.append('specificity emphasis')
        
        return elements[:5]  # Top 5 elements
    
    def _identify_failure_patterns(self, traces: List[InstructionTrace]) -> List[str]:
        """Identify patterns associated with poor performance."""
        
        failure_traces = [t for t in traces if t.performance_metrics.get('overall_score', 0) < 0.4]
        
        if not failure_traces:
            return []
        
        patterns = []
        instructions = [t.instruction.lower() for t in failure_traces]
        
        # Check for problematic patterns
        if sum(1 for inst in instructions if len(inst.split()) < 5) > len(instructions) * 0.5:
            patterns.append('overly_brief_instructions')
        
        if sum(1 for inst in instructions if len(inst.split()) > 100) > len(instructions) * 0.3:
            patterns.append('overly_verbose_instructions')
        
        if sum(1 for inst in instructions if inst.count('?') > 2) > len(instructions) * 0.3:
            patterns.append('excessive_questioning')
        
        return patterns
    
    def _determine_optimization_priority(self, 
                                       recent_performance: List[float],
                                       similar_traces: List[InstructionTrace]) -> str:
        """Determine optimization priority based on performance and history."""
        
        if not recent_performance:
            return 'exploration'
        
        current_performance = recent_performance[-1]
        
        if current_performance < 0.3:
            return 'major_overhaul'
        elif current_performance < 0.6:
            return 'significant_improvement'
        elif current_performance < 0.8:
            return 'fine_tuning'
        else:
            return 'maintenance'
    
    def _find_common_phrases(self, instructions: List[str], min_length: int = 2) -> List[str]:
        """Find common phrases across instructions."""
        
        phrase_counts = defaultdict(int)
        
        for instruction in instructions:
            words = instruction.split()
            # Generate n-grams
            for n in range(min_length, min(4, len(words) + 1)):
                for i in range(len(words) - n + 1):
                    phrase = ' '.join(words[i:i+n])
                    if len(phrase) > 5:  # Skip very short phrases
                        phrase_counts[phrase] += 1
        
        # Return phrases that appear in multiple instructions
        threshold = max(2, len(instructions) * 0.3)
        return [phrase for phrase, count in phrase_counts.items() if count >= threshold]
    
    def _analyze_performance_trends(self, traces: List[InstructionTrace]) -> Dict[str, Any]:
        """Analyze performance trends over time."""
        
        if len(traces) < 3:
            return {'trend': 'insufficient_data'}
        
        # Sort by timestamp
        sorted_traces = sorted(traces, key=lambda t: t.timestamp)
        performances = [t.performance_metrics.get('overall_score', 0) for t in sorted_traces]
        
        # Calculate moving average
        window_size = min(5, len(performances) // 2)
        if window_size >= 2:
            moving_avg = []
            for i in range(len(performances) - window_size + 1):
                avg = np.mean(performances[i:i+window_size])
                moving_avg.append(avg)
        else:
            moving_avg = performances
        
        # Determine trend
        if len(moving_avg) >= 2:
            trend_slope = (moving_avg[-1] - moving_avg[0]) / len(moving_avg)
            if trend_slope > 0.02:
                trend = 'improving'
            elif trend_slope < -0.02:
                trend = 'declining'
            else:
                trend = 'stable'
        else:
            trend = 'stable'
        
        return {
            'trend': trend,
            'slope': trend_slope if len(moving_avg) >= 2 else 0,
            'current_performance': performances[-1],
            'best_performance': max(performances),
            'performance_variance': np.var(performances)
        }
    
    def _analyze_feature_correlations(self, traces: List[InstructionTrace]) -> Dict[str, float]:
        """Analyze correlations between instruction features and performance."""
        
        correlations = {}
        
        for feature, performances in self.feature_performance_map.items():
            if len(performances) >= 3:
                correlation = np.corrcoef(
                    range(len(performances)), 
                    performances
                )[0, 1] if len(performances) > 1 else 0
                
                correlations[feature] = {
                    'correlation': correlation,
                    'average_performance': np.mean(performances),
                    'frequency': len(performances)
                }
        
        return correlations
    
    def _pattern_to_dict(self, pattern: TracePattern) -> Dict[str, Any]:
        """Convert TracePattern to dictionary format."""
        return {
            'pattern_id': pattern.pattern_id,
            'pattern_type': pattern.pattern_type,
            'instruction_features': pattern.instruction_features,
            'performance_correlation': pattern.performance_correlation,
            'frequency': pattern.frequency,
            'insights': pattern.insights
        }
    
    def _generate_pattern_insights(self, 
                                  common_words: List[str],
                                  common_structures: List[str], 
                                  avg_performance: float,
                                  pattern_type: str) -> str:
        """Generate insights for a discovered pattern."""
        
        insights = []
        
        if pattern_type == 'successful':
            insights.append(f"High-performing instructions (avg: {avg_performance:.2f}) typically include:")
            if common_words:
                insights.append(f"- Key terms: {', '.join(common_words[:3])}")
            if common_structures:
                insights.append(f"- Structural patterns: {', '.join(common_structures)}")
        
        elif pattern_type == 'failure':
            insights.append(f"Low-performing instructions (avg: {avg_performance:.2f}) often contain:")
            if common_words:
                insights.append(f"- Problematic terms: {', '.join(common_words[:3])}")
            if common_structures:
                insights.append(f"- Ineffective structures: {', '.join(common_structures)}")
        
        return ' '.join(insights)
    
    def _generate_improvement_insights(self, 
                                     changes: List[str], 
                                     performance_improvement: float) -> str:
        """Generate insights about what drove performance improvements."""
        
        change_counts = defaultdict(int)
        for change in changes:
            change_counts[change] += 1
        
        most_common_change = max(change_counts, key=change_counts.get) if change_counts else "unknown"
        
        return (
            f"Performance improved by {performance_improvement:.2f} through "
            f"'{most_common_change}' modifications. "
            f"Most effective changes: {', '.join(list(change_counts.keys())[:2])}"
        )