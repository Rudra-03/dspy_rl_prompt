# -----------------------------
# Imports
# -----------------------------
import dspy
from dspy.optimizers import BootstrapFewShot
from typing import List, Dict, Any
import random

# -----------------------------
# Placeholder LLM Call (replace with actual API call)
# -----------------------------
def call_llm(prompt: str) -> str:
    # Replace with GPT/Claude API call
    return f"[LLM output for: {prompt[:50]}...]"

# -----------------------------
# DSPy Modules
# -----------------------------
class PromptOptimizer(dspy.Module):
    def forward(self, instruction: str, traces: List[Dict[str, Any]] = []):
        return dspy.Predict(
            "Optimize this instruction based on past traces. "
            "Instruction: {instruction}\nTraces: {traces}",
            input={"instruction": instruction, "traces": traces},
            output={"optimized_prompt": str}
        )

class ResponseGenerator(dspy.Module):
    def forward(self, optimized_prompt: str):
        return dspy.Predict(
            "Generate a response based on the optimized prompt.\nPrompt: {prompt}",
            input={"prompt": optimized_prompt},
            output={"response": str}
        )

class Judge(dspy.Module):
    def forward(self, response: str, gold: str):
        # Simple reward: fraction of gold tokens present in response
        return dspy.Predict(
            "Compute reward (0-1) based on overlap with gold.\nResponse: {response}\nGold: {gold}",
            input={"response": response, "gold": gold},
            output={"reward": float}
        )

# -----------------------------
# Prompt Optimization Program (Training)
# -----------------------------
class PromptOptimizationProgram(dspy.Module):
    def __init__(self):
        super().__init__()
        self.optimizer = PromptOptimizer()
        self.generator = ResponseGenerator()
        self.judge = Judge()

    def forward(self, instruction: str, gold: str):
        # Single-pass optimization, BootstrapFewShot will handle repeated refinements
        optimized_prompt = self.optimizer(instruction=instruction)["optimized_prompt"]
        response = self.generator(optimized_prompt=optimized_prompt)["response"]
        reward = self.judge(response=response, gold=gold)["reward"]
        return {"optimized_prompt": optimized_prompt, "response": response, "reward": reward}

# -----------------------------
# Test Program (Generalization)
# -----------------------------
class PromptOptimizationTest(dspy.Module):
    def __init__(self, trace_memory: List[Dict[str, Any]]):
        super().__init__()
        self.optimizer = PromptOptimizer()
        self.generator = ResponseGenerator()
        self.trace_memory = trace_memory

    def forward(self, instruction: str):
        optimized_prompt = self.optimizer(instruction=instruction, traces=self.trace_memory)["optimized_prompt"]
        response = self.generator(optimized_prompt=optimized_prompt)["response"]
        return {"optimized_prompt": optimized_prompt, "response": response}

# -----------------------------
# Example Run with BootstrapFewShot
# -----------------------------
if __name__ == "__main__":
    # 1️⃣ Training Data
    train_data = [
        {"instruction": "Translate 'hello' to French", "gold": "bonjour"},
        {"instruction": "What is 2+2?", "gold": "4"},
    ]

    # 2️⃣ Define eval metric for BootstrapFewShot
    def eval_metric(example, pred):
        return pred["reward"]

    # 3️⃣ Wrap program in DSPy BootstrapFewShot optimizer
    program = PromptOptimizationProgram()
    optimizer = BootstrapFewShot(metric=eval_metric, max_bootstraps=3, max_shots=5)

    print("=== Training Phase (with BootstrapFewShot) ===")
    optimized_program = optimizer.compile(program=program, trainset=train_data)

    # DSPy automatically runs training, logs traces, and tunes the PromptOptimizer

    # 4️⃣ Test Data (no gold)
    test_data = [
        {"instruction": "Translate 'goodbye' to French"},
        {"instruction": "What is 3+5?"},
    ]

    # Extract the trace memory learned during training
    trace_memory = optimizer.traces if hasattr(optimizer, "traces") else []

    test_program = PromptOptimizationTest(trace_memory=trace_memory)

    print("\n=== Testing Phase ===")
    for ex in test_data:
        result = test_program(instruction=ex["instruction"])
        print(f"[TEST] {ex['instruction']} → Response: {result['response']}")
