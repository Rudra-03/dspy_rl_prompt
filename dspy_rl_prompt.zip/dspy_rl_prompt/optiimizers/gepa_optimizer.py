"""GEPA (Generalized Evolutionary Prompt Augmentation) Optimizer implementation."""

import random
import numpy as np
from typing import List, Dict, Any, Callable, Optional, Tuple
import json
import copy
from dataclasses import dataclass

@dataclass
class PromptCandidate:
    """Represents a prompt candidate in the evolutionary process."""
    prompt: str
    fitness: float
    generation: int
    parent_ids: List[int]
    mutations: List[str]
    metadata: Dict[str, Any]

class GEPAOptimizer:
    """
    Generalized Evolutionary Prompt Augmentation (GEPA) Optimizer.
    
    Uses evolutionary algorithms to optimize prompts through:
    - Selection of high-performing prompts
    - Crossover between successful prompt patterns
    - Mutation with various prompt modification strategies
    - Fitness evaluation based on task performance
    """
    
    def __init__(self, 
                 population_size: int = 20,
                 mutation_rate: float = 0.3,
                 crossover_rate: float = 0.7,
                 elite_size: int = 5,
                 max_generations: int = 10,
                 fitness_function: Optional[Callable] = None):
        """
        Initialize GEPA optimizer.
        
        Args:
            population_size: Number of prompts in each generation
            mutation_rate: Probability of mutation for each prompt
            crossover_rate: Probability of crossover between prompts
            elite_size: Number of best prompts to preserve each generation
            max_generations: Maximum number of evolutionary generations
            fitness_function: Function to evaluate prompt fitness
        """
        
        self.population_size = population_size
        self.mutation_rate = mutation_rate
        self.crossover_rate = crossover_rate
        self.elite_size = elite_size
        self.max_generations = max_generations
        self.fitness_function = fitness_function or self._default_fitness
        
        # Evolution tracking
        self.current_generation = 0
        self.population = []
        self.fitness_history = []
        self.best_prompts = []
        
        # Mutation strategies
        self.mutation_strategies = [
            self._add_instruction_prefix,
            self._add_context_suffix,
            self._modify_tone,
            self._add_examples,
            self._restructure_format,
            self._add_constraints,
            self._modify_specificity
        ]
        
        # Crossover strategies
        self.crossover_strategies = [
            self._single_point_crossover,
            self._uniform_crossover,
            self._semantic_crossover
        ]
    
    def optimize(self, 
                 base_prompt: str,
                 task_function: Callable,
                 evaluation_data: List[Dict],
                 target_metric: str = "accuracy") -> Dict[str, Any]:
        """
        Optimize a prompt using evolutionary algorithms.
        
        Args:
            base_prompt: Initial prompt to optimize
            task_function: Function that executes the task with a prompt
            evaluation_data: Data to evaluate prompt performance
            target_metric: Metric to optimize for
            
        Returns:
            Dictionary containing optimization results
        """
        
        # Initialize population
        self.population = self._initialize_population(base_prompt)
        
        best_fitness = -float('inf')
        best_prompt = base_prompt
        
        for generation in range(self.max_generations):
            self.current_generation = generation
            
            # Evaluate fitness for all candidates
            fitness_scores = []
            for candidate in self.population:
                fitness = self._evaluate_fitness(
                    candidate, task_function, evaluation_data, target_metric
                )
                candidate.fitness = fitness
                fitness_scores.append(fitness)
            
            # Track best prompt
            current_best_idx = np.argmax(fitness_scores)
            current_best_fitness = fitness_scores[current_best_idx]
            
            if current_best_fitness > best_fitness:
                best_fitness = current_best_fitness
                best_prompt = self.population[current_best_idx].prompt
            
            # Store generation statistics
            self.fitness_history.append({
                'generation': generation,
                'best_fitness': current_best_fitness,
                'average_fitness': np.mean(fitness_scores),
                'fitness_std': np.std(fitness_scores)
            })
            
            # Create next generation
            if generation < self.max_generations - 1:
                self.population = self._create_next_generation()
        
        # Compile results
        optimization_results = {
            'best_prompt': best_prompt,
            'best_fitness': best_fitness,
            'optimization_history': self.fitness_history,
            'final_population': [
                {'prompt': p.prompt, 'fitness': p.fitness} 
                for p in self.population
            ],
            'generations_completed': self.max_generations,
            'improvement_ratio': best_fitness / self.fitness_history[0]['best_fitness'] if self.fitness_history else 1.0
        }
        
        return optimization_results
    
    def _initialize_population(self, base_prompt: str) -> List[PromptCandidate]:
        """Initialize the first generation of prompt candidates."""
        
        population = []
        
        # Add the base prompt
        base_candidate = PromptCandidate(
            prompt=base_prompt,
            fitness=0.0,
            generation=0,
            parent_ids=[],
            mutations=[],
            metadata={'type': 'base'}
        )
        population.append(base_candidate)
        
        # Generate variations of the base prompt
        for i in range(self.population_size - 1):
            # Apply random mutations to create diversity
            mutated_prompt = base_prompt
            mutations_applied = []
            
            # Apply 1-3 random mutations
            num_mutations = random.randint(1, 3)
            for _ in range(num_mutations):
                strategy = random.choice(self.mutation_strategies)
                mutated_prompt, mutation_desc = strategy(mutated_prompt)
                mutations_applied.append(mutation_desc)
            
            candidate = PromptCandidate(
                prompt=mutated_prompt,
                fitness=0.0,
                generation=0,
                parent_ids=[0],  # Base prompt as parent
                mutations=mutations_applied,
                metadata={'type': 'initial_variant'}
            )
            population.append(candidate)
        
        return population
    
    def _create_next_generation(self) -> List[PromptCandidate]:
        """Create the next generation using selection, crossover, and mutation."""
        
        # Sort population by fitness
        self.population.sort(key=lambda x: x.fitness, reverse=True)
        
        next_generation = []
        
        # Elitism: Keep best prompts
        for i in range(min(self.elite_size, len(self.population))):
            elite = copy.deepcopy(self.population[i])
            elite.generation = self.current_generation + 1
            next_generation.append(elite)
        
        # Generate remaining population
        while len(next_generation) < self.population_size:
            # Selection
            parent1 = self._tournament_selection()
            parent2 = self._tournament_selection()
            
            # Crossover
            if random.random() < self.crossover_rate:
                child1, child2 = self._crossover(parent1, parent2)
                children = [child1, child2]
            else:
                children = [copy.deepcopy(parent1), copy.deepcopy(parent2)]
            
            # Mutation
            for child in children:
                if random.random() < self.mutation_rate:
                    child = self._mutate(child)
                
                child.generation = self.current_generation + 1
                next_generation.append(child)
                
                if len(next_generation) >= self.population_size:
                    break
        
        return next_generation[:self.population_size]
    
    def _tournament_selection(self, tournament_size: int = 3) -> PromptCandidate:
        """Select a parent using tournament selection."""
        
        tournament = random.sample(self.population, min(tournament_size, len(self.population)))
        return max(tournament, key=lambda x: x.fitness)
    
    def _crossover(self, parent1: PromptCandidate, parent2: PromptCandidate) -> Tuple[PromptCandidate, PromptCandidate]:
        """Perform crossover between two parents."""
        
        strategy = random.choice(self.crossover_strategies)
        child1_prompt, child2_prompt = strategy(parent1.prompt, parent2.prompt)
        
        child1 = PromptCandidate(
            prompt=child1_prompt,
            fitness=0.0,
            generation=self.current_generation + 1,
            parent_ids=[id(parent1), id(parent2)],
            mutations=[],
            metadata={'type': 'crossover', 'strategy': strategy.__name__}
        )
        
        child2 = PromptCandidate(
            prompt=child2_prompt,
            fitness=0.0,
            generation=self.current_generation + 1,
            parent_ids=[id(parent1), id(parent2)],
            mutations=[],
            metadata={'type': 'crossover', 'strategy': strategy.__name__}
        )
        
        return child1, child2
    
    def _mutate(self, candidate: PromptCandidate) -> PromptCandidate:
        """Apply mutation to a candidate."""
        
        strategy = random.choice(self.mutation_strategies)
        mutated_prompt, mutation_desc = strategy(candidate.prompt)
        
        mutated_candidate = PromptCandidate(
            prompt=mutated_prompt,
            fitness=0.0,
            generation=candidate.generation,
            parent_ids=candidate.parent_ids,
            mutations=candidate.mutations + [mutation_desc],
            metadata=candidate.metadata.copy()
        )
        
        return mutated_candidate
    
    def _evaluate_fitness(self, 
                         candidate: PromptCandidate,
                         task_function: Callable,
                         evaluation_data: List[Dict],
                         target_metric: str) -> float:
        """Evaluate the fitness of a prompt candidate."""
        
        try:
            # Execute task with the candidate prompt
            results = []
            for data_point in evaluation_data:
                result = task_function(candidate.prompt, data_point)
                results.append(result)
            
            # Calculate fitness based on target metric
            fitness = self._calculate_metric(results, target_metric)
            
            return fitness
            
        except Exception as e:
            # Return low fitness for prompts that cause errors
            return 0.0
    
    def _calculate_metric(self, results: List[Dict], metric: str) -> float:
        """Calculate the specified metric from results."""
        
        if not results:
            return 0.0
        
        if metric == "accuracy":
            correct = sum(1 for r in results if r.get('correct', False))
            return correct / len(results)
        
        elif metric == "confidence":
            confidences = [r.get('confidence', 0) for r in results]
            return sum(confidences) / len(confidences)
        
        elif metric == "efficiency":
            times = [r.get('execution_time', float('inf')) for r in results]
            avg_time = sum(times) / len(times)
            return 1.0 / (1.0 + avg_time)  # Lower time = higher fitness
        
        else:
            # Default to overall score
            scores = [r.get('score', 0) for r in results]
            return sum(scores) / len(scores)
    
    def _default_fitness(self, prompt: str, evaluation_data: List[Dict]) -> float:
        """Default fitness function if none provided."""
        # Simple heuristic based on prompt characteristics
        fitness = 0.0
        
        # Reward clarity and specificity
        if len(prompt.split()) > 10:
            fitness += 0.2
        
        # Reward structure
        if any(word in prompt.lower() for word in ['step', 'first', 'then', 'finally']):
            fitness += 0.3
        
        # Reward examples
        if 'example' in prompt.lower() or ':' in prompt:
            fitness += 0.2
        
        # Reward constraints
        if any(word in prompt.lower() for word in ['must', 'should', 'ensure', 'make sure']):
            fitness += 0.3
        
        return min(fitness, 1.0)
    
    # Mutation strategies
    def _add_instruction_prefix(self, prompt: str) -> Tuple[str, str]:
        """Add an instruction prefix to the prompt."""
        prefixes = [
            "Please carefully",
            "Step by step,",
            "Think through this systematically:",
            "Consider the following approach:",
            "To solve this effectively,"
        ]
        prefix = random.choice(prefixes)
        return f"{prefix} {prompt}", f"Added prefix: {prefix}"
    
    def _add_context_suffix(self, prompt: str) -> Tuple[str, str]:
        """Add contextual information as a suffix."""
        suffixes = [
            "Provide detailed reasoning for your answer.",
            "Explain your thought process clearly.",
            "Consider multiple perspectives before responding.",
            "Ensure your response is accurate and complete.",
            "Double-check your work before finalizing."
        ]
        suffix = random.choice(suffixes)
        return f"{prompt} {suffix}", f"Added suffix: {suffix}"
    
    def _modify_tone(self, prompt: str) -> Tuple[str, str]:
        """Modify the tone of the prompt."""
        tone_modifiers = [
            ("Be concise and direct:", "concise"),
            ("Be thorough and comprehensive:", "comprehensive"),
            ("Be creative and innovative:", "creative"),
            ("Be analytical and logical:", "analytical"),
            ("Be practical and actionable:", "practical")
        ]
        modifier, tone = random.choice(tone_modifiers)
        return f"{modifier} {prompt}", f"Modified tone to: {tone}"
    
    def _add_examples(self, prompt: str) -> Tuple[str, str]:
        """Add example indicators to the prompt."""
        example_phrases = [
            "For example:",
            "Here's an illustration:",
            "Consider this case:",
            "As demonstrated by:",
            "To illustrate:"
        ]
        phrase = random.choice(example_phrases)
        return f"{prompt} {phrase} [provide relevant example]", f"Added example indicator: {phrase}"
    
    def _restructure_format(self, prompt: str) -> Tuple[str, str]:
        """Restructure the format of the prompt."""
        formats = [
            ("Format your response as a numbered list.", "numbered list"),
            ("Structure your answer with clear headings.", "headings"),
            ("Organize your response in bullet points.", "bullet points"),
            ("Present your analysis in a table format.", "table"),
            ("Use a question-answer format.", "Q&A format")
        ]
        format_instruction, format_type = random.choice(formats)
        return f"{prompt} {format_instruction}", f"Restructured as: {format_type}"
    
    def _add_constraints(self, prompt: str) -> Tuple[str, str]:
        """Add constraints to the prompt."""
        constraints = [
            ("Limit your response to 200 words.", "word limit"),
            ("Focus only on the most important aspects.", "focus constraint"),
            ("Avoid technical jargon.", "language constraint"),
            ("Provide at least 3 specific points.", "minimum requirements"),
            ("Ensure all claims are supported by evidence.", "evidence requirement")
        ]
        constraint, constraint_type = random.choice(constraints)
        return f"{prompt} {constraint}", f"Added constraint: {constraint_type}"
    
    def _modify_specificity(self, prompt: str) -> Tuple[str, str]:
        """Modify the specificity level of the prompt."""
        specificity_modifiers = [
            ("Be very specific and detailed in your response.", "increased specificity"),
            ("Provide a high-level overview.", "decreased specificity"),
            ("Focus on concrete examples and cases.", "concrete focus"),
            ("Discuss both general principles and specific applications.", "balanced specificity"),
            ("Emphasize practical implementation details.", "implementation focus")
        ]
        modifier, specificity_type = random.choice(specificity_modifiers)
        return f"{prompt} {modifier}", f"Modified specificity: {specificity_type}"
    
    # Crossover strategies
    def _single_point_crossover(self, prompt1: str, prompt2: str) -> Tuple[str, str]:
        """Perform single-point crossover between two prompts."""
        words1 = prompt1.split()
        words2 = prompt2.split()
        
        if len(words1) < 2 or len(words2) < 2:
            return prompt1, prompt2
        
        # Choose crossover points
        point1 = random.randint(1, len(words1) - 1)
        point2 = random.randint(1, len(words2) - 1)
        
        # Create children
        child1 = " ".join(words1[:point1] + words2[point2:])
        child2 = " ".join(words2[:point2] + words1[point1:])
        
        return child1, child2
    
    def _uniform_crossover(self, prompt1: str, prompt2: str) -> Tuple[str, str]:
        """Perform uniform crossover between two prompts."""
        words1 = prompt1.split()
        words2 = prompt2.split()
        
        max_len = max(len(words1), len(words2))
        
        child1_words = []
        child2_words = []
        
        for i in range(max_len):
            if random.random() < 0.5:
                # Take from first parent
                if i < len(words1):
                    child1_words.append(words1[i])
                if i < len(words2):
                    child2_words.append(words2[i])
            else:
                # Take from second parent
                if i < len(words2):
                    child1_words.append(words2[i])
                if i < len(words1):
                    child2_words.append(words1[i])
        
        return " ".join(child1_words), " ".join(child2_words)
    
    def _semantic_crossover(self, prompt1: str, prompt2: str) -> Tuple[str, str]:
        """Perform semantic crossover by combining meaningful parts."""
        # Split prompts into sentences
        sentences1 = [s.strip() for s in prompt1.split('.') if s.strip()]
        sentences2 = [s.strip() for s in prompt2.split('.') if s.strip()]
        
        # Randomly combine sentences
        child1_sentences = []
        child2_sentences = []
        
        all_sentences = sentences1 + sentences2
        random.shuffle(all_sentences)
        
        mid_point = len(all_sentences) // 2
        child1_sentences = all_sentences[:mid_point]
        child2_sentences = all_sentences[mid_point:]
        
        child1 = ". ".join(child1_sentences) + "."
        child2 = ". ".join(child2_sentences) + "."
        
        return child1, child2