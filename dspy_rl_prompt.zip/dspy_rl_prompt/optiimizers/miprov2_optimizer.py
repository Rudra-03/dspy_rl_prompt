"""Miprov2 (Multi-step Instruction Prompt Optimization v2) implementation."""

import numpy as np
from typing import List, Dict, Any, Callable, Optional, Tuple
import json
import copy
from dataclasses import dataclass, field
from collections import defaultdict
import random

@dataclass
class InstructionStep:
    """Represents a single step in a multi-step instruction."""
    step_id: int
    content: str
    step_type: str  # 'reasoning', 'action', 'verification', 'output'
    dependencies: List[int] = field(default_factory=list)
    parameters: Dict[str, Any] = field(default_factory=dict)
    performance_metrics: Dict[str, float] = field(default_factory=dict)

@dataclass
class MultiStepInstruction:
    """Represents a complete multi-step instruction."""
    instruction_id: str
    steps: List[InstructionStep]
    global_context: str
    success_criteria: List[str]
    overall_performance: Dict[str, float] = field(default_factory=dict)
    optimization_history: List[Dict] = field(default_factory=list)

class Miprov2Optimizer:
    """
    Multi-step Instruction Prompt Optimization v2 (Miprov2).
    
    Optimizes complex multi-step instructions by:
    - Decomposing instructions into atomic steps
    - Optimizing individual steps and their dependencies
    - Learning step patterns that lead to success
    - Dynamically adjusting instruction flow based on performance
    """
    
    def __init__(self,
                 max_steps: int = 10,
                 optimization_rounds: int = 5,
                 step_types: Optional[List[str]] = None,
                 learning_rate: float = 0.1,
                 exploration_rate: float = 0.2):
        """
        Initialize Miprov2 optimizer.
        
        Args:
            max_steps: Maximum number of steps in an instruction
            optimization_rounds: Number of optimization iterations
            step_types: Allowed step types for instructions
            learning_rate: Rate of learning from performance feedback
            exploration_rate: Rate of exploring new instruction patterns
        """
        
        self.max_steps = max_steps
        self.optimization_rounds = optimization_rounds
        self.learning_rate = learning_rate
        self.exploration_rate = exploration_rate
        
        # Default step types
        self.step_types = step_types or [
            'reasoning', 'action', 'verification', 'output', 
            'context_gathering', 'analysis', 'synthesis'
        ]
        
        # Learning components
        self.step_performance_history = defaultdict(list)
        self.pattern_success_rates = defaultdict(float)
        self.dependency_effectiveness = defaultdict(float)
        
        # Optimization tracking
        self.optimization_history = []
        self.best_instructions = []
        
        # Step templates and patterns
        self.step_templates = self._initialize_step_templates()
        self.successful_patterns = []
    
    def optimize(self,
                 base_instruction: str,
                 task_function: Callable,
                 evaluation_data: List[Dict],
                 success_criteria: List[str],
                 target_metrics: List[str] = None) -> Dict[str, Any]:
        """
        Optimize a multi-step instruction using Miprov2 algorithm.
        
        Args:
            base_instruction: Initial instruction to optimize
            task_function: Function that executes tasks with instructions
            evaluation_data: Data for evaluating instruction performance
            success_criteria: Criteria for measuring instruction success
            target_metrics: Specific metrics to optimize for
            
        Returns:
            Dictionary containing optimization results
        """
        
        target_metrics = target_metrics or ['accuracy', 'efficiency', 'completeness']
        
        # Decompose base instruction into steps
        current_instruction = self._decompose_instruction(
            base_instruction, success_criteria
        )
        
        best_instruction = copy.deepcopy(current_instruction)
        best_performance = self._evaluate_instruction(
            current_instruction, task_function, evaluation_data, target_metrics
        )
        
        optimization_log = []
        
        for round_num in range(self.optimization_rounds):
            print(f"Miprov2 Optimization Round {round_num + 1}/{self.optimization_rounds}")
            
            # Generate candidate instructions
            candidates = self._generate_candidates(current_instruction)
            
            # Evaluate all candidates
            candidate_performances = []
            for candidate in candidates:
                performance = self._evaluate_instruction(
                    candidate, task_function, evaluation_data, target_metrics
                )
                candidate_performances.append(performance)
            
            # Select best candidate
            best_candidate_idx = self._select_best_candidate(
                candidate_performances, target_metrics
            )
            
            if best_candidate_idx is not None:
                candidate_performance = candidate_performances[best_candidate_idx]
                
                # Check if this candidate is better than current best
                if self._is_better_performance(candidate_performance, best_performance, target_metrics):
                    best_instruction = copy.deepcopy(candidates[best_candidate_idx])
                    best_performance = candidate_performance
                    current_instruction = copy.deepcopy(best_instruction)
                
                # Update learning components
                self._update_learning_components(
                    candidates[best_candidate_idx], candidate_performance
                )
            
            # Log optimization round
            round_log = {
                'round': round_num + 1,
                'best_performance': best_performance,
                'candidates_evaluated': len(candidates),
                'improvement_found': best_candidate_idx is not None
            }
            optimization_log.append(round_log)
        
        # Compile final results
        optimization_results = {
            'optimized_instruction': self._compile_instruction(best_instruction),
            'instruction_steps': [
                {
                    'step_id': step.step_id,
                    'content': step.content,
                    'type': step.step_type,
                    'dependencies': step.dependencies
                }
                for step in best_instruction.steps
            ],
            'performance_metrics': best_performance,
            'optimization_log': optimization_log,
            'learned_patterns': self._extract_learned_patterns(),
            'improvement_summary': self._calculate_improvement_summary(
                self._evaluate_instruction(
                    self._decompose_instruction(base_instruction, success_criteria),
                    task_function, evaluation_data, target_metrics
                ),
                best_performance
            )
        }
        
        return optimization_results
    
    def _decompose_instruction(self, 
                              instruction: str, 
                              success_criteria: List[str]) -> MultiStepInstruction:
        """Decompose a single instruction into multiple steps."""
        
        # Simple decomposition based on sentence structure and keywords
        sentences = [s.strip() for s in instruction.split('.') if s.strip()]
        
        steps = []
        step_id = 0
        
        for sentence in sentences:
            # Determine step type based on content
            step_type = self._classify_step_type(sentence)
            
            # Create step
            step = InstructionStep(
                step_id=step_id,
                content=sentence,
                step_type=step_type,
                dependencies=self._infer_dependencies(step_id, steps),
                parameters=self._extract_parameters(sentence)
            )
            
            steps.append(step)
            step_id += 1
        
        # Add verification and output steps if not present
        if not any(step.step_type == 'verification' for step in steps):
            verification_step = InstructionStep(
                step_id=step_id,
                content="Verify that the solution meets all requirements",
                step_type='verification',
                dependencies=list(range(step_id))
            )
            steps.append(verification_step)
            step_id += 1
        
        if not any(step.step_type == 'output' for step in steps):
            output_step = InstructionStep(
                step_id=step_id,
                content="Provide the final answer in the requested format",
                step_type='output',
                dependencies=list(range(step_id))
            )
            steps.append(output_step)
        
        return MultiStepInstruction(
            instruction_id=f"inst_{random.randint(1000, 9999)}",
            steps=steps,
            global_context=instruction,
            success_criteria=success_criteria
        )
    
    def _classify_step_type(self, content: str) -> str:
        """Classify the type of an instruction step based on its content."""
        
        content_lower = content.lower()
        
        # Keywords for different step types
        type_keywords = {
            'reasoning': ['think', 'consider', 'analyze', 'evaluate', 'reason'],
            'action': ['do', 'perform', 'execute', 'run', 'apply', 'use'],
            'verification': ['check', 'verify', 'validate', 'confirm', 'ensure'],
            'output': ['provide', 'return', 'output', 'present', 'show'],
            'context_gathering': ['gather', 'collect', 'find', 'search', 'identify'],
            'analysis': ['examine', 'study', 'investigate', 'assess', 'review'],
            'synthesis': ['combine', 'integrate', 'merge', 'synthesize', 'compile']
        }
        
        # Score each type based on keyword presence
        type_scores = {}
        for step_type, keywords in type_keywords.items():
            score = sum(1 for keyword in keywords if keyword in content_lower)
            type_scores[step_type] = score
        
        # Return type with highest score, default to 'reasoning'
        if max(type_scores.values()) > 0:
            return max(type_scores, key=type_scores.get)
        else:
            return 'reasoning'
    
    def _infer_dependencies(self, current_step_id: int, existing_steps: List[InstructionStep]) -> List[int]:
        """Infer dependencies for a step based on existing steps."""
        
        if current_step_id == 0:
            return []
        
        # Simple heuristic: each step depends on the previous step
        # In practice, this would use more sophisticated dependency analysis
        dependencies = []
        
        if existing_steps:
            # Most steps depend on the immediately previous step
            dependencies.append(current_step_id - 1)
            
            # Verification and output steps depend on all previous steps
            if current_step_id > 2:
                dependencies.extend(range(max(0, current_step_id - 3), current_step_id - 1))
        
        return dependencies
    
    def _extract_parameters(self, content: str) -> Dict[str, Any]:
        """Extract parameters from step content."""
        
        parameters = {}
        
        # Extract numerical parameters
        import re
        numbers = re.findall(r'\d+', content)
        if numbers:
            parameters['numeric_values'] = [int(n) for n in numbers]
        
        # Extract quoted strings as parameters
        quoted_strings = re.findall(r'"([^"]*)"', content)
        if quoted_strings:
            parameters['quoted_text'] = quoted_strings
        
        # Extract constraint words
        constraint_words = ['must', 'should', 'ensure', 'always', 'never']
        found_constraints = [word for word in constraint_words if word in content.lower()]
        if found_constraints:
            parameters['constraints'] = found_constraints
        
        return parameters
    
    def _generate_candidates(self, base_instruction: MultiStepInstruction) -> List[MultiStepInstruction]:
        """Generate candidate instructions for optimization."""
        
        candidates = []
        
        # Strategy 1: Modify individual steps
        for step_idx in range(len(base_instruction.steps)):
            candidate = copy.deepcopy(base_instruction)
            candidate.steps[step_idx] = self._optimize_step(candidate.steps[step_idx])
            candidates.append(candidate)
        
        # Strategy 2: Reorder steps (respecting dependencies)
        reordered_candidate = self._reorder_steps(copy.deepcopy(base_instruction))
        if reordered_candidate:
            candidates.append(reordered_candidate)
        
        # Strategy 3: Add new steps
        if len(base_instruction.steps) < self.max_steps:
            augmented_candidate = self._add_step(copy.deepcopy(base_instruction))
            if augmented_candidate:
                candidates.append(augmented_candidate)
        
        # Strategy 4: Remove redundant steps
        if len(base_instruction.steps) > 2:
            reduced_candidate = self._remove_step(copy.deepcopy(base_instruction))
            if reduced_candidate:
                candidates.append(reduced_candidate)
        
        # Strategy 5: Apply learned patterns
        pattern_candidates = self._apply_learned_patterns(copy.deepcopy(base_instruction))
        candidates.extend(pattern_candidates)
        
        return candidates
    
    def _optimize_step(self, step: InstructionStep) -> InstructionStep:
        """Optimize an individual step."""
        
        optimized_step = copy.deepcopy(step)
        
        # Apply step-specific optimizations based on type
        if step.step_type == 'reasoning':
            optimized_step.content = self._enhance_reasoning_step(step.content)
        elif step.step_type == 'action':
            optimized_step.content = self._enhance_action_step(step.content)
        elif step.step_type == 'verification':
            optimized_step.content = self._enhance_verification_step(step.content)
        elif step.step_type == 'output':
            optimized_step.content = self._enhance_output_step(step.content)
        
        return optimized_step
    
    def _enhance_reasoning_step(self, content: str) -> str:
        """Enhance a reasoning step."""
        enhancements = [
            "Carefully consider",
            "Think step by step about",
            "Analyze thoroughly",
            "Systematically evaluate"
        ]
        
        if not any(enhancement in content for enhancement in enhancements):
            enhancement = random.choice(enhancements)
            return f"{enhancement} {content.lower()}"
        
        return content
    
    def _enhance_action_step(self, content: str) -> str:
        """Enhance an action step."""
        enhancements = [
            "Precisely execute",
            "Carefully perform",
            "Systematically apply",
            "Methodically implement"
        ]
        
        if not any(enhancement in content for enhancement in enhancements):
            enhancement = random.choice(enhancements)
            return f"{enhancement} {content.lower()}"
        
        return content
    
    def _enhance_verification_step(self, content: str) -> str:
        """Enhance a verification step."""
        enhancements = [
            "Double-check that",
            "Verify carefully that",
            "Confirm thoroughly that",
            "Validate completely that"
        ]
        
        if not any(enhancement in content for enhancement in enhancements):
            enhancement = random.choice(enhancements)
            return f"{enhancement} {content.lower()}"
        
        return content
    
    def _enhance_output_step(self, content: str) -> str:
        """Enhance an output step."""
        enhancements = [
            "Clearly present",
            "Comprehensively provide",
            "Systematically organize and present",
            "Thoroughly document and provide"
        ]
        
        if not any(enhancement in content for enhancement in enhancements):
            enhancement = random.choice(enhancements)
            return f"{enhancement} {content.lower()}"
        
        return content
    
    def _reorder_steps(self, instruction: MultiStepInstruction) -> Optional[MultiStepInstruction]:
        """Reorder steps while respecting dependencies."""
        
        # Simple reordering: try to optimize the sequence
        steps = instruction.steps[:]
        
        # Don't reorder if there are complex dependencies
        if any(len(step.dependencies) > 1 for step in steps):
            return None
        
        # Try swapping adjacent steps that don't have dependencies
        for i in range(len(steps) - 1):
            if (not steps[i+1].dependencies or 
                max(steps[i+1].dependencies, default=-1) < i):
                # Safe to swap
                steps[i], steps[i+1] = steps[i+1], steps[i]
                # Update step IDs
                steps[i].step_id = i
                steps[i+1].step_id = i + 1
                break
        
        instruction.steps = steps
        return instruction
    
    def _add_step(self, instruction: MultiStepInstruction) -> Optional[MultiStepInstruction]:
        """Add a new step to the instruction."""
        
        # Determine where to add the step and what type
        insertion_point = random.randint(1, len(instruction.steps) - 1)
        
        # Choose step type based on context
        step_types_by_position = {
            'early': ['context_gathering', 'reasoning'],
            'middle': ['analysis', 'action'],
            'late': ['verification', 'synthesis']
        }
        
        if insertion_point < len(instruction.steps) // 3:
            position = 'early'
        elif insertion_point < 2 * len(instruction.steps) // 3:
            position = 'middle'
        else:
            position = 'late'
        
        step_type = random.choice(step_types_by_position[position])
        
        # Create new step
        new_step = InstructionStep(
            step_id=insertion_point,
            content=self._generate_step_content(step_type),
            step_type=step_type,
            dependencies=[insertion_point - 1] if insertion_point > 0 else []
        )
        
        # Insert step and update IDs
        instruction.steps.insert(insertion_point, new_step)
        for i, step in enumerate(instruction.steps):
            step.step_id = i
            # Update dependencies
            step.dependencies = [
                dep + 1 if dep >= insertion_point else dep 
                for dep in step.dependencies
            ]
        
        return instruction
    
    def _remove_step(self, instruction: MultiStepInstruction) -> Optional[MultiStepInstruction]:
        """Remove a redundant step from the instruction."""
        
        # Don't remove essential steps (first, last, or steps with many dependencies)
        removable_indices = []
        for i, step in enumerate(instruction.steps):
            if (i != 0 and i != len(instruction.steps) - 1 and
                step.step_type not in ['output', 'verification'] and
                len(step.dependencies) <= 1):
                removable_indices.append(i)
        
        if not removable_indices:
            return None
        
        # Remove a random removable step
        remove_idx = random.choice(removable_indices)
        instruction.steps.pop(remove_idx)
        
        # Update step IDs and dependencies
        for i, step in enumerate(instruction.steps):
            step.step_id = i
            # Update dependencies
            step.dependencies = [
                dep - 1 if dep > remove_idx else dep 
                for dep in step.dependencies if dep != remove_idx
            ]
        
        return instruction
    
    def _apply_learned_patterns(self, instruction: MultiStepInstruction) -> List[MultiStepInstruction]:
        """Apply learned successful patterns to the instruction."""
        
        candidates = []
        
        # Apply each learned pattern
        for pattern in self.successful_patterns[:3]:  # Top 3 patterns
            candidate = copy.deepcopy(instruction)
            
            # Apply pattern modifications
            if 'step_enhancements' in pattern:
                for step_idx, enhancement in pattern['step_enhancements'].items():
                    if step_idx < len(candidate.steps):
                        candidate.steps[step_idx].content = enhancement
            
            if 'additional_steps' in pattern:
                for step_info in pattern['additional_steps']:
                    new_step = InstructionStep(
                        step_id=len(candidate.steps),
                        content=step_info['content'],
                        step_type=step_info['type'],
                        dependencies=step_info.get('dependencies', [])
                    )
                    candidate.steps.append(new_step)
            
            candidates.append(candidate)
        
        return candidates
    
    def _generate_step_content(self, step_type: str) -> str:
        """Generate content for a new step of the given type."""
        
        templates = self.step_templates.get(step_type, [])
        if templates:
            return random.choice(templates)
        else:
            return f"Perform {step_type} operation as needed"
    
    def _evaluate_instruction(self,
                             instruction: MultiStepInstruction,
                             task_function: Callable,
                             evaluation_data: List[Dict],
                             target_metrics: List[str]) -> Dict[str, float]:
        """Evaluate the performance of a multi-step instruction."""
        
        # Compile instruction into executable format
        compiled_instruction = self._compile_instruction(instruction)
        
        # Execute on evaluation data
        results = []
        for data_point in evaluation_data:
            try:
                result = task_function(compiled_instruction, data_point)
                results.append(result)
            except Exception as e:
                # Handle execution errors
                results.append({
                    'error': str(e),
                    'accuracy': 0.0,
                    'efficiency': 0.0,
                    'completeness': 0.0
                })
        
        # Calculate performance metrics
        performance = {}
        for metric in target_metrics:
            if metric == 'accuracy':
                accuracy_scores = [r.get('accuracy', 0) for r in results]
                performance[metric] = sum(accuracy_scores) / len(accuracy_scores)
            
            elif metric == 'efficiency':
                efficiency_scores = [r.get('efficiency', 0) for r in results]
                performance[metric] = sum(efficiency_scores) / len(efficiency_scores)
            
            elif metric == 'completeness':
                completeness_scores = [r.get('completeness', 0) for r in results]
                performance[metric] = sum(completeness_scores) / len(completeness_scores)
            
            else:
                # Default metric calculation
                metric_scores = [r.get(metric, 0) for r in results]
                performance[metric] = sum(metric_scores) / len(metric_scores)
        
        # Add composite score
        performance['composite_score'] = sum(performance.values()) / len(performance)
        
        return performance
    
    def _compile_instruction(self, instruction: MultiStepInstruction) -> str:
        """Compile a multi-step instruction into a single executable instruction."""
        
        compiled_parts = []
        
        # Add global context
        if instruction.global_context:
            compiled_parts.append(f"Context: {instruction.global_context}")
        
        # Add steps in order
        compiled_parts.append("Follow these steps:")
        for i, step in enumerate(instruction.steps, 1):
            compiled_parts.append(f"{i}. {step.content}")
        
        # Add success criteria
        if instruction.success_criteria:
            compiled_parts.append("Success criteria:")
            for criterion in instruction.success_criteria:
                compiled_parts.append(f"- {criterion}")
        
        return "\n".join(compiled_parts)
    
    def _select_best_candidate(self,
                              performances: List[Dict[str, float]],
                              target_metrics: List[str]) -> Optional[int]:
        """Select the best candidate based on performance metrics."""
        
        if not performances:
            return None
        
        # Calculate weighted scores for each candidate
        candidate_scores = []
        for performance in performances:
            # Equal weighting for all target metrics
            score = sum(performance.get(metric, 0) for metric in target_metrics)
            candidate_scores.append(score)
        
        # Return index of best candidate
        if max(candidate_scores) > 0:
            return candidate_scores.index(max(candidate_scores))
        else:
            return None
    
    def _is_better_performance(self,
                              new_performance: Dict[str, float],
                              current_best: Dict[str, float],
                              target_metrics: List[str]) -> bool:
        """Check if new performance is better than current best."""
        
        new_score = sum(new_performance.get(metric, 0) for metric in target_metrics)
        current_score = sum(current_best.get(metric, 0) for metric in target_metrics)
        
        return new_score > current_score
    
    def _update_learning_components(self,
                                   instruction: MultiStepInstruction,
                                   performance: Dict[str, float]):
        """Update learning components based on instruction performance."""
        
        # Update step performance history
        for step in instruction.steps:
            step_key = f"{step.step_type}_{hash(step.content) % 1000}"
            self.step_performance_history[step_key].append(performance.get('composite_score', 0))
        
        # Update pattern success rates
        pattern_key = "_".join([step.step_type for step in instruction.steps])
        current_rate = self.pattern_success_rates[pattern_key]
        new_rate = performance.get('composite_score', 0)
        self.pattern_success_rates[pattern_key] = (
            current_rate * (1 - self.learning_rate) + new_rate * self.learning_rate
        )
        
        # Update successful patterns if performance is good
        if performance.get('composite_score', 0) > 0.7:
            pattern = {
                'step_types': [step.step_type for step in instruction.steps],
                'performance': performance,
                'step_enhancements': {
                    i: step.content for i, step in enumerate(instruction.steps)
                }
            }
            self.successful_patterns.append(pattern)
            
            # Keep only top patterns
            self.successful_patterns.sort(
                key=lambda p: p['performance'].get('composite_score', 0),
                reverse=True
            )
            self.successful_patterns = self.successful_patterns[:10]
    
    def _extract_learned_patterns(self) -> Dict[str, Any]:
        """Extract learned patterns for analysis."""
        
        return {
            'successful_step_patterns': dict(self.pattern_success_rates),
            'high_performing_steps': {
                step_key: np.mean(performances)
                for step_key, performances in self.step_performance_history.items()
                if len(performances) > 0 and np.mean(performances) > 0.6
            },
            'pattern_count': len(self.successful_patterns),
            'optimization_insights': self._generate_optimization_insights()
        }
    
    def _generate_optimization_insights(self) -> List[str]:
        """Generate insights about the optimization process."""
        
        insights = []
        
        # Analyze step type effectiveness
        step_type_performance = defaultdict(list)
        for step_key, performances in self.step_performance_history.items():
            step_type = step_key.split('_')[0]
            step_type_performance[step_type].extend(performances)
        
        for step_type, performances in step_type_performance.items():
            if len(performances) > 2:
                avg_performance = np.mean(performances)
                if avg_performance > 0.7:
                    insights.append(f"Step type '{step_type}' shows high effectiveness (avg: {avg_performance:.2f})")
                elif avg_performance < 0.3:
                    insights.append(f"Step type '{step_type}' may need improvement (avg: {avg_performance:.2f})")
        
        # Analyze pattern effectiveness
        if self.pattern_success_rates:
            best_pattern = max(self.pattern_success_rates, key=self.pattern_success_rates.get)
            best_rate = self.pattern_success_rates[best_pattern]
            insights.append(f"Most successful step pattern: {best_pattern} (rate: {best_rate:.2f})")
        
        return insights
    
    def _calculate_improvement_summary(self,
                                     initial_performance: Dict[str, float],
                                     final_performance: Dict[str, float]) -> Dict[str, Any]:
        """Calculate summary of improvements made during optimization."""
        
        improvements = {}
        
        for metric in initial_performance:
            initial_value = initial_performance[metric]
            final_value = final_performance[metric]
            
            if initial_value > 0:
                improvement_ratio = (final_value - initial_value) / initial_value
                improvements[metric] = {
                    'initial': initial_value,
                    'final': final_value,
                    'improvement_ratio': improvement_ratio,
                    'absolute_improvement': final_value - initial_value
                }
            else:
                improvements[metric] = {
                    'initial': initial_value,
                    'final': final_value,
                    'improvement_ratio': float('inf') if final_value > 0 else 0,
                    'absolute_improvement': final_value
                }
        
        return improvements
    
    def _initialize_step_templates(self) -> Dict[str, List[str]]:
        """Initialize templates for different step types."""
        
        return {
            'reasoning': [
                "Analyze the problem systematically",
                "Consider all relevant factors",
                "Think through the implications carefully",
                "Evaluate different approaches"
            ],
            'action': [
                "Execute the planned approach",
                "Apply the selected method",
                "Implement the solution step by step",
                "Perform the required operations"
            ],
            'verification': [
                "Check the results for accuracy",
                "Verify all requirements are met",
                "Validate the solution completeness",
                "Confirm the approach is correct"
            ],
            'output': [
                "Present the final results clearly",
                "Provide the answer in the requested format",
                "Summarize the key findings",
                "Document the complete solution"
            ],
            'context_gathering': [
                "Gather all relevant information",
                "Identify key constraints and requirements",
                "Collect necessary background data",
                "Understand the problem context fully"
            ],
            'analysis': [
                "Examine the data thoroughly",
                "Identify patterns and relationships",
                "Assess the significance of findings",
                "Evaluate the evidence systematically"
            ],
            'synthesis': [
                "Combine insights from different sources",
                "Integrate findings into a coherent solution",
                "Merge different approaches effectively",
                "Synthesize information into actionable results"
            ]
        }