"""DSPy configuration and setup utilities."""

import os
from typing import Dict, Any, Optional
import dspy
from dotenv import load_dotenv

load_dotenv()

class DSPyConfig:
    """Configuration manager for DSPy models and settings."""
    
    def __init__(self):
        self.models = {}
        self.current_model = None
        
    def setup_openai_model(self, model_name: str = "gpt-4", api_key: Optional[str] = None):
        """Setup OpenAI model for DSPy."""
        api_key = api_key or os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OpenAI API key not provided")
            
        model = dspy.OpenAI(
            model=model_name,
            api_key=api_key,
            max_tokens=2048,
            temperature=0.7
        )
        self.models["openai"] = model
        return model
    
    def setup_anthropic_model(self, model_name: str = "claude-3-sonnet-20240229", api_key: Optional[str] = None):
        """Setup Anthropic model for DSPy."""
        api_key = api_key or os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            raise ValueError("Anthropic API key not provided")
            
        model = dspy.Claude(
            model=model_name,
            api_key=api_key,
            max_tokens=2048,
            temperature=0.7
        )
        self.models["anthropic"] = model
        return model
    
    def set_default_model(self, model_key: str):
        """Set the default model for DSPy operations."""
        if model_key not in self.models:
            raise ValueError(f"Model {model_key} not configured")
        
        self.current_model = self.models[model_key]
        dspy.settings.configure(lm=self.current_model)
        
    def get_model(self, model_key: str):
        """Get a specific model instance."""
        return self.models.get(model_key)

# Global configuration instance
config = DSPyConfig()

def initialize_dspy(instructor_model: str = "openai", responder_model: str = "openai"):
    """Initialize DSPy with specified models."""
    try:
        # Setup models
        if instructor_model == "openai" or responder_model == "openai":
            config.setup_openai_model()
        if instructor_model == "anthropic" or responder_model == "anthropic":
            config.setup_anthropic_model()
            
        # Set default model
        config.set_default_model(instructor_model)
        
        print(f"DSPy initialized with instructor: {instructor_model}, responder: {responder_model}")
        return config
        
    except Exception as e:
        print(f"Failed to initialize DSPy: {e}")
        # Fallback to dummy model for testing
        dummy_model = dspy.DummyLM([
            "This is a test response from the instructor model.",
            "This is a test response from the responder model."
        ])
        config.models["dummy"] = dummy_model
        config.set_default_model("dummy")
        print("Using dummy model for testing")
        return config