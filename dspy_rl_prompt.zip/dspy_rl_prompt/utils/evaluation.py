"""Evaluation utilities for the DSPy RL optimization pipeline."""

import numpy as np
from typing import Dict, List, Any, Optional, Callable
import json
import time
from dataclasses import dataclass
from collections import defaultdict

@dataclass
class EvaluationMetrics:
    """Container for evaluation metrics."""
    accuracy: float
    efficiency: float
    completeness: float
    confidence: float
    consistency: float
    overall_score: float
    
    def to_dict(self) -> Dict[str, float]:
        """Convert to dictionary format."""
        return {
            'accuracy': self.accuracy,
            'efficiency': self.efficiency,
            'completeness': self.completeness,
            'confidence': self.confidence,
            'consistency': self.consistency,
            'overall_score': self.overall_score
        }

class PerformanceEvaluator:
    """Comprehensive performance evaluator for instruction optimization."""
    
    def __init__(self, 
                 weights: Optional[Dict[str, float]] = None,
                 similarity_threshold: float = 0.7):
        """
        Initialize performance evaluator.
        
        Args:
            weights: Weights for different metrics in overall score calculation
            similarity_threshold: Threshold for considering outputs as similar
        """
        
        self.weights = weights or {
            'accuracy': 0.4,
            'efficiency': 0.2,
            'completeness': 0.2,
            'confidence': 0.1,
            'consistency': 0.1
        }
        
        self.similarity_threshold = similarity_threshold
        
        # Evaluation history
        self.evaluation_history = []
        self.performance_trends = defaultdict(list)
    
    def evaluate_instruction_performance(self,
                                       instruction: str,
                                       results: List[Dict[str, Any]],
                                       expected_outputs: List[str],
                                       execution_times: List[float]) -> EvaluationMetrics:
        """
        Evaluate instruction performance comprehensively.
        
        Args:
            instruction: The instruction being evaluated
            results: List of execution results
            expected_outputs: List of expected outputs for comparison
            execution_times: List of execution times for each result
            
        Returns:
            EvaluationMetrics object containing all performance metrics
        """
        
        if not results or len(results) != len(expected_outputs):
            return EvaluationMetrics(0, 0, 0, 0, 0, 0)
        
        # Calculate individual metrics
        accuracy = self._calculate_accuracy(results, expected_outputs)
        efficiency = self._calculate_efficiency(execution_times, results)
        completeness = self._calculate_completeness(results, expected_outputs)
        confidence = self._calculate_confidence(results)
        consistency = self._calculate_consistency(results)
        
        # Calculate overall score
        overall_score = (
            accuracy * self.weights['accuracy'] +
            efficiency * self.weights['efficiency'] +
            completeness * self.weights['completeness'] +
            confidence * self.weights['confidence'] +
            consistency * self.weights['consistency']
        )
        
        metrics = EvaluationMetrics(
            accuracy=accuracy,
            efficiency=efficiency,
            completeness=completeness,
            confidence=confidence,
            consistency=consistency,
            overall_score=overall_score
        )
        
        # Store in history
        evaluation_record = {
            'instruction': instruction,
            'metrics': metrics.to_dict(),
            'timestamp': time.time(),
            'result_count': len(results)
        }
        self.evaluation_history.append(evaluation_record)
        
        # Update trends
        for metric_name, value in metrics.to_dict().items():
            self.performance_trends[metric_name].append(value)
        
        return metrics
    
    def _calculate_accuracy(self, results: List[Dict], expected_outputs: List[str]) -> float:
        """Calculate accuracy metric based on output similarity."""
        
        if not results or not expected_outputs:
            return 0.0
        
        accuracy_scores = []
        
        for result, expected in zip(results, expected_outputs):
            actual_output = result.get('response', '').strip().lower()
            expected_output = expected.strip().lower()
            
            if not actual_output:
                accuracy_scores.append(0.0)
                continue
            
            # Exact match
            if actual_output == expected_output:
                accuracy_scores.append(1.0)
            # Substring match
            elif expected_output in actual_output or actual_output in expected_output:
                accuracy_scores.append(0.8)
            # Word overlap similarity
            else:
                similarity = self._calculate_text_similarity(actual_output, expected_output)
                accuracy_scores.append(similarity)
        
        return sum(accuracy_scores) / len(accuracy_scores)
    
    def _calculate_efficiency(self, execution_times: List[float], results: List[Dict]) -> float:
        """Calculate efficiency metric based on execution time and output quality."""
        
        if not execution_times or not results:
            return 0.0
        
        # Normalize execution times (lower is better)
        max_reasonable_time = 10.0  # 10 seconds as reasonable upper bound
        time_efficiency = []
        
        for exec_time in execution_times:
            if exec_time <= 0:
                time_efficiency.append(0.0)
            else:
                normalized_time = min(exec_time / max_reasonable_time, 1.0)
                efficiency = 1.0 - normalized_time
                time_efficiency.append(max(efficiency, 0.0))
        
        # Consider output length efficiency (not too short, not too verbose)
        length_efficiency = []
        for result in results:
            output_length = len(result.get('response', ''))
            if 10 <= output_length <= 500:  # Reasonable length range
                length_efficiency.append(1.0)
            elif output_length < 10:
                length_efficiency.append(output_length / 10.0)
            else:
                length_efficiency.append(max(0.2, 1.0 - (output_length - 500) / 1000))
        
        # Combine time and length efficiency
        combined_efficiency = []
        for time_eff, length_eff in zip(time_efficiency, length_efficiency):
            combined_efficiency.append((time_eff + length_eff) / 2)
        
        return sum(combined_efficiency) / len(combined_efficiency)
    
    def _calculate_completeness(self, results: List[Dict], expected_outputs: List[str]) -> float:
        """Calculate completeness metric based on information coverage."""
        
        if not results or not expected_outputs:
            return 0.0
        
        completeness_scores = []
        
        for result, expected in zip(results, expected_outputs):
            actual_output = result.get('response', '').strip()
            expected_output = expected.strip()
            
            if not actual_output:
                completeness_scores.append(0.0)
                continue
            
            # Check if all key information from expected output is covered
            expected_words = set(expected_output.lower().split())
            actual_words = set(actual_output.lower().split())
            
            if not expected_words:
                completeness_scores.append(1.0)
                continue
            
            # Calculate coverage of expected information
            coverage = len(expected_words.intersection(actual_words)) / len(expected_words)
            
            # Bonus for additional relevant information (up to a point)
            additional_info = len(actual_words - expected_words)
            bonus = min(additional_info / len(expected_words), 0.2)
            
            completeness = min(coverage + bonus, 1.0)
            completeness_scores.append(completeness)
        
        return sum(completeness_scores) / len(completeness_scores)
    
    def _calculate_confidence(self, results: List[Dict]) -> float:
        """Calculate confidence metric based on model confidence and output quality indicators."""
        
        if not results:
            return 0.0
        
        confidence_scores = []
        
        for result in results:
            # Use explicit confidence if available
            explicit_confidence = result.get('confidence', None)
            if explicit_confidence is not None:
                confidence_scores.append(float(explicit_confidence))
                continue
            
            # Estimate confidence from output characteristics
            output = result.get('response', '')
            
            # Factors that indicate confidence
            confidence_indicators = 0.0
            
            # Length (not too short, suggesting thoughtful response)
            if len(output) > 20:
                confidence_indicators += 0.3
            
            # Presence of specific details
            if any(char.isdigit() for char in output):
                confidence_indicators += 0.2
            
            # Structured response
            if any(indicator in output for indicator in ['.', ':', '-', '1.', '2.']):
                confidence_indicators += 0.2
            
            # Definitive language vs uncertain language
            definitive_words = ['is', 'are', 'will', 'must', 'always', 'never']
            uncertain_words = ['maybe', 'perhaps', 'might', 'could', 'possibly']
            
            definitive_count = sum(1 for word in definitive_words if word in output.lower())
            uncertain_count = sum(1 for word in uncertain_words if word in output.lower())
            
            if definitive_count > uncertain_count:
                confidence_indicators += 0.3
            elif uncertain_count > definitive_count:
                confidence_indicators -= 0.2
            
            confidence_scores.append(max(0.0, min(1.0, confidence_indicators)))
        
        return sum(confidence_scores) / len(confidence_scores)
    
    def _calculate_consistency(self, results: List[Dict]) -> float:
        """Calculate consistency metric based on output similarity across similar inputs."""
        
        if len(results) < 2:
            return 1.0  # Perfect consistency with single result
        
        # Group similar inputs and check output consistency
        outputs = [result.get('response', '') for result in results]
        
        # Calculate pairwise similarities
        similarities = []
        for i in range(len(outputs)):
            for j in range(i + 1, len(outputs)):
                similarity = self._calculate_text_similarity(outputs[i], outputs[j])
                similarities.append(similarity)
        
        if not similarities:
            return 1.0
        
        # Consistency is the average similarity
        # High similarity indicates consistent responses
        return sum(similarities) / len(similarities)
    
    def _calculate_text_similarity(self, text1: str, text2: str) -> float:
        """Calculate similarity between two texts using Jaccard similarity."""
        
        if not text1 and not text2:
            return 1.0
        if not text1 or not text2:
            return 0.0
        
        # Tokenize and normalize
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        
        # Jaccard similarity
        intersection = len(words1.intersection(words2))
        union = len(words1.union(words2))
        
        return intersection / union if union > 0 else 0.0
    
    def get_performance_trends(self, metric: str, window_size: int = 10) -> Dict[str, Any]:
        """Get performance trends for a specific metric."""
        
        if metric not in self.performance_trends:
            return {'error': f'Metric {metric} not found'}
        
        values = self.performance_trends[metric]
        
        if len(values) < 2:
            return {'trend': 'insufficient_data', 'values': values}
        
        # Calculate trend over recent window
        recent_values = values[-window_size:] if len(values) >= window_size else values
        
        # Simple linear trend
        x = list(range(len(recent_values)))
        y = recent_values
        
        if len(x) > 1:
            # Calculate slope
            n = len(x)
            slope = (n * sum(x[i] * y[i] for i in range(n)) - sum(x) * sum(y)) / (n * sum(x[i]**2 for i in range(n)) - sum(x)**2)
            
            trend_direction = 'improving' if slope > 0.01 else 'declining' if slope < -0.01 else 'stable'
        else:
            slope = 0
            trend_direction = 'stable'
        
        return {
            'trend': trend_direction,
            'slope': slope,
            'recent_values': recent_values,
            'average': sum(recent_values) / len(recent_values),
            'latest': recent_values[-1] if recent_values else 0
        }
    
    def compare_instructions(self, 
                           instruction1: str, 
                           instruction2: str,
                           evaluation_data: List[Dict]) -> Dict[str, Any]:
        """Compare performance between two instructions."""
        
        comparison = {
            'instruction1': instruction1,
            'instruction2': instruction2,
            'metrics_comparison': {},
            'winner': None,
            'improvement_areas': []
        }
        
        # This would require actual execution - simplified for demonstration
        # In practice, you would execute both instructions and compare results
        
        # Placeholder comparison logic
        comparison['winner'] = 'instruction1'  # Simplified
        comparison['metrics_comparison'] = {
            'accuracy': {'instruction1': 0.8, 'instruction2': 0.75, 'difference': 0.05},
            'efficiency': {'instruction1': 0.7, 'instruction2': 0.8, 'difference': -0.1}
        }
        
        return comparison
    
    def generate_performance_report(self) -> Dict[str, Any]:
        """Generate comprehensive performance report."""
        
        if not self.evaluation_history:
            return {'message': 'No evaluation history available'}
        
        report = {
            'summary': {
                'total_evaluations': len(self.evaluation_history),
                'evaluation_period': {
                    'start': self.evaluation_history[0]['timestamp'],
                    'end': self.evaluation_history[-1]['timestamp']
                }
            },
            'performance_statistics': {},
            'trends': {},
            'recommendations': []
        }
        
        # Calculate statistics for each metric
        for metric in ['accuracy', 'efficiency', 'completeness', 'confidence', 'consistency', 'overall_score']:
            values = [eval_record['metrics'][metric] for eval_record in self.evaluation_history]
            
            report['performance_statistics'][metric] = {
                'mean': sum(values) / len(values),
                'min': min(values),
                'max': max(values),
                'std': (sum((v - sum(values)/len(values))**2 for v in values) / len(values))**0.5,
                'latest': values[-1]
            }
            
            # Get trends
            report['trends'][metric] = self.get_performance_trends(metric)
        
        # Generate recommendations
        report['recommendations'] = self._generate_recommendations(report)
        
        return report
    
    def _generate_recommendations(self, report: Dict) -> List[str]:
        """Generate optimization recommendations based on performance analysis."""
        
        recommendations = []
        
        stats = report.get('performance_statistics', {})
        trends = report.get('trends', {})
        
        # Accuracy recommendations
        if stats.get('accuracy', {}).get('mean', 0) < 0.7:
            recommendations.append("Consider improving instruction clarity and specificity to boost accuracy")
        
        # Efficiency recommendations
        if stats.get('efficiency', {}).get('mean', 0) < 0.6:
            recommendations.append("Focus on optimizing instruction length and complexity for better efficiency")
        
        # Trend-based recommendations
        for metric, trend_info in trends.items():
            if trend_info.get('trend') == 'declining':
                recommendations.append(f"Address declining {metric} trend through targeted optimization")
        
        # Consistency recommendations
        if stats.get('consistency', {}).get('mean', 0) < 0.7:
            recommendations.append("Improve instruction consistency to reduce output variability")
        
        return recommendations

# Utility functions for evaluation
def calculate_improvement_ratio(before_metrics: Dict[str, float], 
                              after_metrics: Dict[str, float]) -> Dict[str, float]:
    """Calculate improvement ratios between before and after metrics."""
    
    improvements = {}
    
    for metric in before_metrics:
        if metric in after_metrics:
            before_value = before_metrics[metric]
            after_value = after_metrics[metric]
            
            if before_value > 0:
                improvement = (after_value - before_value) / before_value
            else:
                improvement = after_value  # If before was 0, improvement is just the after value
            
            improvements[metric] = improvement
    
    return improvements

def aggregate_evaluation_results(results_list: List[EvaluationMetrics]) -> EvaluationMetrics:
    """Aggregate multiple evaluation results into a single metrics object."""
    
    if not results_list:
        return EvaluationMetrics(0, 0, 0, 0, 0, 0)
    
    metrics_dict = {
        'accuracy': sum(r.accuracy for r in results_list) / len(results_list),
        'efficiency': sum(r.efficiency for r in results_list) / len(results_list),
        'completeness': sum(r.completeness for r in results_list) / len(results_list),
        'confidence': sum(r.confidence for r in results_list) / len(results_list),
        'consistency': sum(r.consistency for r in results_list) / len(results_list),
    }
    
    # Recalculate overall score
    weights = {'accuracy': 0.4, 'efficiency': 0.2, 'completeness': 0.2, 'confidence': 0.1, 'consistency': 0.1}
    overall_score = sum(metrics_dict[metric] * weights[metric] for metric in weights)
    metrics_dict['overall_score'] = overall_score
    
    return EvaluationMetrics(**metrics_dict)