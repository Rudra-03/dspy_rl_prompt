"""DSPy module for task execution and response generation."""

import dspy
from typing import Dict, List, Optional, Any
import json
import time
from signatures.instruction_signatures import TaskExecution, MultiStepReasoning

class ResponderModule(dspy.Module):
    """DSPy module that executes tasks based on generated instructions."""
    
    def __init__(self, model_config: Optional[Dict] = None):
        super().__init__()
        
        # Initialize DSPy predictors
        self.task_executor = dspy.Predict(TaskExecution)
        self.multi_step_reasoner = dspy.Predict(MultiStepReasoning)
        
        # Execution history and performance tracking
        self.execution_history = []
        self.tool_usage_stats = {}
        
        # Configuration
        self.config = model_config or {}
        self.available_tools = self.config.get('available_tools', {})
        self.max_history_length = self.config.get('max_history_length', 50)
        
    def forward(self, 
                instruction: str, 
                task_input: str,
                tools_available: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Execute a task based on the given instruction.
        
        Args:
            instruction: The instruction to follow
            task_input: Input data or query for the task
            tools_available: Available tools and their descriptions
            
        Returns:
            Dictionary containing execution results and metadata
        """
        
        start_time = time.time()
        
        # Prepare tools description
        tools_str = self._format_tools(tools_available or self.available_tools)
        
        # Execute task
        result = self.task_executor(
            instruction=instruction,
            task_input=task_input,
            tools_available=tools_str
        )
        
        execution_time = time.time() - start_time
        
        # Process tool usage
        tool_usage = self._parse_tool_usage(result.tool_usage or "")
        
        # Create execution record
        execution_record = {
            'instruction': instruction,
            'task_input': task_input,
            'response': result.response,
            'tool_usage': tool_usage,
            'confidence': result.confidence,
            'execution_time': execution_time,
            'timestamp': self._get_timestamp()
        }
        
        # Store in history
        self.execution_history.append(execution_record)
        
        # Update tool usage statistics
        self._update_tool_stats(tool_usage)
        
        # Trim history if needed
        if len(self.execution_history) > self.max_history_length:
            self.execution_history = self.execution_history[-self.max_history_length:]
        
        return {
            'response': result.response,
            'confidence': result.confidence,
            'tool_usage': tool_usage,
            'execution_time': execution_time,
            'execution_id': len(self.execution_history) - 1,
            'metadata': execution_record
        }
    
    def execute_multi_step(self, 
                          complex_query: str,
                          instruction_context: str,
                          tools_available: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Execute complex multi-step reasoning tasks.
        
        Args:
            complex_query: Complex query requiring multi-step reasoning
            instruction_context: Context and instructions for reasoning
            tools_available: Available tools for the task
            
        Returns:
            Dictionary containing multi-step execution results
        """
        
        start_time = time.time()
        
        # Prepare tools description
        tools_str = self._format_tools(tools_available or self.available_tools)
        
        # Execute multi-step reasoning
        result = self.multi_step_reasoner(
            complex_query=complex_query,
            available_tools=tools_str,
            instruction_context=instruction_context
        )
        
        execution_time = time.time() - start_time
        
        # Parse reasoning steps and tool sequence
        reasoning_steps = self._parse_reasoning_steps(result.reasoning_steps)
        tool_sequence = self._parse_tool_sequence(result.tool_sequence)
        confidence_breakdown = self._parse_confidence_breakdown(result.confidence_breakdown)
        
        # Create execution record
        execution_record = {
            'complex_query': complex_query,
            'instruction_context': instruction_context,
            'reasoning_steps': reasoning_steps,
            'tool_sequence': tool_sequence,
            'final_answer': result.final_answer,
            'confidence_breakdown': confidence_breakdown,
            'execution_time': execution_time,
            'timestamp': self._get_timestamp()
        }
        
        # Store in history
        self.execution_history.append(execution_record)
        
        return {
            'final_answer': result.final_answer,
            'reasoning_steps': reasoning_steps,
            'tool_sequence': tool_sequence,
            'confidence_breakdown': confidence_breakdown,
            'execution_time': execution_time,
            'execution_id': len(self.execution_history) - 1,
            'metadata': execution_record
        }
    
    def _format_tools(self, tools: Dict) -> str:
        """Format tools dictionary into a string description."""
        
        if not tools:
            return "No tools available."
        
        tool_descriptions = []
        for tool_name, tool_info in tools.items():
            description = tool_info.get('description', 'No description available')
            parameters = tool_info.get('parameters', [])
            
            tool_desc = f"- {tool_name}: {description}"
            if parameters:
                param_str = ", ".join(parameters)
                tool_desc += f" (Parameters: {param_str})"
            
            tool_descriptions.append(tool_desc)
        
        return "\n".join(tool_descriptions)
    
    def _parse_tool_usage(self, tool_usage_str: str) -> List[Dict]:
        """Parse tool usage string into structured format."""
        
        if not tool_usage_str or tool_usage_str.strip() == "":
            return []
        
        # Simple parsing - in practice, this would be more sophisticated
        tools_used = []
        lines = tool_usage_str.split('\n')
        
        for line in lines:
            line = line.strip()
            if line and ':' in line:
                parts = line.split(':', 1)
                if len(parts) == 2:
                    tool_name = parts[0].strip()
                    usage_desc = parts[1].strip()
                    tools_used.append({
                        'tool': tool_name,
                        'usage': usage_desc
                    })
        
        return tools_used
    
    def _parse_reasoning_steps(self, reasoning_str: str) -> List[str]:
        """Parse reasoning steps string into list."""
        
        if not reasoning_str:
            return []
        
        # Split by common step indicators
        steps = []
        lines = reasoning_str.split('\n')
        
        current_step = ""
        for line in lines:
            line = line.strip()
            if line.startswith(('1.', '2.', '3.', '4.', '5.', 'Step', '-')):
                if current_step:
                    steps.append(current_step.strip())
                current_step = line
            else:
                current_step += " " + line
        
        if current_step:
            steps.append(current_step.strip())
        
        return steps
    
    def _parse_tool_sequence(self, tool_sequence_str: str) -> List[Dict]:
        """Parse tool sequence string into structured format."""
        
        if not tool_sequence_str:
            return []
        
        # Simple parsing for tool sequence
        sequence = []
        lines = tool_sequence_str.split('\n')
        
        for i, line in enumerate(lines):
            line = line.strip()
            if line:
                sequence.append({
                    'step': i + 1,
                    'action': line
                })
        
        return sequence
    
    def _parse_confidence_breakdown(self, confidence_str: str) -> Dict:
        """Parse confidence breakdown string into structured format."""
        
        if not confidence_str:
            return {}
        
        # Simple parsing for confidence scores
        confidence = {}
        lines = confidence_str.split('\n')
        
        for line in lines:
            line = line.strip()
            if ':' in line:
                parts = line.split(':', 1)
                if len(parts) == 2:
                    key = parts[0].strip()
                    try:
                        value = float(parts[1].strip())
                        confidence[key] = value
                    except ValueError:
                        confidence[key] = parts[1].strip()
        
        return confidence
    
    def _update_tool_stats(self, tool_usage: List[Dict]):
        """Update tool usage statistics."""
        
        for usage in tool_usage:
            tool_name = usage.get('tool', 'unknown')
            if tool_name not in self.tool_usage_stats:
                self.tool_usage_stats[tool_name] = {
                    'count': 0,
                    'total_time': 0.0,
                    'success_rate': 0.0
                }
            
            self.tool_usage_stats[tool_name]['count'] += 1
    
    def _get_timestamp(self) -> str:
        """Get current timestamp string."""
        import datetime
        return datetime.datetime.now().isoformat()
    
    def get_execution_statistics(self) -> Dict[str, Any]:
        """Get statistics about task execution performance."""
        
        if not self.execution_history:
            return {"message": "No execution data available"}
        
        # Calculate statistics
        execution_times = [e.get('execution_time', 0) for e in self.execution_history]
        confidences = [e.get('confidence', 0) for e in self.execution_history if 'confidence' in e]
        
        stats = {
            'total_executions': len(self.execution_history),
            'average_execution_time': sum(execution_times) / len(execution_times) if execution_times else 0,
            'average_confidence': sum(confidences) / len(confidences) if confidences else 0,
            'tool_usage_stats': self.tool_usage_stats,
            'most_used_tools': self._get_most_used_tools()
        }
        
        return stats
    
    def _get_most_used_tools(self) -> List[Dict]:
        """Get the most frequently used tools."""
        
        sorted_tools = sorted(
            self.tool_usage_stats.items(),
            key=lambda x: x[1]['count'],
            reverse=True
        )
        
        return [
            {'tool': tool, 'usage_count': stats['count']}
            for tool, stats in sorted_tools[:5]
        ]