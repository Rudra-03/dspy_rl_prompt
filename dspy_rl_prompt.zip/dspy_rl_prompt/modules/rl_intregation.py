"""RL integration module for DSPy-based instruction optimization."""

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from typing import Dict, List, Any, Optional, Tuple, Callable
import json
import random
from collections import deque, defaultdict
from dataclasses import dataclass
import gymnasium as gym
from gymnasium import spaces

@dataclass
class RLState:
    """Represents the state in the RL environment."""
    instruction_history: List[str]
    performance_history: List[float]
    task_context: str
    optimization_markers: Dict[str, Any]
    step_count: int
    
    def to_vector(self) -> np.ndarray:
        """Convert state to numerical vector for RL agent."""
        # Simple encoding - in practice, would use more sophisticated embeddings
        features = []
        
        # Performance statistics
        if self.performance_history:
            features.extend([
                np.mean(self.performance_history),
                np.std(self.performance_history) if len(self.performance_history) > 1 else 0,
                np.max(self.performance_history),
                len(self.performance_history)
            ])
        else:
            features.extend([0, 0, 0, 0])
        
        # Instruction characteristics
        if self.instruction_history:
            last_instruction = self.instruction_history[-1]
            features.extend([
                len(last_instruction.split()),  # Word count
                len(last_instruction),  # Character count
                last_instruction.count('?'),  # Question marks
                last_instruction.count('.'),  # Sentences
            ])
        else:
            features.extend([0, 0, 0, 0])
        
        # Step count
        features.append(self.step_count)
        
        # Optimization markers (simplified)
        features.append(len(self.optimization_markers))
        
        return np.array(features, dtype=np.float32)

@dataclass
class RLAction:
    """Represents an action in the RL environment."""
    action_type: str  # 'modify_prefix', 'modify_suffix', 'change_tone', 'add_constraint'
    parameters: Dict[str, Any]
    
    @classmethod
    def from_vector(cls, action_vector: np.ndarray) -> 'RLAction':
        """Convert numerical action vector to RLAction."""
        action_types = ['modify_prefix', 'modify_suffix', 'change_tone', 'add_constraint', 'restructure']
        
        action_type_idx = int(action_vector[0] * len(action_types))
        action_type_idx = min(action_type_idx, len(action_types) - 1)
        action_type = action_types[action_type_idx]
        
        parameters = {
            'intensity': float(action_vector[1]),
            'style': int(action_vector[2] * 5),  # 0-4 style options
            'specificity': float(action_vector[3])
        }
        
        return cls(action_type=action_type, parameters=parameters)

class InstructionOptimizationEnv(gym.Env):
    """Gymnasium environment for instruction optimization."""
    
    def __init__(self, 
                 instructor_module,
                 responder_module,
                 evaluation_function: Callable,
                 max_steps: int = 20):
        """
        Initialize the RL environment.
        
        Args:
            instructor_module: DSPy instructor module
            responder_module: DSPy responder module
            evaluation_function: Function to evaluate instruction performance
            max_steps: Maximum steps per episode
        """
        
        super().__init__()
        
        self.instructor_module = instructor_module
        self.responder_module = responder_module
        self.evaluation_function = evaluation_function
        self.max_steps = max_steps
        
        # Define action and observation spaces
        self.action_space = spaces.Box(
            low=0.0, high=1.0, shape=(4,), dtype=np.float32
        )
        
        self.observation_space = spaces.Box(
            low=-np.inf, high=np.inf, shape=(10,), dtype=np.float32
        )
        
        # Environment state
        self.current_state = None
        self.current_task = None
        self.step_count = 0
        self.episode_history = []
        
    def reset(self, seed=None, options=None) -> Tuple[np.ndarray, Dict]:
        """Reset the environment for a new episode."""
        
        super().reset(seed=seed)
        
        # Initialize state
        self.current_state = RLState(
            instruction_history=[],
            performance_history=[],
            task_context=options.get('task_context', '') if options else '',
            optimization_markers={},
            step_count=0
        )
        
        self.current_task = options.get('task', {}) if options else {}
        self.step_count = 0
        self.episode_history = []
        
        return self.current_state.to_vector(), {}
    
    def step(self, action: np.ndarray) -> Tuple[np.ndarray, float, bool, bool, Dict]:
        """Execute one step in the environment."""
        
        # Convert action vector to RLAction
        rl_action = RLAction.from_vector(action)
        
        # Apply action to generate new instruction
        new_instruction = self._apply_action(rl_action)
        
        # Evaluate instruction performance
        performance = self._evaluate_instruction(new_instruction)
        
        # Update state
        self.current_state.instruction_history.append(new_instruction)
        self.current_state.performance_history.append(performance)
        self.current_state.step_count += 1
        self.step_count += 1
        
        # Calculate reward
        reward = self._calculate_reward(performance, rl_action)
        
        # Check if episode is done
        done = (self.step_count >= self.max_steps or 
                performance > 0.95 or  # High performance achieved
                len(self.current_state.performance_history) > 5 and 
                all(p < 0.1 for p in self.current_state.performance_history[-3:]))  # Consistent poor performance
        
        # Store step information
        step_info = {
            'action': rl_action,
            'instruction': new_instruction,
            'performance': performance,
            'reward': reward
        }
        self.episode_history.append(step_info)
        
        info = {
            'episode_history': self.episode_history,
            'current_performance': performance,
            'best_performance': max(self.current_state.performance_history) if self.current_state.performance_history else 0
        }
        
        return self.current_state.to_vector(), reward, done, False, info
    
    def _apply_action(self, action: RLAction) -> str:
        """Apply an RL action to generate a new instruction."""
        
        # Get current instruction or use base instruction
        if self.current_state.instruction_history:
            current_instruction = self.current_state.instruction_history[-1]
        else:
            current_instruction = self.current_task.get('base_instruction', 'Solve the given problem.')
        
        # Apply action based on type
        if action.action_type == 'modify_prefix':
            new_instruction = self._modify_prefix(current_instruction, action.parameters)
        elif action.action_type == 'modify_suffix':
            new_instruction = self._modify_suffix(current_instruction, action.parameters)
        elif action.action_type == 'change_tone':
            new_instruction = self._change_tone(current_instruction, action.parameters)
        elif action.action_type == 'add_constraint':
            new_instruction = self._add_constraint(current_instruction, action.parameters)
        elif action.action_type == 'restructure':
            new_instruction = self._restructure_instruction(current_instruction, action.parameters)
        else:
            new_instruction = current_instruction
        
        return new_instruction
    
    def _modify_prefix(self, instruction: str, parameters: Dict) -> str:
        """Modify the prefix of an instruction."""
        
        intensity = parameters.get('intensity', 0.5)
        style = parameters.get('style', 0)
        
        prefixes = [
            ["Please", "Carefully", "Systematically", "Thoroughly", "Precisely"],
            ["Think step by step and", "Consider all aspects and", "Analyze carefully and", "Evaluate systematically and"],
            ["To solve this effectively,", "For the best results,", "To ensure accuracy,", "To optimize performance,"],
            ["Using your expertise,", "Drawing on best practices,", "Applying systematic thinking,", "With careful consideration,"],
            ["Step by step,", "Methodically,", "Systematically,", "Comprehensively,"]
        ]
        
        if style < len(prefixes):
            prefix_options = prefixes[style]
            prefix_idx = int(intensity * len(prefix_options))
            prefix_idx = min(prefix_idx, len(prefix_options) - 1)
            prefix = prefix_options[prefix_idx]
            
            return f"{prefix} {instruction.lower()}"
        
        return instruction
    
    def _modify_suffix(self, instruction: str, parameters: Dict) -> str:
        """Modify the suffix of an instruction."""
        
        intensity = parameters.get('intensity', 0.5)
        style = parameters.get('style', 0)
        
        suffixes = [
            ["Provide a clear answer.", "Be specific and detailed.", "Ensure accuracy.", "Double-check your work."],
            ["Explain your reasoning.", "Show your thought process.", "Justify your approach.", "Provide supporting evidence."],
            ["Consider multiple perspectives.", "Think about edge cases.", "Validate your solution.", "Check for completeness."],
            ["Format your response clearly.", "Organize your answer logically.", "Present results systematically.", "Structure your output well."],
            ["Optimize for accuracy and clarity.", "Ensure comprehensive coverage.", "Provide actionable insights.", "Deliver high-quality results."]
        ]
        
        if style < len(suffixes):
            suffix_options = suffixes[style]
            suffix_idx = int(intensity * len(suffix_options))
            suffix_idx = min(suffix_idx, len(suffix_options) - 1)
            suffix = suffix_options[suffix_idx]
            
            return f"{instruction} {suffix}"
        
        return instruction
    
    def _change_tone(self, instruction: str, parameters: Dict) -> str:
        """Change the tone of an instruction."""
        
        style = parameters.get('style', 0)
        
        tone_modifiers = [
            "Be direct and concise:",
            "Be thorough and comprehensive:",
            "Be creative and innovative:",
            "Be analytical and logical:",
            "Be practical and actionable:"
        ]
        
        if style < len(tone_modifiers):
            modifier = tone_modifiers[style]
            return f"{modifier} {instruction}"
        
        return instruction
    
    def _add_constraint(self, instruction: str, parameters: Dict) -> str:
        """Add constraints to an instruction."""
        
        intensity = parameters.get('intensity', 0.5)
        specificity = parameters.get('specificity', 0.5)
        
        constraints = [
            "Ensure your response is accurate and well-reasoned.",
            "Provide specific examples to support your points.",
            "Consider potential limitations and edge cases.",
            "Validate your approach before providing the final answer.",
            "Focus on the most important and relevant aspects."
        ]
        
        if specificity > 0.7:
            constraints.extend([
                "Limit your response to the most critical points.",
                "Provide quantitative evidence where possible.",
                "Address potential counterarguments.",
                "Ensure reproducibility of your approach."
            ])
        
        if intensity > 0.5 and constraints:
            constraint = random.choice(constraints)
            return f"{instruction} {constraint}"
        
        return instruction
    
    def _restructure_instruction(self, instruction: str, parameters: Dict) -> str:
        """Restructure the format of an instruction."""
        
        style = parameters.get('style', 0)
        
        structures = [
            "Break this down into clear steps: {}",
            "Approach this systematically: {}",
            "Consider the following framework: {}",
            "Use this structured approach: {}",
            "Follow this methodology: {}"
        ]
        
        if style < len(structures):
            structure = structures[style]
            return structure.format(instruction)
        
        return instruction
    
    def _evaluate_instruction(self, instruction: str) -> float:
        """Evaluate the performance of an instruction."""
        
        try:
            # Use the evaluation function provided during initialization
            if self.evaluation_function and self.current_task:
                result = self.evaluation_function(instruction, self.current_task)
                return result.get('performance', 0.0)
            else:
                # Fallback evaluation based on instruction characteristics
                return self._heuristic_evaluation(instruction)
                
        except Exception as e:
            # Return low performance for instructions that cause errors
            return 0.0
    
    def _heuristic_evaluation(self, instruction: str) -> float:
        """Heuristic evaluation of instruction quality."""
        
        score = 0.0
        
        # Length and complexity
        word_count = len(instruction.split())
        if 10 <= word_count <= 50:
            score += 0.2
        elif word_count > 50:
            score += 0.1
        
        # Structure indicators
        if any(word in instruction.lower() for word in ['step', 'first', 'then', 'finally']):
            score += 0.3
        
        # Clarity indicators
        if any(word in instruction.lower() for word in ['clear', 'specific', 'detailed']):
            score += 0.2
        
        # Constraint indicators
        if any(word in instruction.lower() for word in ['ensure', 'make sure', 'verify']):
            score += 0.2
        
        # Completeness indicators
        if any(word in instruction.lower() for word in ['explain', 'provide', 'show']):
            score += 0.1
        
        return min(score, 1.0)
    
    def _calculate_reward(self, performance: float, action: RLAction) -> float:
        """Calculate reward for the current step."""
        
        # Base reward from performance
        reward = performance
        
        # Improvement bonus
        if len(self.current_state.performance_history) > 1:
            previous_performance = self.current_state.performance_history[-2]
            improvement = performance - previous_performance
            reward += improvement * 2  # Bonus for improvement
        
        # Penalty for poor performance
        if performance < 0.2:
            reward -= 0.1
        
        # Bonus for high performance
        if performance > 0.8:
            reward += 0.2
        
        # Efficiency penalty (encourage reaching good performance quickly)
        if self.step_count > 10:
            reward -= 0.01 * (self.step_count - 10)
        
        return reward

class DQNAgent(nn.Module):
    """Deep Q-Network agent for instruction optimization."""
    
    def __init__(self, 
                 state_dim: int,
                 action_dim: int,
                 hidden_dims: List[int] = [128, 64],
                 learning_rate: float = 0.001):
        """
        Initialize DQN agent.
        
        Args:
            state_dim: Dimension of state space
            action_dim: Dimension of action space
            hidden_dims: Hidden layer dimensions
            learning_rate: Learning rate for optimization
        """
        
        super().__init__()
        
        self.state_dim = state_dim
        self.action_dim = action_dim
        
        # Build network layers
        layers = []
        prev_dim = state_dim
        
        for hidden_dim in hidden_dims:
            layers.extend([
                nn.Linear(prev_dim, hidden_dim),
                nn.ReLU(),
                nn.Dropout(0.2)
            ])
            prev_dim = hidden_dim
        
        layers.append(nn.Linear(prev_dim, action_dim))
        
        self.network = nn.Sequential(*layers)
        self.optimizer = optim.Adam(self.parameters(), lr=learning_rate)
        
        # Experience replay
        self.memory = deque(maxlen=10000)
        self.batch_size = 32
        
        # Exploration
        self.epsilon = 1.0
        self.epsilon_decay = 0.995
        self.epsilon_min = 0.01
    
    def forward(self, state: torch.Tensor) -> torch.Tensor:
        """Forward pass through the network."""
        return self.network(state)
    
    def act(self, state: np.ndarray, training: bool = True) -> np.ndarray:
        """Select an action given the current state."""
        
        if training and random.random() < self.epsilon:
            # Exploration: random action
            return np.random.random(self.action_dim).astype(np.float32)
        else:
            # Exploitation: use network
            state_tensor = torch.FloatTensor(state).unsqueeze(0)
            with torch.no_grad():
                q_values = self.forward(state_tensor)
                # Convert Q-values to action probabilities and sample
                action_probs = torch.softmax(q_values, dim=1)
                action = torch.multinomial(action_probs, 1).float() / self.action_dim
                return action.squeeze().numpy()
    
    def remember(self, state, action, reward, next_state, done):
        """Store experience in replay memory."""
        self.memory.append((state, action, reward, next_state, done))
    
    def replay(self):
        """Train the network on a batch of experiences."""
        
        if len(self.memory) < self.batch_size:
            return
        
        batch = random.sample(self.memory, self.batch_size)
        states = torch.FloatTensor([e[0] for e in batch])
        actions = torch.FloatTensor([e[1] for e in batch])
        rewards = torch.FloatTensor([e[2] for e in batch])
        next_states = torch.FloatTensor([e[3] for e in batch])
        dones = torch.BoolTensor([e[4] for e in batch])
        
        current_q_values = self.forward(states)
        next_q_values = self.forward(next_states)
        
        target_q_values = rewards + (0.99 * torch.max(next_q_values, 1)[0] * ~dones)
        
        # Convert actions to Q-value indices (simplified)
        action_indices = (actions * self.action_dim).long()
        predicted_q_values = current_q_values.gather(1, action_indices[:, 0].unsqueeze(1))
        
        loss = nn.MSELoss()(predicted_q_values.squeeze(), target_q_values)
        
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        
        # Decay exploration rate
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay

class RLInstructionOptimizer:
    """Main RL-based instruction optimizer integrating with DSPy modules."""
    
    def __init__(self,
                 instructor_module,
                 responder_module,
                 state_dim: int = 10,
                 action_dim: int = 4,
                 episodes: int = 100):
        """
        Initialize RL instruction optimizer.
        
        Args:
            instructor_module: DSPy instructor module
            responder_module: DSPy responder module
            state_dim: Dimension of state representation
            action_dim: Dimension of action representation
            episodes: Number of training episodes
        """
        
        self.instructor_module = instructor_module
        self.responder_module = responder_module
        
        # Initialize RL components
        self.env = InstructionOptimizationEnv(
            instructor_module, responder_module, self._evaluate_instruction
        )
        
        self.agent = DQNAgent(state_dim, action_dim)
        
        self.episodes = episodes
        self.training_history = []
        
    def optimize_instruction(self,
                           base_instruction: str,
                           task_data: Dict,
                           evaluation_data: List[Dict]) -> Dict[str, Any]:
        """
        Optimize an instruction using RL.
        
        Args:
            base_instruction: Initial instruction to optimize
            task_data: Task information and context
            evaluation_data: Data for evaluating instruction performance
            
        Returns:
            Dictionary containing optimization results
        """
        
        best_instruction = base_instruction
        best_performance = 0.0
        episode_rewards = []
        
        # Prepare task context
        task_context = {
            'base_instruction': base_instruction,
            'task_data': task_data,
            'evaluation_data': evaluation_data
        }
        
        for episode in range(self.episodes):
            # Reset environment
            state, _ = self.env.reset(options={'task': task_context})
            
            episode_reward = 0
            episode_steps = 0
            
            while True:
                # Agent selects action
                action = self.agent.act(state, training=True)
                
                # Execute action
                next_state, reward, done, truncated, info = self.env.step(action)
                
                # Store experience
                self.agent.remember(state, action, reward, next_state, done)
                
                # Update state
                state = next_state
                episode_reward += reward
                episode_steps += 1
                
                # Check for new best instruction
                current_performance = info.get('current_performance', 0)
                if current_performance > best_performance:
                    best_performance = current_performance
                    # Get the instruction that achieved this performance
                    episode_history = info.get('episode_history', [])
                    if episode_history:
                        best_instruction = episode_history[-1]['instruction']
                
                if done or truncated:
                    break
            
            # Train agent
            self.agent.replay()
            
            episode_rewards.append(episode_reward)
            
            # Log progress
            if episode % 10 == 0:
                avg_reward = np.mean(episode_rewards[-10:])
                print(f"Episode {episode}, Avg Reward: {avg_reward:.3f}, Best Performance: {best_performance:.3f}")
        
        # Compile results
        optimization_results = {
            'optimized_instruction': best_instruction,
            'best_performance': best_performance,
            'training_episodes': self.episodes,
            'episode_rewards': episode_rewards,
            'final_epsilon': self.agent.epsilon,
            'average_final_reward': np.mean(episode_rewards[-10:]) if len(episode_rewards) >= 10 else np.mean(episode_rewards),
            'improvement_ratio': best_performance / self._evaluate_instruction(base_instruction, task_context).get('performance', 0.1)
        }
        
        return optimization_results
    
    def _evaluate_instruction(self, instruction: str, task_context: Dict) -> Dict[str, Any]:
        """Evaluate instruction performance using DSPy modules."""
        
        try:
            evaluation_data = task_context.get('evaluation_data', [])
            
            if not evaluation_data:
                # Fallback evaluation
                return {'performance': 0.5, 'accuracy': 0.5, 'efficiency': 0.5}
            
            results = []
            for data_point in evaluation_data:
                # Use responder module to execute instruction
                result = self.responder_module.forward(
                    instruction=instruction,
                    task_input=data_point.get('input', ''),
                    tools_available=data_point.get('tools', {})
                )
                
                # Calculate performance metrics
                performance_metrics = self._calculate_performance_metrics(
                    result, data_point
                )
                results.append(performance_metrics)
            
            # Aggregate results
            if results:
                avg_performance = np.mean([r.get('overall_score', 0) for r in results])
                avg_accuracy = np.mean([r.get('accuracy', 0) for r in results])
                avg_efficiency = np.mean([r.get('efficiency', 0) for r in results])
                
                return {
                    'performance': avg_performance,
                    'accuracy': avg_accuracy,
                    'efficiency': avg_efficiency,
                    'results': results
                }
            else:
                return {'performance': 0.0, 'accuracy': 0.0, 'efficiency': 0.0}
                
        except Exception as e:
            print(f"Evaluation error: {e}")
            return {'performance': 0.0, 'accuracy': 0.0, 'efficiency': 0.0}
    
    def _calculate_performance_metrics(self, result: Dict, expected: Dict) -> Dict[str, float]:
        """Calculate performance metrics for a single result."""
        
        metrics = {}
        
        # Accuracy (simplified - would need task-specific logic)
        if 'expected_output' in expected:
            expected_output = expected['expected_output']
            actual_output = result.get('response', '')
            
            # Simple string similarity as accuracy proxy
            if expected_output.lower() in actual_output.lower():
                metrics['accuracy'] = 1.0
            else:
                # Use Jaccard similarity
                expected_words = set(expected_output.lower().split())
                actual_words = set(actual_output.lower().split())
                if expected_words or actual_words:
                    intersection = len(expected_words.intersection(actual_words))
                    union = len(expected_words.union(actual_words))
                    metrics['accuracy'] = intersection / union if union > 0 else 0.0
                else:
                    metrics['accuracy'] = 0.0
        else:
            metrics['accuracy'] = result.get('confidence', 0.5)
        
        # Efficiency
        execution_time = result.get('execution_time', 1.0)
        metrics['efficiency'] = 1.0 / (1.0 + execution_time)  # Lower time = higher efficiency
        
        # Overall score
        metrics['overall_score'] = (metrics['accuracy'] + metrics['efficiency']) / 2
        
        return metrics
    
    def get_optimization_statistics(self) -> Dict[str, Any]:
        """Get statistics about the RL optimization process."""
        
        return {
            'total_episodes': len(self.training_history),
            'agent_epsilon': self.agent.epsilon,
            'memory_size': len(self.agent.memory),
            'network_parameters': sum(p.numel() for p in self.agent.parameters()),
            'average_episode_reward': np.mean([h['reward'] for h in self.training_history]) if self.training_history else 0
        }