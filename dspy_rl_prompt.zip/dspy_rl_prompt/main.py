"""Main DSPy RL Optimizer Pipeline - End-to-end implementation."""

import asyncio
import json
import time
from typing import Dict, List, Any, Optional
from dataclasses import dataclass

# Import DSPy and configuration
import dspy
from utils.dspy_config import initialize_dspy, config

# Import modules
from modules.instructor_module import InstructorModule
from modules.responder_module import ResponderModule
from modules.rl_integration import RLInstructionOptimizer

# Import optimizers
from optimizers.gepa_optimizer import GEPAOptimizer
from optimizers.miprov2_optimizer import Miprov2Optimizer

@dataclass
class OptimizationTask:
    """Represents a complete optimization task."""
    task_id: str
    task_description: str
    base_instruction: str
    evaluation_data: List[Dict]
    success_criteria: List[str]
    target_metrics: List[str]
    optimization_methods: List[str]  # ['gepa', 'miprov2', 'rl']

class DSPyRLPipeline:
    """Main pipeline orchestrating DSPy modules with RL optimization."""
    
    def __init__(self, 
                 instructor_model: str = "openai",
                 responder_model: str = "openai"):
        """
        Initialize the DSPy RL optimization pipeline.
        
        Args:
            instructor_model: Model to use for instruction generation
            responder_model: Model to use for task execution
        """
        
        # Initialize DSPy configuration
        self.config = initialize_dspy(instructor_model, responder_model)
        
        # Initialize modules
        self.instructor = InstructorModule()
        self.responder = ResponderModule()
        
        # Initialize optimizers
        self.gepa_optimizer = GEPAOptimizer(
            population_size=15,
            mutation_rate=0.3,
            crossover_rate=0.7,
            max_generations=8
        )
        
        self.miprov2_optimizer = Miprov2Optimizer(
            max_steps=8,
            optimization_rounds=5
        )
        
        self.rl_optimizer = RLInstructionOptimizer(
            instructor_module=self.instructor,
            responder_module=self.responder,
            episodes=50
        )
        
        # Pipeline state
        self.optimization_history = []
        self.performance_metrics = {}
        
    async def run_optimization_pipeline(self, task: OptimizationTask) -> Dict[str, Any]:
        """
        Run the complete optimization pipeline for a given task.
        
        Args:
            task: OptimizationTask containing all necessary information
            
        Returns:
            Dictionary containing comprehensive optimization results
        """
        
        print(f"🚀 Starting optimization pipeline for task: {task.task_id}")
        print(f"📋 Task: {task.task_description}")
        print(f"🎯 Methods: {', '.join(task.optimization_methods)}")
        
        start_time = time.time()
        results = {
            'task_id': task.task_id,
            'task_description': task.task_description,
            'base_instruction': task.base_instruction,
            'optimization_results': {},
            'performance_comparison': {},
            'best_instruction': task.base_instruction,
            'best_performance': 0.0,
            'execution_time': 0.0
        }
        
        # Evaluate base instruction performance
        print("\n📊 Evaluating base instruction...")
        base_performance = await self._evaluate_instruction_comprehensive(
            task.base_instruction, task
        )
        results['base_performance'] = base_performance
        print(f"Base performance: {base_performance.get('overall_score', 0):.3f}")
        
        # Run each optimization method
        for method in task.optimization_methods:
            print(f"\n🔧 Running {method.upper()} optimization...")
            
            try:
                if method == 'gepa':
                    method_results = await self._run_gepa_optimization(task)
                elif method == 'miprov2':
                    method_results = await self._run_miprov2_optimization(task)
                elif method == 'rl':
                    method_results = await self._run_rl_optimization(task)
                else:
                    print(f"❌ Unknown optimization method: {method}")
                    continue
                
                results['optimization_results'][method] = method_results
                
                # Check if this is the best result so far
                method_performance = method_results.get('performance', {}).get('overall_score', 0)
                if method_performance > results['best_performance']:
                    results['best_performance'] = method_performance
                    results['best_instruction'] = method_results.get('optimized_instruction', task.base_instruction)
                    results['best_method'] = method
                
                print(f"✅ {method.upper()} completed. Performance: {method_performance:.3f}")
                
            except Exception as e:
                print(f"❌ Error in {method} optimization: {e}")
                results['optimization_results'][method] = {'error': str(e)}
        
        # Generate performance comparison
        results['performance_comparison'] = self._generate_performance_comparison(results)
        
        # Calculate total execution time
        results['execution_time'] = time.time() - start_time
        
        # Store in history
        self.optimization_history.append(results)
        
        print(f"\n🎉 Pipeline completed in {results['execution_time']:.2f}s")
        print(f"🏆 Best method: {results.get('best_method', 'None')}")
        print(f"📈 Best performance: {results['best_performance']:.3f}")
        
        return results
    
    async def _run_gepa_optimization(self, task: OptimizationTask) -> Dict[str, Any]:
        """Run GEPA optimization."""
        
        def task_function(instruction: str, data_point: Dict) -> Dict:
            """Function to execute task with given instruction."""
            result = self.responder.forward(
                instruction=instruction,
                task_input=data_point.get('input', ''),
                tools_available=data_point.get('tools', {})
            )
            
            # Calculate performance metrics
            performance = self._calculate_task_performance(result, data_point)
            return performance
        
        # Run GEPA optimization
        gepa_results = self.gepa_optimizer.optimize(
            base_prompt=task.base_instruction,
            task_function=task_function,
            evaluation_data=task.evaluation_data,
            target_metric="accuracy"
        )
        
        # Evaluate final performance
        final_performance = await self._evaluate_instruction_comprehensive(
            gepa_results['best_prompt'], task
        )
        
        return {
            'optimized_instruction': gepa_results['best_prompt'],
            'performance': final_performance,
            'optimization_details': gepa_results,
            'method': 'GEPA'
        }
    
    async def _run_miprov2_optimization(self, task: OptimizationTask) -> Dict[str, Any]:
        """Run Miprov2 optimization."""
        
        def task_function(instruction: str, data_point: Dict) -> Dict:
            """Function to execute task with given instruction."""
            result = self.responder.forward(
                instruction=instruction,
                task_input=data_point.get('input', ''),
                tools_available=data_point.get('tools', {})
            )
            
            # Calculate performance metrics
            performance = self._calculate_task_performance(result, data_point)
            return performance
        
        # Run Miprov2 optimization
        miprov2_results = self.miprov2_optimizer.optimize(
            base_instruction=task.base_instruction,
            task_function=task_function,
            evaluation_data=task.evaluation_data,
            success_criteria=task.success_criteria,
            target_metrics=task.target_metrics
        )
        
        # Evaluate final performance
        final_performance = await self._evaluate_instruction_comprehensive(
            miprov2_results['optimized_instruction'], task
        )
        
        return {
            'optimized_instruction': miprov2_results['optimized_instruction'],
            'performance': final_performance,
            'optimization_details': miprov2_results,
            'method': 'Miprov2'
        }
    
    async def _run_rl_optimization(self, task: OptimizationTask) -> Dict[str, Any]:
        """Run RL optimization."""
        
        # Prepare task data for RL optimizer
        task_data = {
            'description': task.task_description,
            'success_criteria': task.success_criteria,
            'target_metrics': task.target_metrics
        }
        
        # Run RL optimization
        rl_results = self.rl_optimizer.optimize_instruction(
            base_instruction=task.base_instruction,
            task_data=task_data,
            evaluation_data=task.evaluation_data
        )
        
        # Evaluate final performance
        final_performance = await self._evaluate_instruction_comprehensive(
            rl_results['optimized_instruction'], task
        )
        
        return {
            'optimized_instruction': rl_results['optimized_instruction'],
            'performance': final_performance,
            'optimization_details': rl_results,
            'method': 'RL'
        }
    
    async def _evaluate_instruction_comprehensive(self, 
                                                instruction: str, 
                                                task: OptimizationTask) -> Dict[str, Any]:
        """Comprehensively evaluate an instruction's performance."""
        
        results = []
        total_time = 0
        
        for data_point in task.evaluation_data:
            start_time = time.time()
            
            # Execute instruction
            result = self.responder.forward(
                instruction=instruction,
                task_input=data_point.get('input', ''),
                tools_available=data_point.get('tools', {})
            )
            
            execution_time = time.time() - start_time
            total_time += execution_time
            
            # Calculate performance
            performance = self._calculate_task_performance(result, data_point)
            performance['execution_time'] = execution_time
            
            results.append(performance)
        
        # Aggregate metrics
        if results:
            metrics = {
                'accuracy': sum(r.get('accuracy', 0) for r in results) / len(results),
                'efficiency': sum(r.get('efficiency', 0) for r in results) / len(results),
                'completeness': sum(r.get('completeness', 0) for r in results) / len(results),
                'confidence': sum(r.get('confidence', 0) for r in results) / len(results),
                'total_execution_time': total_time,
                'average_execution_time': total_time / len(results),
                'success_rate': sum(1 for r in results if r.get('accuracy', 0) > 0.7) / len(results)
            }
            
            # Calculate overall score
            metrics['overall_score'] = (
                metrics['accuracy'] * 0.4 +
                metrics['efficiency'] * 0.2 +
                metrics['completeness'] * 0.2 +
                metrics['confidence'] * 0.2
            )
        else:
            metrics = {
                'accuracy': 0.0, 'efficiency': 0.0, 'completeness': 0.0,
                'confidence': 0.0, 'overall_score': 0.0, 'success_rate': 0.0
            }
        
        return {
            'metrics': metrics,
            'individual_results': results,
            'evaluation_count': len(results)
        }
    
    def _calculate_task_performance(self, result: Dict, expected: Dict) -> Dict[str, float]:
        """Calculate performance metrics for a task result."""
        
        performance = {}
        
        # Accuracy
        if 'expected_output' in expected:
            expected_output = expected['expected_output'].lower()
            actual_output = result.get('response', '').lower()
            
            if expected_output in actual_output:
                performance['accuracy'] = 1.0
            else:
                # Use word overlap as similarity measure
                expected_words = set(expected_output.split())
                actual_words = set(actual_output.split())
                if expected_words:
                    overlap = len(expected_words.intersection(actual_words))
                    performance['accuracy'] = overlap / len(expected_words)
                else:
                    performance['accuracy'] = 0.0
        else:
            performance['accuracy'] = result.get('confidence', 0.5)
        
        # Efficiency (based on execution time and response length)
        execution_time = result.get('execution_time', 1.0)
        response_length = len(result.get('response', ''))
        
        # Normalize efficiency (lower time and appropriate length = higher efficiency)
        time_efficiency = 1.0 / (1.0 + execution_time)
        length_efficiency = min(1.0, response_length / 500) if response_length > 0 else 0.0
        performance['efficiency'] = (time_efficiency + length_efficiency) / 2
        
        # Completeness (based on response length and structure)
        if response_length > 50:
            performance['completeness'] = min(1.0, response_length / 200)
        else:
            performance['completeness'] = response_length / 50
        
        # Confidence (from model or heuristic)
        performance['confidence'] = result.get('confidence', 0.5)
        
        return performance
    
    def _generate_performance_comparison(self, results: Dict) -> Dict[str, Any]:
        """Generate performance comparison between optimization methods."""
        
        comparison = {
            'method_rankings': [],
            'metric_comparison': {},
            'improvement_analysis': {}
        }
        
        base_performance = results.get('base_performance', {}).get('metrics', {})
        optimization_results = results.get('optimization_results', {})
        
        # Rank methods by overall performance
        method_performances = []
        for method, method_results in optimization_results.items():
            if 'error' not in method_results:
                performance = method_results.get('performance', {}).get('metrics', {})
                overall_score = performance.get('overall_score', 0)
                method_performances.append((method, overall_score, performance))
        
        method_performances.sort(key=lambda x: x[1], reverse=True)
        comparison['method_rankings'] = [
            {'method': method, 'score': score, 'rank': i+1}
            for i, (method, score, _) in enumerate(method_performances)
        ]
        
        # Compare metrics across methods
        metrics = ['accuracy', 'efficiency', 'completeness', 'confidence', 'overall_score']
        for metric in metrics:
            comparison['metric_comparison'][metric] = {
                'base': base_performance.get(metric, 0),
                'methods': {}
            }
            
            for method, _, performance in method_performances:
                comparison['metric_comparison'][metric]['methods'][method] = performance.get(metric, 0)
        
        # Calculate improvements
        for method, _, performance in method_performances:
            improvements = {}
            for metric in metrics:
                base_value = base_performance.get(metric, 0)
                method_value = performance.get(metric, 0)
                if base_value > 0:
                    improvement = (method_value - base_value) / base_value
                else:
                    improvement = method_value
                improvements[metric] = improvement
            
            comparison['improvement_analysis'][method] = improvements
        
        return comparison
    
    def get_pipeline_statistics(self) -> Dict[str, Any]:
        """Get comprehensive pipeline statistics."""
        
        if not self.optimization_history:
            return {'message': 'No optimization history available'}
        
        stats = {
            'total_optimizations': len(self.optimization_history),
            'methods_used': set(),
            'average_performance_by_method': {},
            'best_overall_performance': 0.0,
            'total_execution_time': 0.0
        }
        
        # Aggregate statistics
        method_performances = {}
        
        for result in self.optimization_history:
            stats['total_execution_time'] += result.get('execution_time', 0)
            
            if result.get('best_performance', 0) > stats['best_overall_performance']:
                stats['best_overall_performance'] = result['best_performance']
            
            for method, method_result in result.get('optimization_results', {}).items():
                if 'error' not in method_result:
                    stats['methods_used'].add(method)
                    
                    if method not in method_performances:
                        method_performances[method] = []
                    
                    performance = method_result.get('performance', {}).get('metrics', {})
                    method_performances[method].append(performance.get('overall_score', 0))
        
        # Calculate averages
        for method, performances in method_performances.items():
            if performances:
                stats['average_performance_by_method'][method] = sum(performances) / len(performances)
        
        stats['methods_used'] = list(stats['methods_used'])
        
        return stats

# Example usage and demo functions
def create_sample_tasks() -> List[OptimizationTask]:
    """Create sample tasks for demonstration."""
    
    tasks = []
    
    # Task 1: Question Answering
    qa_task = OptimizationTask(
        task_id="qa_001",
        task_description="Answer factual questions accurately and concisely",
        base_instruction="Answer the following question based on your knowledge.",
        evaluation_data=[
            {
                'input': 'What is the capital of France?',
                'expected_output': 'Paris',
                'tools': {}
            },
            {
                'input': 'Who wrote Romeo and Juliet?',
                'expected_output': 'William Shakespeare',
                'tools': {}
            },
            {
                'input': 'What is 15 * 23?',
                'expected_output': '345',
                'tools': {}
            }
        ],
        success_criteria=['Accuracy > 0.8', 'Response time < 2s', 'Concise answers'],
        target_metrics=['accuracy', 'efficiency', 'completeness'],
        optimization_methods=['gepa', 'miprov2', 'rl']
    )
    tasks.append(qa_task)
    
    # Task 2: Problem Solving
    problem_solving_task = OptimizationTask(
        task_id="ps_001",
        task_description="Solve multi-step mathematical word problems",
        base_instruction="Solve the given problem step by step, showing your work.",
        evaluation_data=[
            {
                'input': 'A store sells apples for $2 per pound. If John buys 3.5 pounds and pays with a $10 bill, how much change does he receive?',
                'expected_output': '$3',
                'tools': {}
            },
            {
                'input': 'A rectangular garden is 12 feet long and 8 feet wide. What is its area and perimeter?',
                'expected_output': 'Area: 96 square feet, Perimeter: 40 feet',
                'tools': {}
            }
        ],
        success_criteria=['Correct final answer', 'Clear step-by-step solution', 'Proper units'],
        target_metrics=['accuracy', 'completeness', 'confidence'],
        optimization_methods=['miprov2', 'rl']
    )
    tasks.append(problem_solving_task)
    
    return tasks

async def run_demo():
    """Run a demonstration of the DSPy RL pipeline."""
    
    print("🎯 DSPy RL Optimization Pipeline Demo")
    print("=" * 50)
    
    # Initialize pipeline
    pipeline = DSPyRLPipeline()
    
    # Create sample tasks
    tasks = create_sample_tasks()
    
    # Run optimization for each task
    all_results = []
    
    for task in tasks:
        print(f"\n{'='*60}")
        results = await pipeline.run_optimization_pipeline(task)
        all_results.append(results)
        
        # Print summary
        print(f"\n📊 Task {task.task_id} Summary:")
        print(f"Base Performance: {results['base_performance']['metrics']['overall_score']:.3f}")
        print(f"Best Performance: {results['best_performance']:.3f}")
        print(f"Best Method: {results.get('best_method', 'None')}")
        print(f"Improvement: {((results['best_performance'] - results['base_performance']['metrics']['overall_score']) / results['base_performance']['metrics']['overall_score'] * 100):.1f}%")
    
    # Print overall statistics
    print(f"\n{'='*60}")
    print("🏆 Overall Pipeline Statistics")
    stats = pipeline.get_pipeline_statistics()
    print(f"Total Optimizations: {stats['total_optimizations']}")
    print(f"Methods Used: {', '.join(stats['methods_used'])}")
    print(f"Best Overall Performance: {stats['best_overall_performance']:.3f}")
    print(f"Total Execution Time: {stats['total_execution_time']:.2f}s")
    
    return all_results

if __name__ == "__main__":
    # Run the demo
    results = asyncio.run(run_demo())
    
    # Save results to file
    with open('optimization_results.json', 'w') as f:
        json.dump(results, f, indent=2, default=str)
    
    print("\n Demo completed! Results saved to 'optimization_results.json'")