"""DSPy signatures for instruction generation and optimization."""

import dspy
from typing import List, Optional

class InstructionGeneration(dspy.Signature):
    """Generate optimized instructions for a given task."""
    
    task_description: str = dspy.InputField(desc="Description of the task to generate instructions for")
    previous_instructions: Optional[str] = dspy.InputField(desc="Previous instruction attempts and their outcomes", default="")
    optimization_markers: Optional[str] = dspy.InputField(desc="Optimization markers from RL agent (prefix tokens, hyper-prompts, etc.)", default="")
    context: Optional[str] = dspy.InputField(desc="Additional context or constraints", default="")
    
    instruction: str = dspy.OutputField(desc="Generated instruction optimized for the task")
    reasoning: str = dspy.OutputField(desc="Reasoning behind the instruction generation")

class TaskExecution(dspy.Signature):
    """Execute a task based on given instructions."""
    
    instruction: str = dspy.InputField(desc="The instruction to follow")
    task_input: str = dspy.InputField(desc="Input data or query for the task")
    tools_available: Optional[str] = dspy.InputField(desc="Available tools and their descriptions", default="")
    
    response: str = dspy.OutputField(desc="Response or solution to the task")
    tool_usage: Optional[str] = dspy.OutputField(desc="Tools used and how they were applied", default="")
    confidence: float = dspy.OutputField(desc="Confidence score for the response (0-1)")

class InstructionEvaluation(dspy.Signature):
    """Evaluate the quality and effectiveness of instructions."""
    
    instruction: str = dspy.InputField(desc="The instruction to evaluate")
    task_description: str = dspy.InputField(desc="Original task description")
    execution_result: str = dspy.InputField(desc="Result of executing the instruction")
    expected_outcome: Optional[str] = dspy.InputField(desc="Expected or desired outcome", default="")
    
    quality_score: float = dspy.OutputField(desc="Quality score for the instruction (0-1)")
    effectiveness_score: float = dspy.OutputField(desc="Effectiveness score based on results (0-1)")
    improvement_suggestions: str = dspy.OutputField(desc="Suggestions for improving the instruction")

class PromptOptimization(dspy.Signature):
    """Optimize prompts using evolutionary and RL-based approaches."""
    
    base_prompt: str = dspy.InputField(desc="Base prompt to optimize")
    performance_history: str = dspy.InputField(desc="History of prompt performance and outcomes")
    optimization_strategy: str = dspy.InputField(desc="Strategy to use (GEPA, Miprov2, RL)")
    target_metrics: str = dspy.InputField(desc="Target metrics to optimize for")
    
    optimized_prompt: str = dspy.OutputField(desc="Optimized version of the prompt")
    optimization_rationale: str = dspy.OutputField(desc="Explanation of optimization choices")
    expected_improvement: float = dspy.OutputField(desc="Expected improvement score (0-1)")

class MultiStepReasoning(dspy.Signature):
    """Handle multi-step reasoning tasks with tool integration."""
    
    complex_query: str = dspy.InputField(desc="Complex query requiring multi-step reasoning")
    available_tools: str = dspy.InputField(desc="List of available tools and their capabilities")
    instruction_context: str = dspy.InputField(desc="Context and instructions for reasoning approach")
    
    reasoning_steps: str = dspy.OutputField(desc="Step-by-step reasoning process")
    tool_sequence: str = dspy.OutputField(desc="Sequence of tools to use and their inputs")
    final_answer: str = dspy.OutputField(desc="Final answer or solution")
    confidence_breakdown: str = dspy.OutputField(desc="Confidence scores for each step")