import dspy

def run_problem(problem_id, problem_text, ground_truth, max_iters=3):
    actor = ActorModule()
    evaluator = EvaluatorModule()
    refl = ReflectionistModule()
    cf = CounterfactualModule()
    policy = PolicyComposerModule()

    instruction = "Solve the problem carefully. Output FinalAnswer: <value>."

    memory_summary = ""
    history = []

    for t in range(max_iters):
        # Actor
        act_out = actor(problem_text=problem_text, instruction_text=instruction)
        final_answer = act_out.final_answer

        # Evaluator
        eval_out = evaluator(final_answer=final_answer,
                             ground_truth=ground_truth,
                             task_type="gsm8k")

        # Reflectionist
        refl_out = refl(instruction_text=instruction,
                        final_answer=final_answer,
                        eval_json=eval_out.__dict__,
                        memory_summary=memory_summary)

        # Counterfactual tests (optional: run on proposals)
        proposals = refl_out.proposals
        attribution_summary = ""
        if proposals:
            # run one CF test as example
            first_edit = proposals[0].get("edit") if isinstance(proposals, list) else proposals
            cf_out = cf(problem_text=problem_text, instruction_with_edit=first_edit)
            attribution_summary = f"CF tried: {first_edit}, result: {cf_out.cf_score}"

        # Policy chooses next instruction
        policy_out = policy(proposals=proposals,
                            attribution_summary=attribution_summary,
                            memory_summary=memory_summary)

        instruction = policy_out.next_instruction

        # Update memory summary
        history.append({"instruction": instruction,
                        "answer": final_answer,
                        "score": eval_out.score,
                        "reflection": refl_out.reflection})
        memory_summary = str(history[-3:])  # last 3 trials summarized

        if eval_out.score == 1:
            break

    return history
