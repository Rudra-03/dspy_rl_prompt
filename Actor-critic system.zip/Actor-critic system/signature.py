import dspy

# -------------------------------------------------
# 1. Actor (Solver)
# -------------------------------------------------
class ActorSignature(dspy.Signature):
    """
    System: You are a precise problem solver.
    - Read the problem carefully.
    - Follow the provided instruction exactly.
    - If the instruction says "step by step", include reasoning.
    - Always end with a JSON object containing:
        {"final_answer": "...", "chain_of_thought": "..."}
      (omit chain_of_thought if not requested).
    """
    problem_text = dspy.InputField(desc="The problem/question to solve.")
    instruction_text = dspy.InputField(desc="The current instruction guiding the solver.")
    final_answer = dspy.OutputField(desc="The solver's final answer.")
    chain_of_thought = dspy.OutputField(optional=True, desc="Step-by-step reasoning if included.")

# -------------------------------------------------
# 2. Evaluator
# -------------------------------------------------
class EvaluatorSignature(dspy.Signature):
    """
    System: You are a strict evaluator.
    - Compare solver's answer with the ground truth.
    - For GSM8K: score=1 if exact numeric match else 0.
    - For HotPotQA: compute EM (exact match) and F1.
    - Always return JSON: {"score": ..., "error_type":"...", "notes":"..."}
    """
    final_answer = dspy.InputField(desc="Solver's predicted answer.")
    ground_truth = dspy.InputField(desc="Correct gold answer.")
    task_type = dspy.InputField(desc="Task type: 'gsm8k' or 'hotpotqa'.")
    score = dspy.OutputField(desc="Numeric score (int or float).")
    error_type = dspy.OutputField(optional=True, desc="Type of error if wrong.")
    notes = dspy.OutputField(optional=True, desc="Any evaluator notes.")

# -------------------------------------------------
# 3. Reflectionist
# -------------------------------------------------
class ReflectionistSignature(dspy.Signature):
    """
    System: You are a reflectionist (self-critic).
    - Analyze the solver's attempt and evaluation.
    - Write a short reflection explaining success/failure.
    - Propose 1–3 concrete edits to the instruction that could improve results.
    - Each proposal must be actionable (e.g., "add step-by-step reasoning").
    - Always return JSON:
        {"reflection":"...", "proposals":[{"edit":"...", "attr":"...", "rationale":"..."}]}
    """
    instruction_text = dspy.InputField(desc="The instruction used in this attempt.")
    final_answer = dspy.InputField(desc="Solver's predicted answer.")
    eval_json = dspy.InputField(desc="Evaluation result in JSON.")
    memory_summary = dspy.InputField(optional=True, desc="Summary of previous attempts.")
    reflection = dspy.OutputField(desc="Textual reflection on attempt.")
    proposals = dspy.OutputField(desc="List of proposed edits in JSON format.")

# -------------------------------------------------
# 4. Counterfactual Tester
# -------------------------------------------------
class CounterfactualSignature(dspy.Signature):
    """
    System: You are a counterfactual tester.
    - Apply the proposed edit to the instruction.
    - Solve the problem again using the modified instruction.
    - Return JSON: {"cf_answer":"...", "cf_score":..., "cf_eval_notes":"..."}
    """
    problem_text = dspy.InputField(desc="The problem/question to solve.")
    instruction_with_edit = dspy.InputField(desc="Modified instruction text after applying proposal.")
    cf_answer = dspy.OutputField(desc="Answer under counterfactual instruction.")
    cf_score = dspy.OutputField(optional=True, desc="Evaluation score for this counterfactual.")
    cf_eval_notes = dspy.OutputField(optional=True, desc="Any notes on performance difference.")

# -------------------------------------------------
# 5. Policy Composer
# -------------------------------------------------
class PolicySignature(dspy.Signature):
    """
    System: You are a policy decider.
    - Review the proposals, attribution notes, and memory summary.
    - Choose the most promising edit (or merge edits).
    - Always return JSON: {"next_instruction":"...", "picked":"proposal_id"}
    """
    proposals = dspy.InputField(desc="Proposals from reflectionist (JSON list).")
    attribution_summary = dspy.InputField(optional=True, desc="Attribution or counterfactual notes.")
    memory_summary = dspy.InputField(optional=True, desc="Summary of recent trials.")
    next_instruction = dspy.OutputField(desc="The instruction to use in the next attempt.")
    picked = dspy.OutputField(optional=True, desc="ID of the chosen proposal.")
