actor = dspy.Predict(ActorSignature)
evaluator = dspy.Predict(EvaluatorSignature)
reflectionist = dspy.Predict(ReflectionistSignature)
counterfactual = dspy.Predict(CounterfactualSignature)
policy = dspy.Predict(PolicySignature)

# Example run
act_out = actor(problem_text="If Sarah has 3 apples and buys 2 more, how many apples?",
                instruction_text="Solve step by step and give FinalAnswer.")

eval_out = evaluator(final_answer=act_out.final_answer,
                     ground_truth="5",
                     task_type="gsm8k")

refl_out = reflectionist(instruction_text="Solve step by step and give FinalAnswer.",
                         final_answer=act_out.final_answer,
                         eval_json=eval_out.__dict__,
                         memory_summary="")

policy_out = policy(proposals=refl_out.proposals,
                    attribution_summary="",
                    memory_summary="")

print("Actor answer:", act_out.final_answer)
print("Evaluator score:", eval_out.score)
print("Reflection:", refl_out.reflection)
print("Next instruction:", policy_out.next_instruction)
