# dspy_prompt_optimizer.py
import dspy

# ---------------------------
# 1. Actor (Solver)
# ---------------------------
class ActorSignature(dspy.Signature):
    """Solve a given problem using the current instruction."""
    problem_text = dspy.InputField()
    instruction_text = dspy.InputField()
    final_answer = dspy.OutputField(desc="The final answer (string, numeric, or text).")
    chain_of_thought = dspy.OutputField(optional=True)

class ActorModule(dspy.Module):
    def __init__(self, model="gpt-4o-mini"):
        super().__init__()
        self.lm = dspy.LM(model)

    def forward(self, problem_text, instruction_text):
        result = self.lm(
            ActorSignature(),
            problem_text=problem_text,
            instruction_text=instruction_text
        )
        return result

# ---------------------------
# 2. Evaluator
# ---------------------------
class EvaluatorSignature(dspy.Signature):
    """Evaluate solver output against ground truth."""
    final_answer = dspy.InputField()
    ground_truth = dspy.InputField()
    task_type = dspy.InputField(desc="gsm8k or hotpotqa")
    score = dspy.OutputField(desc="Numeric score: 0/1 or EM/F1.")
    error_type = dspy.OutputField(optional=True)
    notes = dspy.OutputField(optional=True)

class EvaluatorModule(dspy.Module):
    def __init__(self, model="gpt-4o-mini"):
        super().__init__()
        self.lm = dspy.LM(model)

    def forward(self, final_answer, ground_truth, task_type="gsm8k"):
        result = self.lm(
            EvaluatorSignature(),
            final_answer=final_answer,
            ground_truth=ground_truth,
            task_type=task_type
        )
        return result

# ---------------------------
# 3. Reflectionist
# ---------------------------
class ReflectionistSignature(dspy.Signature):
    """Reflect on solver attempt and propose instruction edits."""
    instruction_text = dspy.InputField()
    final_answer = dspy.InputField()
    eval_json = dspy.InputField()
    memory_summary = dspy.InputField(optional=True)
    reflection = dspy.OutputField()
    proposals = dspy.OutputField(desc="List of proposed edits in JSON.")

class ReflectionistModule(dspy.Module):
    def __init__(self, model="gpt-4o-mini"):
        super().__init__()
        self.lm = dspy.LM(model)

    def forward(self, instruction_text, final_answer, eval_json, memory_summary=""):
        result = self.lm(
            ReflectionistSignature(),
            instruction_text=instruction_text,
            final_answer=final_answer,
            eval_json=str(eval_json),
            memory_summary=memory_summary
        )
        return result

# ---------------------------
# 4. Counterfactual Tester
# ---------------------------
class CounterfactualSignature(dspy.Signature):
    """Test counterfactual edit on the problem."""
    problem_text = dspy.InputField()
    instruction_with_edit = dspy.InputField()
    cf_answer = dspy.OutputField()
    cf_score = dspy.OutputField(optional=True)
    cf_eval_notes = dspy.OutputField(optional=True)

class CounterfactualModule(dspy.Module):
    def __init__(self, model="gpt-4o-mini"):
        super().__init__()
        self.lm = dspy.LM(model)

    def forward(self, problem_text, instruction_with_edit):
        result = self.lm(
            CounterfactualSignature(),
            problem_text=problem_text,
            instruction_with_edit=instruction_with_edit
        )
        return result

# ---------------------------
# 5. Policy Composer
# ---------------------------
class PolicySignature(dspy.Signature):
    """Choose the next instruction edit to apply."""
    proposals = dspy.InputField()
    attribution_summary = dspy.InputField(optional=True)
    memory_summary = dspy.InputField(optional=True)
    next_instruction = dspy.OutputField()
    picked = dspy.OutputField(optional=True)

class PolicyComposerModule(dspy.Module):
    def __init__(self, model="gpt-4o-mini"):
        super().__init__()
        self.lm = dspy.LM(model)

    def forward(self, proposals, attribution_summary="", memory_summary=""):
        result = self.lm(
            PolicySignature(),
            proposals=str(proposals),
            attribution_summary=attribution_summary,
            memory_summary=memory_summary
        )
        return result
