"""RL Agent for instruction optimization"""
import numpy as np
import torch
import torch.nn as nn
from typing import Dict, Any, Optional, List, Tuple
from stable_baselines3 import PPO, A2C, SAC
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.policies import ActorCriticPolicy
import gymnasium as gym
from loguru import logger
import pickle
import os
import time

from ..utils.config import RLConfig
from ..environment.rl_environment import LLMOptimizationEnvironment

class CustomPolicyNetwork(ActorCriticPolicy):
    """Custom policy network for LLM instruction optimization"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # Add custom layers for instruction optimization
        self.instruction_features = nn.Sequential(
            nn.Linear(self.features_dim, 256),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(0.1)
        )
        
        # Separate heads for different action components
        self.prefix_head = nn.Linear(128, 32)
        self.modifier_head = nn.Linear(128, 32)
        self.format_head = nn.Linear(128, 32)
        self.meta_head = nn.Linear(128, 4)  # Temperature, creativity, etc.
        
    def forward_actor(self, features: torch.Tensor) -> torch.Tensor:
        """Forward pass for actor network"""
        
        instruction_features = self.instruction_features(features)
        
        # Combine different action components
        prefix_logits = self.prefix_head(instruction_features)
        modifier_logits = self.modifier_head(instruction_features)
        format_logits = self.format_head(instruction_features)
        meta_logits = self.meta_head(instruction_features)
        
        # Concatenate all action components
        action_logits = torch.cat([
            prefix_logits, modifier_logits, format_logits, meta_logits
        ], dim=-1)
        
        return action_logits

class TrainingCallback(BaseCallback):
    """Custom callback for training monitoring"""
    
    def __init__(self, save_freq: int = 1000, save_path: str = "./models/"):
        super().__init__()
        self.save_freq = save_freq
        self.save_path = save_path
        self.episode_rewards = []
        self.episode_lengths = []
        
    def _on_step(self) -> bool:
        # Log training progress
        if self.locals.get('done'):
            episode_reward = self.locals.get('episode_reward', 0)
            episode_length = self.locals.get('episode_length', 0)
            
            self.episode_rewards.append(episode_reward)
            self.episode_lengths.append(episode_length)
            
            if len(self.episode_rewards) % 10 == 0:
                avg_reward = np.mean(self.episode_rewards[-10:])
                avg_length = np.mean(self.episode_lengths[-10:])
                
                logger.info(f"Episode {len(self.episode_rewards)}: "
                          f"Avg Reward={avg_reward:.3f}, "
                          f"Avg Length={avg_length:.1f}")
        
        # Save model periodically
        if self.n_calls % self.save_freq == 0:
            model_path = os.path.join(self.save_path, f"model_step_{self.n_calls}")
            self.model.save(model_path)
            logger.info(f"Model saved at step {self.n_calls}")
        
        return True

class RLAgent:
    """RL Agent for optimizing LLM instructions"""
    
    def __init__(self, config: RLConfig, environment: LLMOptimizationEnvironment):
        self.config = config
        self.environment = environment
        self.model = None
        self.training_history = []
        
        # Create vectorized environment
        self.vec_env = DummyVecEnv([lambda: environment])
        
        # Initialize model based on algorithm
        self._initialize_model()
        
        # Training callback
        self.callback = TrainingCallback(
            save_freq=config.batch_size * 10,
            save_path="./models/"
        )
        
        # Performance tracking
        self.evaluation_history = []
        
    def _initialize_model(self):
        """Initialize RL model based on configuration"""
        
        common_kwargs = {
            'learning_rate': self.config.learning_rate,
            'verbose': 1,
            'tensorboard_log': "./tensorboard_logs/"
        }
        
        if self.config.algorithm == "PPO":
            self.model = PPO(
                "MlpPolicy",
                self.vec_env,
                batch_size=self.config.batch_size,
                gamma=self.config.gamma,
                gae_lambda=self.config.gae_lambda,
                clip_range=self.config.clip_range,
                ent_coef=self.config.entropy_coef,
                vf_coef=self.config.value_function_coef,
                max_grad_norm=self.config.max_grad_norm,
                **common_kwargs
            )
        elif self.config.algorithm == "A2C":
            self.model = A2C(
                "MlpPolicy",
                self.vec_env,
                gamma=self.config.gamma,
                gae_lambda=self.config.gae_lambda,
                ent_coef=self.config.entropy_coef,
                vf_coef=self.config.value_function_coef,
                max_grad_norm=self.config.max_grad_norm,
                **common_kwargs
            )
        elif self.config.algorithm == "SAC":
            self.model = SAC(
                "MlpPolicy",
                self.vec_env,
                buffer_size=self.config.buffer_size,
                batch_size=self.config.batch_size,
                gamma=self.config.gamma,
                **common_kwargs
            )
        else:
            raise ValueError(f"Unsupported algorithm: {self.config.algorithm}")
        
        logger.info(f"Initialized {self.config.algorithm} agent")
    
    async def train(self, total_timesteps: int, 
                   evaluation_tasks: Optional[List[Dict[str, Any]]] = None):
        """Train the RL agent"""
        
        logger.info(f"Starting training for {total_timesteps} timesteps")
        
        start_time = time.time()
        
        try:
            # Train the model
            self.model.learn(
                total_timesteps=total_timesteps,
                callback=self.callback,
                progress_bar=True
            )
            
            training_time = time.time() - start_time
            
            # Record training session
            training_session = {
                'timestamp': time.time(),
                'total_timesteps': total_timesteps,
                'training_time': training_time,
                'algorithm': self.config.algorithm,
                'final_episode_rewards': self.callback.episode_rewards[-10:] if self.callback.episode_rewards else []
            }
            
            self.training_history.append(training_session)
            
            logger.info(f"Training completed in {training_time:.2f}s")
            
            # Evaluate if tasks provided
            if evaluation_tasks:
                await self.evaluate(evaluation_tasks)
            
        except Exception as e:
            logger.error(f"Training failed: {str(e)}")
            raise
    
    async def evaluate(self, tasks: List[Dict[str, Any]], 
                      num_episodes_per_task: int = 5) -> Dict[str, Any]:
        """Evaluate agent performance on specific tasks"""
        
        logger.info(f"Evaluating agent on {len(tasks)} tasks")
        
        evaluation_results = {
            'timestamp': time.time(),
            'tasks': {},
            'overall_stats': {}
        }
        
        all_rewards = []
        all_success_rates = []
        
        for task in tasks:
            task_name = task.get('name', 'unnamed_task')
            task_rewards = []
            task_successes = []
            
            for episode in range(num_episodes_per_task):
                try:
                    # Reset environment with specific task
                    obs, info = await self.environment.reset(task)
                    
                    episode_reward = 0
                    done = False
                    step_count = 0
                    
                    while not done and step_count < 20:  # Max steps per episode
                        # Get action from trained model
                        action, _ = self.model.predict(obs, deterministic=True)
                        
                        # Take step
                        obs, reward, terminated, truncated, info = await self.environment.step(action)
                        
                        episode_reward += reward
                        done = terminated or truncated
                        step_count += 1
                    
                    task_rewards.append(episode_reward)
                    task_successes.append(info.get('task_success', False))
                    
                except Exception as e:
                    logger.error(f"Evaluation episode failed: {str(e)}")
                    task_rewards.append(0.0)
                    task_successes.append(False)
            
            # Calculate task statistics
            task_stats = {
                'avg_reward': np.mean(task_rewards),
                'std_reward': np.std(task_rewards),
                'success_rate': np.mean(task_successes),
                'episodes': num_episodes_per_task,
                'rewards': task_rewards
            }
            
            evaluation_results['tasks'][task_name] = task_stats
            all_rewards.extend(task_rewards)
            all_success_rates.extend(task_successes)
            
            logger.info(f"Task {task_name}: Avg Reward={task_stats['avg_reward']:.3f}, "
                       f"Success Rate={task_stats['success_rate']:.3f}")
        
        # Overall statistics
        evaluation_results['overall_stats'] = {
            'avg_reward': np.mean(all_rewards),
            'std_reward': np.std(all_rewards),
            'overall_success_rate': np.mean(all_success_rates),
            'total_episodes': len(all_rewards)
        }
        
        self.evaluation_history.append(evaluation_results)
        
        logger.info(f"Evaluation completed: Overall Success Rate={evaluation_results['overall_stats']['overall_success_rate']:.3f}")
        
        return evaluation_results
    
    def predict_action(self, observation: np.ndarray, deterministic: bool = True) -> Tuple[np.ndarray, Optional[np.ndarray]]:
        """Predict action for given observation"""
        
        if self.model is None:
            raise ValueError("Model not initialized. Train or load a model first.")
        
        return self.model.predict(observation, deterministic=deterministic)
    
    def save_model(self, path: str):
        """Save trained model"""
        
        if self.model is None:
            raise ValueError("No model to save")
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(path), exist_ok=True)
        
        # Save model
        self.model.save(path)
        
        # Save additional metadata
        metadata = {
            'config': self.config.dict(),
            'training_history': self.training_history,
            'evaluation_history': self.evaluation_history
        }
        
        with open(f"{path}_metadata.pkl", 'wb') as f:
            pickle.dump(metadata, f)
        
        logger.info(f"Model saved to {path}")
    
    def load_model(self, path: str):
        """Load trained model"""
        
        if self.config.algorithm == "PPO":
            self.model = PPO.load(path, env=self.vec_env)
        elif self.config.algorithm == "A2C":
            self.model = A2C.load(path, env=self.vec_env)
        elif self.config.algorithm == "SAC":
            self.model = SAC.load(path, env=self.vec_env)
        else:
            raise ValueError(f"Unsupported algorithm: {self.config.algorithm}")
        
        # Load metadata if available
        metadata_path = f"{path}_metadata.pkl"
        if os.path.exists(metadata_path):
            with open(metadata_path, 'rb') as f:
                metadata = pickle.load(f)
                self.training_history = metadata.get('training_history', [])
                self.evaluation_history = metadata.get('evaluation_history', [])
        
        logger.info(f"Model loaded from {path}")
    
    def get_training_stats(self) -> Dict[str, Any]:
        """Get training statistics"""
        
        if not self.training_history:
            return {}
        
        latest_session = self.training_history[-1]
        
        stats = {
            'total_training_sessions': len(self.training_history),
            'total_timesteps': sum(session['total_timesteps'] for session in self.training_history),
            'total_training_time': sum(session['training_time'] for session in self.training_history),
            'latest_session': latest_session,
            'recent_episode_rewards': self.callback.episode_rewards[-20:] if self.callback.episode_rewards else []
        }
        
        return stats
    
    def update_config(self, new_config: RLConfig):
        """Update agent configuration (requires reinitialization)"""
        
        logger.warning("Updating config requires model reinitialization")
        self.config = new_config
        self._initialize_model()