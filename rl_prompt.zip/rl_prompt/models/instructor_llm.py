"""Instructor LLM for generating optimized prompts"""
import asyncio
import aiohttp
import openai
import anthropic
from typing import Dict, Any, Optional, List
from loguru import logger
import time
import json

from ..utils.config import LLMConfig
from ..utils.action_decoder import ActionDecoder

class InstructorLLM:
    """LLM responsible for generating optimized prompts based on RL agent actions"""
    
    def __init__(self, config: LLMConfig):
        self.config = config
        self.action_decoder = ActionDecoder()
        
        # Initialize API clients
        if config.provider == "openai":
            self.client = openai.AsyncOpenAI(
                api_key=config.api_key,
                base_url=config.base_url
            )
        elif config.provider == "anthropic":
            self.client = anthropic.AsyncAnthropic(
                api_key=config.api_key
            )
        else:
            self.client = None
            
        # Performance tracking
        self.call_history: List[Dict] = []
        
    async def generate_optimized_instruction(self, 
                                           base_task: str,
                                           rl_action: np.ndarray,
                                           context: Optional[str] = None,
                                           task_type: str = "general") -> Dict[str, Any]:
        """Generate optimized instruction based on RL agent action"""
        
        start_time = time.time()
        
        try:
            # Decode RL action into prompt optimization components
            decoded_action = self.action_decoder.decode_action(rl_action)
            
            # Get LLM parameters from action
            llm_params = self.action_decoder.get_llm_parameters(decoded_action)
            
            # Construct meta-prompt for instruction generation
            meta_prompt = self._construct_meta_prompt(base_task, decoded_action, context, task_type)
            
            # Generate instruction using LLM
            instruction_response = await self._call_llm(meta_prompt, llm_params)
            
            # Extract generated instruction
            generated_instruction = self._extract_instruction(instruction_response)
            
            # Apply final optimizations based on decoded action
            final_instruction = self.action_decoder.construct_optimized_prompt(
                generated_instruction, decoded_action, context or ""
            )
            
            execution_time = time.time() - start_time
            
            result = {
                'instruction': final_instruction,
                'base_instruction': generated_instruction,
                'decoded_action': decoded_action,
                'llm_params': llm_params,
                'execution_time': execution_time,
                'meta_prompt': meta_prompt,
                'task_type': task_type
            }
            
            # Log performance
            self.call_history.append({
                'timestamp': time.time(),
                'execution_time': execution_time,
                'task_type': task_type,
                'success': True
            })
            
            logger.info(f"Generated optimized instruction in {execution_time:.2f}s")
            
            return result
            
        except Exception as e:
            logger.error(f"Error generating instruction: {str(e)}")
            
            # Log failure
            self.call_history.append({
                'timestamp': time.time(),
                'execution_time': time.time() - start_time,
                'task_type': task_type,
                'success': False,
                'error': str(e)
            })
            
            # Return fallback instruction
            return {
                'instruction': base_task,
                'base_instruction': base_task,
                'decoded_action': decoded_action,
                'llm_params': {},
                'execution_time': time.time() - start_time,
                'error': str(e),
                'task_type': task_type
            }
    
    def _construct_meta_prompt(self, base_task: str, decoded_action: Dict[str, Any], 
                              context: Optional[str], task_type: str) -> str:
        """Construct meta-prompt for instruction generation"""
        
        meta_prompt_parts = [
            "You are an expert prompt engineer. Your task is to optimize the given instruction to maximize task performance.",
            "",
            f"Task Type: {task_type}",
            f"Base Task: {base_task}",
        ]
        
        if context:
            meta_prompt_parts.extend([
                f"Context: {context}",
                ""
            ])
        
        meta_prompt_parts.extend([
            "Optimization Guidelines:",
            f"- Use this approach: {decoded_action['instruction_modifier']}",
            f"- Apply this formatting: {decoded_action['formatting_instruction']}",
            f"- Optimization focus: {decoded_action['weight_schema']}",
        ])
        
        if decoded_action['use_chain_of_thought']:
            meta_prompt_parts.append("- Include chain-of-thought reasoning prompts")
            
        if decoded_action['creativity_boost']:
            meta_prompt_parts.append("- Encourage creative and innovative thinking")
        
        meta_prompt_parts.extend([
            "",
            "Generate an optimized version of the base task that incorporates these guidelines.",
            "Focus on clarity, specificity, and task-appropriate instructions.",
            "Output only the optimized instruction, no additional commentary."
        ])
        
        return "\n".join(meta_prompt_parts)
    
    async def _call_llm(self, prompt: str, params: Dict[str, Any]) -> str:
        """Call the LLM API with given prompt and parameters"""
        
        # Merge config params with action-specific params
        final_params = {
            'temperature': params.get('temperature', self.config.temperature),
            'max_tokens': params.get('max_tokens', self.config.max_tokens)
        }
        
        if self.config.provider == "openai":
            response = await self.client.chat.completions.create(
                model=self.config.model,
                messages=[{"role": "user", "content": prompt}],
                **final_params
            )
            return response.choices[0].message.content
            
        elif self.config.provider == "anthropic":
            response = await self.client.messages.create(
                model=self.config.model,
                messages=[{"role": "user", "content": prompt}],
                **final_params
            )
            return response.content[0].text
            
        else:
            # Custom API implementation
            return await self._call_custom_api(prompt, final_params)
    
    async def _call_custom_api(self, prompt: str, params: Dict[str, Any]) -> str:
        """Call custom API endpoint"""
        
        if not self.config.base_url:
            raise ValueError("Base URL required for custom API")
        
        payload = {
            'prompt': prompt,
            'model': self.config.model,
            **params
        }
        
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.config.api_key}' if self.config.api_key else ''
        }
        
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=self.config.timeout)) as session:
            async with session.post(self.config.base_url, json=payload, headers=headers) as response:
                if response.status == 200:
                    result = await response.json()
                    return result.get('response', result.get('text', ''))
                else:
                    raise Exception(f"API call failed with status {response.status}")
    
    def _extract_instruction(self, response: str) -> str:
        """Extract instruction from LLM response"""
        
        # Clean up the response
        instruction = response.strip()
        
        # Remove common prefixes/suffixes
        prefixes_to_remove = [
            "Here's the optimized instruction:",
            "Optimized instruction:",
            "The optimized version is:",
            "Here is the optimized task:"
        ]
        
        for prefix in prefixes_to_remove:
            if instruction.lower().startswith(prefix.lower()):
                instruction = instruction[len(prefix):].strip()
        
        return instruction
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """Get performance statistics"""
        
        if not self.call_history:
            return {}
        
        recent_calls = self.call_history[-100:]  # Last 100 calls
        
        successful_calls = [call for call in recent_calls if call['success']]
        
        stats = {
            'total_calls': len(recent_calls),
            'successful_calls': len(successful_calls),
            'success_rate': len(successful_calls) / len(recent_calls) if recent_calls else 0,
            'avg_execution_time': np.mean([call['execution_time'] for call in successful_calls]) if successful_calls else 0,
            'min_execution_time': np.min([call['execution_time'] for call in successful_calls]) if successful_calls else 0,
            'max_execution_time': np.max([call['execution_time'] for call in successful_calls]) if successful_calls else 0
        }
        
        return stats
    
    async def health_check(self) -> bool:
        """Check if the LLM API is healthy"""
        
        try:
            test_response = await self._call_llm("Test prompt", {'max_tokens': 10})
            return len(test_response) > 0
        except Exception as e:
            logger.error(f"Health check failed: {str(e)}")
            return False