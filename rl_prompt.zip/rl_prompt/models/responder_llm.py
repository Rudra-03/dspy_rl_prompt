"""Responder LLM for processing optimized prompts"""
import asyncio
import aiohttp
import openai
import anthropic
from typing import Dict, Any, Optional, List
from loguru import logger
import time
import json
import numpy as np

from ..utils.config import LLMConfig

class ResponderLLM:
    """LLM responsible for processing optimized prompts and generating responses"""
    
    def __init__(self, config: LLMConfig):
        self.config = config
        
        # Initialize API clients
        if config.provider == "openai":
            self.client = openai.AsyncOpenAI(
                api_key=config.api_key,
                base_url=config.base_url
            )
        elif config.provider == "anthropic":
            self.client = anthropic.AsyncAnthropic(
                api_key=config.api_key
            )
        else:
            self.client = None
            
        # Performance tracking
        self.call_history: List[Dict] = []
        
    async def process_instruction(self, 
                                instruction: str,
                                task_context: Optional[Dict[str, Any]] = None,
                                tools: Optional[List[Dict]] = None) -> Dict[str, Any]:
        """Process instruction and generate response"""
        
        start_time = time.time()
        
        try:
            # Prepare the prompt with context and tools if available
            full_prompt = self._prepare_full_prompt(instruction, task_context, tools)
            
            # Call LLM API
            response = await self._call_llm(full_prompt)
            
            # Process response for tool calls if needed
            processed_response = await self._process_response(response, tools)
            
            execution_time = time.time() - start_time
            
            result = {
                'response': processed_response['final_response'],
                'raw_response': response,
                'tool_calls': processed_response.get('tool_calls', []),
                'execution_time': execution_time,
                'token_count': self._estimate_tokens(full_prompt + response),
                'success': True,
                'metadata': {
                    'has_tools': bool(tools),
                    'context_provided': bool(task_context),
                    'response_length': len(response),
                    'tool_executions': len(processed_response.get('tool_calls', []))
                }
            }
            
            # Log performance
            self.call_history.append({
                'timestamp': time.time(),
                'execution_time': execution_time,
                'token_count': result['token_count'],
                'success': True,
                'has_tools': bool(tools)
            })
            
            logger.info(f"Processed instruction in {execution_time:.2f}s, {result['token_count']} tokens")
            
            return result
            
        except Exception as e:
            logger.error(f"Error processing instruction: {str(e)}")
            
            execution_time = time.time() - start_time
            
            # Log failure
            self.call_history.append({
                'timestamp': time.time(),
                'execution_time': execution_time,
                'success': False,
                'error': str(e)
            })
            
            return {
                'response': f"Error processing instruction: {str(e)}",
                'raw_response': "",
                'tool_calls': [],
                'execution_time': execution_time,
                'token_count': 0,
                'success': False,
                'error': str(e),
                'metadata': {}
            }
    
    def _prepare_full_prompt(self, instruction: str, 
                           task_context: Optional[Dict[str, Any]], 
                           tools: Optional[List[Dict]]) -> str:
        """Prepare the full prompt with context and tool information"""
        
        prompt_parts = []
        
        # Add system context if available
        if task_context:
            if 'system_message' in task_context:
                prompt_parts.append(f"System: {task_context['system_message']}")
            
            if 'previous_interactions' in task_context:
                prompt_parts.append("Previous interactions:")
                for interaction in task_context['previous_interactions'][-3:]:  # Last 3
                    prompt_parts.append(f"Q: {interaction.get('question', '')}")
                    prompt_parts.append(f"A: {interaction.get('answer', '')}")
        
        # Add tool information if available
        if tools:
            prompt_parts.append("Available tools:")
            for tool in tools:
                tool_desc = f"- {tool['name']}: {tool.get('description', '')}"
                if 'parameters' in tool:
                    tool_desc += f" (Parameters: {', '.join(tool['parameters'].keys())})"
                prompt_parts.append(tool_desc)
            
            prompt_parts.append("Use tools when necessary by calling them in your response.")
        
        # Add main instruction
        prompt_parts.append("")
        prompt_parts.append("Task:")
        prompt_parts.append(instruction)
        
        return "\n".join(prompt_parts)
    
    async def _call_llm(self, prompt: str) -> str:
        """Call the LLM API"""
        
        if self.config.provider == "openai":
            response = await self.client.chat.completions.create(
                model=self.config.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens
            )
            return response.choices[0].message.content
            
        elif self.config.provider == "anthropic":
            response = await self.client.messages.create(
                model=self.config.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens
            )
            return response.content[0].text
            
        else:
            return await self._call_custom_api(prompt)
    
    async def _call_custom_api(self, prompt: str) -> str:
        """Call custom API endpoint"""
        
        if not self.config.base_url:
            raise ValueError("Base URL required for custom API")
        
        payload = {
            'prompt': prompt,
            'model': self.config.model,
            'temperature': self.config.temperature,
            'max_tokens': self.config.max_tokens
        }
        
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.config.api_key}' if self.config.api_key else ''
        }
        
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=self.config.timeout)) as session:
            async with session.post(self.config.base_url, json=payload, headers=headers) as response:
                if response.status == 200:
                    result = await response.json()
                    return result.get('response', result.get('text', ''))
                else:
                    raise Exception(f"API call failed with status {response.status}")
    
    async def _process_response(self, response: str, tools: Optional[List[Dict]]) -> Dict[str, Any]:
        """Process response and execute tool calls if needed"""
        
        result = {
            'final_response': response,
            'tool_calls': []
        }
        
        if not tools:
            return result
        
        # Simple tool call detection (in practice, this would be more sophisticated)
        tool_calls = self._extract_tool_calls(response, tools)
        
        if tool_calls:
            # Execute tool calls
            tool_results = []
            for tool_call in tool_calls:
                try:
                    tool_result = await self._execute_tool_call(tool_call)
                    tool_results.append(tool_result)
                except Exception as e:
                    logger.error(f"Tool execution failed: {str(e)}")
                    tool_results.append({'error': str(e)})
            
            result['tool_calls'] = tool_calls
            result['tool_results'] = tool_results
            
            # Update response with tool results if needed
            if tool_results:
                updated_response = self._integrate_tool_results(response, tool_results)
                result['final_response'] = updated_response
        
        return result
    
    def _extract_tool_calls(self, response: str, tools: List[Dict]) -> List[Dict]:
        """Extract tool calls from response"""
        
        tool_calls = []
        
        # Simple pattern matching for tool calls
        # In practice, this would use more sophisticated parsing
        for tool in tools:
            tool_name = tool['name']
            if f"call_{tool_name}" in response.lower() or f"{tool_name}(" in response:
                # Extract parameters (simplified)
                tool_call = {
                    'name': tool_name,
                    'parameters': {},  # Would extract actual parameters
                    'raw_call': response  # For debugging
                }
                tool_calls.append(tool_call)
        
        return tool_calls
    
    async def _execute_tool_call(self, tool_call: Dict) -> Dict[str, Any]:
        """Execute a tool call (mock implementation)"""
        
        # Mock tool execution
        # In practice, this would call actual tools/APIs
        
        tool_name = tool_call['name']
        
        if tool_name == "calculator":
            return {'result': 42, 'type': 'calculation'}
        elif tool_name == "search":
            return {'result': 'Mock search results', 'type': 'search'}
        elif tool_name == "database":
            return {'result': {'data': 'mock_data'}, 'type': 'database'}
        else:
            return {'result': f'Mock result for {tool_name}', 'type': 'generic'}
    
    def _integrate_tool_results(self, original_response: str, tool_results: List[Dict]) -> str:
        """Integrate tool results into the response"""
        
        # Simple integration - append results
        integrated_response = original_response
        
        if tool_results:
            integrated_response += "\n\nTool Results:"
            for i, result in enumerate(tool_results):
                integrated_response += f"\n{i+1}. {result.get('result', 'No result')}"
        
        return integrated_response
    
    def _estimate_tokens(self, text: str) -> int:
        """Estimate token count (rough approximation)"""
        # Rough approximation: 1 token ≈ 4 characters
        return len(text) // 4
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """Get performance statistics"""
        
        if not self.call_history:
            return {}
        
        recent_calls = self.call_history[-100:]  # Last 100 calls
        successful_calls = [call for call in recent_calls if call['success']]
        
        stats = {
            'total_calls': len(recent_calls),
            'successful_calls': len(successful_calls),
            'success_rate': len(successful_calls) / len(recent_calls) if recent_calls else 0,
            'avg_execution_time': np.mean([call['execution_time'] for call in successful_calls]) if successful_calls else 0,
            'avg_token_count': np.mean([call.get('token_count', 0) for call in successful_calls]) if successful_calls else 0,
            'total_tokens': sum([call.get('token_count', 0) for call in successful_calls]),
            'tool_usage_rate': np.mean([call.get('has_tools', False) for call in recent_calls]) if recent_calls else 0
        }
        
        return stats
    
    async def health_check(self) -> bool:
        """Check if the LLM API is healthy"""
        
        try:
            test_response = await self._call_llm("Test prompt for health check")
            return len(test_response) > 0
        except Exception as e:
            logger.error(f"Health check failed: {str(e)}")
            return False