"""Configuration management for RL-LLM Optimizer"""
import os
from typing import Dict, Any, Optional
from pydantic import BaseModel
from dotenv import load_dotenv

load_dotenv()

class LLMConfig(BaseModel):
    """Configuration for LLM APIs"""
    provider: str  # "openai", "anthropic", "custom"
    model: str
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    temperature: float = 0.7
    max_tokens: int = 2048
    timeout: int = 30

class RLConfig(BaseModel):
    """Configuration for RL Agent"""
    algorithm: str = "PPO"  # PPO, A2C, SAC
    learning_rate: float = 3e-4
    batch_size: int = 64
    buffer_size: int = 10000
    gamma: float = 0.99
    gae_lambda: float = 0.95
    clip_range: float = 0.2
    entropy_coef: float = 0.01
    value_function_coef: float = 0.5
    max_grad_norm: float = 0.5

class EnvironmentConfig(BaseModel):
    """Configuration for RL Environment"""
    max_episode_length: int = 10
    reward_threshold: float = 0.8
    state_history_length: int = 5
    action_space_size: int = 100
    observation_space_size: int = 512

class SystemConfig(BaseModel):
    """Main system configuration"""
    instructor_llm: LLMConfig
    responder_llm: LLMConfig
    rl_config: RLConfig
    env_config: EnvironmentConfig
    redis_url: str = "redis://localhost:6379"
    log_level: str = "INFO"
    experiment_name: str = "rl_llm_optimization"
    save_frequency: int = 100
    evaluation_frequency: int = 50

def get_default_config() -> SystemConfig:
    """Get default system configuration"""
    return SystemConfig(
        instructor_llm=LLMConfig(
            provider="openai",
            model="gpt-4",
            api_key=os.getenv("OPENAI_API_KEY"),
            temperature=0.8
        ),
        responder_llm=LLMConfig(
            provider="openai", 
            model="gpt-4",
            api_key=os.getenv("OPENAI_API_KEY"),
            temperature=0.3
        ),
        rl_config=RLConfig(),
        env_config=EnvironmentConfig()
    )

def load_config(config_path: Optional[str] = None) -> SystemConfig:
    """Load configuration from file or environment"""
    if config_path and os.path.exists(config_path):
        import json
        with open(config_path, 'r') as f:
            config_dict = json.load(f)
        return SystemConfig(**config_dict)
    return get_default_config()