"""State encoder for RL environment"""
import numpy as np
from typing import List, Dict, Any, Optional
from sentence_transformers import SentenceTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
import torch
import json

class StateEncoder:
    """Encodes instruction-outcome traces into state representations"""
    
    def __init__(self, embedding_dim: int = 384, history_length: int = 5):
        self.embedding_dim = embedding_dim
        self.history_length = history_length
        
        # Initialize sentence transformer for semantic encoding
        self.sentence_model = SentenceTransformer('all-MiniLM-L6-v2')
        
        # TF-IDF for keyword importance
        self.tfidf = TfidfVectorizer(max_features=100, stop_words='english')
        self.tfidf_fitted = False
        
        # State history buffer
        self.state_history: List[Dict[str, Any]] = []
        
    def encode_instruction_outcome(self, instruction: str, outcome: str, 
                                 reward: float, metadata: Optional[Dict] = None) -> np.ndarray:
        """Encode a single instruction-outcome pair"""
        
        # Semantic embeddings
        instruction_emb = self.sentence_model.encode(instruction)
        outcome_emb = self.sentence_model.encode(outcome)
        
        # Combine instruction and outcome
        combined_text = f"{instruction} [SEP] {outcome}"
        combined_emb = self.sentence_model.encode(combined_text)
        
        # Reward signal
        reward_features = np.array([
            reward,
            1.0 if reward > 0.5 else 0.0,  # Success indicator
            len(instruction.split()),  # Instruction length
            len(outcome.split()),  # Outcome length
        ])
        
        # Metadata features
        meta_features = np.zeros(10)
        if metadata:
            meta_features[0] = metadata.get('execution_time', 0.0) / 100.0  # Normalized
            meta_features[1] = metadata.get('api_calls', 0) / 10.0  # Normalized
            meta_features[2] = metadata.get('tool_usage', 0) / 5.0  # Normalized
            meta_features[3] = 1.0 if metadata.get('error', False) else 0.0
        
        # Concatenate all features
        state_vector = np.concatenate([
            instruction_emb,
            outcome_emb, 
            combined_emb,
            reward_features,
            meta_features
        ])
        
        return state_vector
    
    def update_history(self, instruction: str, outcome: str, reward: float, 
                      metadata: Optional[Dict] = None):
        """Update state history with new instruction-outcome pair"""
        entry = {
            'instruction': instruction,
            'outcome': outcome,
            'reward': reward,
            'metadata': metadata or {},
            'timestamp': np.datetime64('now')
        }
        
        self.state_history.append(entry)
        
        # Keep only recent history
        if len(self.state_history) > self.history_length:
            self.state_history = self.state_history[-self.history_length:]
    
    def get_current_state(self) -> np.ndarray:
        """Get current state representation from history"""
        if not self.state_history:
            # Return zero state if no history
            return np.zeros(self.embedding_dim * 3 + 14)  # Match encoding dimensions
        
        # Encode recent history
        state_vectors = []
        for entry in self.state_history[-self.history_length:]:
            vector = self.encode_instruction_outcome(
                entry['instruction'],
                entry['outcome'],
                entry['reward'],
                entry['metadata']
            )
            state_vectors.append(vector)
        
        # Pad or truncate to fixed length
        while len(state_vectors) < self.history_length:
            state_vectors.insert(0, np.zeros_like(state_vectors[0] if state_vectors else 
                                                np.zeros(self.embedding_dim * 3 + 14)))
        
        state_vectors = state_vectors[-self.history_length:]
        
        # Aggregate state vectors (mean pooling + recent emphasis)
        weights = np.exp(np.linspace(-1, 0, len(state_vectors)))  # Recent emphasis
        weights = weights / weights.sum()
        
        aggregated_state = np.average(state_vectors, axis=0, weights=weights)
        
        # Add temporal features
        temporal_features = self._extract_temporal_features()
        
        final_state = np.concatenate([aggregated_state, temporal_features])
        
        return final_state.astype(np.float32)
    
    def _extract_temporal_features(self) -> np.ndarray:
        """Extract temporal patterns from history"""
        if len(self.state_history) < 2:
            return np.zeros(8)
        
        rewards = [entry['reward'] for entry in self.state_history]
        
        features = np.array([
            np.mean(rewards),  # Average reward
            np.std(rewards),   # Reward variance
            rewards[-1] - rewards[0] if len(rewards) > 1 else 0,  # Reward trend
            np.max(rewards),   # Best reward
            np.min(rewards),   # Worst reward
            len(self.state_history) / self.history_length,  # History fullness
            1.0 if len(rewards) > 1 and rewards[-1] > rewards[-2] else 0.0,  # Improving
            np.sum([1 for r in rewards if r > 0.5]) / len(rewards)  # Success rate
        ])
        
        return features
    
    def reset(self):
        """Reset state history"""
        self.state_history = []
    
    def get_state_dimension(self) -> int:
        """Get the dimension of state vectors"""
        return self.embedding_dim * 3 + 14 + 8  # Base features + temporal features