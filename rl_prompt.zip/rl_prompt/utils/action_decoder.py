"""Action decoder for RL agent actions"""
import numpy as np
from typing import Dict, List, Any, Tuple
import json

class ActionDecoder:
    """Decodes RL agent actions into prompt optimization markers"""
    
    def __init__(self, action_dim: int = 100):
        self.action_dim = action_dim
        
        # Define action space components
        self.prefix_tokens = [
            "Think step by step:",
            "Let's approach this systematically:",
            "Consider the following:",
            "To solve this problem:",
            "Breaking this down:",
            "First, let's analyze:",
            "The key insight is:",
            "Important to note:",
        ]
        
        self.instruction_modifiers = [
            "Be more specific",
            "Provide examples", 
            "Explain your reasoning",
            "Consider edge cases",
            "Focus on accuracy",
            "Be concise",
            "Include step-by-step process",
            "Verify your answer"
        ]
        
        self.formatting_instructions = [
            "Format as JSON",
            "Use bullet points",
            "Provide numbered steps",
            "Include confidence score",
            "Highlight key points",
            "Use clear headings",
            "Structure your response",
            "Summarize at the end"
        ]
        
        self.emphasis_markers = [
            "IMPORTANT:",
            "CRITICAL:",
            "NOTE:",
            "WARNING:",
            "REMEMBER:",
            "KEY POINT:",
            "FOCUS:",
            "ESSENTIAL:"
        ]
        
        # Weighting schemas
        self.weight_schemas = {
            'accuracy_focused': {'accuracy': 0.8, 'speed': 0.1, 'creativity': 0.1},
            'speed_focused': {'accuracy': 0.3, 'speed': 0.6, 'creativity': 0.1},
            'creative_focused': {'accuracy': 0.3, 'speed': 0.1, 'creativity': 0.6},
            'balanced': {'accuracy': 0.4, 'speed': 0.3, 'creativity': 0.3}
        }
    
    def decode_action(self, action: np.ndarray) -> Dict[str, Any]:
        """Decode action vector into prompt optimization components"""
        
        # Normalize action to [0, 1]
        action = np.clip(action, -1, 1)
        action_normalized = (action + 1) / 2
        
        # Split action into components
        prefix_idx = int(action_normalized[0] * len(self.prefix_tokens))
        modifier_idx = int(action_normalized[1] * len(self.instruction_modifiers))
        format_idx = int(action_normalized[2] * len(self.formatting_instructions))
        emphasis_idx = int(action_normalized[3] * len(self.emphasis_markers))
        
        # Weighting schema selection
        weight_prob = action_normalized[4:8]
        weight_schema_idx = np.argmax(weight_prob)
        weight_schemas = list(self.weight_schemas.keys())
        selected_schema = weight_schemas[weight_schema_idx % len(weight_schemas)]
        
        # Temperature and creativity controls
        temperature = 0.1 + action_normalized[8] * 0.9  # 0.1 to 1.0
        creativity_boost = action_normalized[9] > 0.5
        
        # Additional parameters
        max_tokens_multiplier = 0.5 + action_normalized[10] * 1.0  # 0.5x to 1.5x
        repetition_penalty = 1.0 + action_normalized[11] * 0.2  # 1.0 to 1.2
        
        # Meta-prompt construction flags
        use_chain_of_thought = action_normalized[12] > 0.5
        use_few_shot = action_normalized[13] > 0.5
        use_self_critique = action_normalized[14] > 0.5
        
        decoded_action = {
            'prefix_token': self.prefix_tokens[prefix_idx % len(self.prefix_tokens)],
            'instruction_modifier': self.instruction_modifiers[modifier_idx % len(self.instruction_modifiers)],
            'formatting_instruction': self.formatting_instructions[format_idx % len(self.formatting_instructions)],
            'emphasis_marker': self.emphasis_markers[emphasis_idx % len(self.emphasis_markers)],
            'weight_schema': selected_schema,
            'temperature': temperature,
            'creativity_boost': creativity_boost,
            'max_tokens_multiplier': max_tokens_multiplier,
            'repetition_penalty': repetition_penalty,
            'use_chain_of_thought': use_chain_of_thought,
            'use_few_shot': use_few_shot,
            'use_self_critique': use_self_critique,
            'raw_action': action.tolist()
        }
        
        return decoded_action
    
    def construct_optimized_prompt(self, base_instruction: str, 
                                 decoded_action: Dict[str, Any],
                                 task_context: str = "") -> str:
        """Construct optimized prompt using decoded action"""
        
        components = []
        
        # Add emphasis marker if needed
        if decoded_action['creativity_boost']:
            components.append(decoded_action['emphasis_marker'])
        
        # Add prefix token
        components.append(decoded_action['prefix_token'])
        
        # Add task context if provided
        if task_context:
            components.append(f"Context: {task_context}")
        
        # Chain of thought prompting
        if decoded_action['use_chain_of_thought']:
            components.append("Think through this step by step, showing your reasoning:")
        
        # Add main instruction with modifier
        modified_instruction = f"{base_instruction}\n\n{decoded_action['instruction_modifier']}."
        components.append(modified_instruction)
        
        # Few-shot examples (placeholder - would be task-specific)
        if decoded_action['use_few_shot']:
            components.append("Here are some examples of good responses:")
            components.append("[Examples would be inserted here based on task type]")
        
        # Formatting instructions
        components.append(f"Response format: {decoded_action['formatting_instruction']}")
        
        # Self-critique instruction
        if decoded_action['use_self_critique']:
            components.append("After providing your answer, briefly critique it and suggest any improvements.")
        
        # Weight schema as instruction
        schema = self.weight_schemas[decoded_action['weight_schema']]
        weight_instruction = f"Prioritize: {', '.join([f'{k}({v:.1f})' for k, v in schema.items()])}"
        components.append(weight_instruction)
        
        # Combine all components
        optimized_prompt = "\n\n".join(components)
        
        return optimized_prompt
    
    def get_llm_parameters(self, decoded_action: Dict[str, Any], 
                          base_max_tokens: int = 1000) -> Dict[str, Any]:
        """Get LLM API parameters based on decoded action"""
        
        return {
            'temperature': decoded_action['temperature'],
            'max_tokens': int(base_max_tokens * decoded_action['max_tokens_multiplier']),
            'frequency_penalty': decoded_action['repetition_penalty'] - 1.0,
            'presence_penalty': 0.1 if decoded_action['creativity_boost'] else 0.0,
            'top_p': 0.9 if decoded_action['creativity_boost'] else 0.7
        }
    
    def action_to_string(self, decoded_action: Dict[str, Any]) -> str:
        """Convert decoded action to human-readable string"""
        
        summary = []
        summary.append(f"Prefix: {decoded_action['prefix_token']}")
        summary.append(f"Modifier: {decoded_action['instruction_modifier']}")
        summary.append(f"Format: {decoded_action['formatting_instruction']}")
        summary.append(f"Schema: {decoded_action['weight_schema']}")
        summary.append(f"Temperature: {decoded_action['temperature']:.2f}")
        
        flags = []
        if decoded_action['use_chain_of_thought']:
            flags.append("CoT")
        if decoded_action['use_few_shot']:
            flags.append("Few-shot")
        if decoded_action['use_self_critique']:
            flags.append("Self-critique")
        if decoded_action['creativity_boost']:
            flags.append("Creative")
            
        if flags:
            summary.append(f"Flags: {', '.join(flags)}")
        
        return " | ".join(summary)
    
    def sample_random_action(self) -> np.ndarray:
        """Sample a random action for exploration"""
        return np.random.uniform(-1, 1, self.action_dim)