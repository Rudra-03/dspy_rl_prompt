"""Benchmark tasks for evaluating RL-LLM optimization"""
from typing import List, Dict, Any
import json

class BenchmarkTasks:
    """Collection of benchmark tasks for evaluation"""
    
    def __init__(self):
        self.tasks = self._initialize_tasks()
    
    def _initialize_tasks(self) -> Dict[str, List[Dict[str, Any]]]:
        """Initialize all benchmark task categories"""
        
        return {
            'question_answering': self._get_qa_tasks(),
            'tool_augmented': self._get_tool_tasks(),
            'workflow_automation': self._get_workflow_tasks(),
            'creative_writing': self._get_creative_tasks(),
            'code_generation': self._get_code_tasks(),
            'reasoning': self._get_reasoning_tasks()
        }
    
    def _get_qa_tasks(self) -> List[Dict[str, Any]]:
        """Question answering benchmark tasks"""
        
        return [
            {
                'name': 'factual_qa_science',
                'type': 'question_answering',
                'description': 'What is photosynthesis and why is it important for life on Earth?',
                'context': 'This is a biology question requiring factual accuracy and clear explanation.',
                'expected_keywords': ['chlorophyll', 'carbon dioxide', 'oxygen', 'glucose', 'sunlight'],
                'difficulty': 'medium'
            },
            {
                'name': 'factual_qa_history',
                'type': 'question_answering', 
                'description': 'Explain the causes and consequences of World War I.',
                'context': 'This is a history question requiring comprehensive analysis.',
                'expected_keywords': ['assassination', 'alliances', 'trench warfare', 'treaty'],
                'difficulty': 'hard'
            },
            {
                'name': 'conceptual_qa_math',
                'type': 'question_answering',
                'description': 'Explain the concept of derivatives in calculus with a simple example.',
                'context': 'This is a mathematics question requiring both theory and practical example.',
                'expected_keywords': ['rate of change', 'slope', 'limit', 'function'],
                'difficulty': 'medium'
            },
            {
                'name': 'analytical_qa_literature',
                'type': 'question_answering',
                'description': 'Analyze the theme of isolation in "The Great Gatsby".',
                'context': 'This is a literature analysis question requiring critical thinking.',
                'expected_keywords': ['Gatsby', 'American Dream', 'social class', 'symbolism'],
                'difficulty': 'hard'
            }
        ]
    
    def _get_tool_tasks(self) -> List[Dict[str, Any]]:
        """Tool-augmented reasoning tasks"""
        
        return [
            {
                'name': 'calculator_math_problem',
                'type': 'tool_augmented',
                'description': 'Calculate the compound interest on $10,000 invested at 5% annual rate for 10 years.',
                'context': 'Use calculator tool for precise calculations.',
                'tools': [
                    {
                        'name': 'calculator',
                        'description': 'Perform mathematical calculations',
                        'parameters': {'expression': 'string'}
                    }
                ],
                'expected_result_range': [16000, 17000],
                'difficulty': 'easy'
            },
            {
                'name': 'search_current_events',
                'type': 'tool_augmented',
                'description': 'Find and summarize the latest developments in artificial intelligence research.',
                'context': 'Use search tool to find current information.',
                'tools': [
                    {
                        'name': 'search',
                        'description': 'Search for current information',
                        'parameters': {'query': 'string', 'date_range': 'string'}
                    }
                ],
                'expected_keywords': ['AI', 'research', 'breakthrough', 'technology'],
                'difficulty': 'medium'
            },
            {
                'name': 'database_query_analysis',
                'type': 'tool_augmented',
                'description': 'Analyze customer purchase patterns from the sales database.',
                'context': 'Use database tool to query and analyze data.',
                'tools': [
                    {
                        'name': 'database',
                        'description': 'Query database for information',
                        'parameters': {'query': 'string', 'table': 'string'}
                    }
                ],
                'expected_keywords': ['customers', 'purchases', 'patterns', 'analysis'],
                'difficulty': 'hard'
            }
        ]
    
    def _get_workflow_tasks(self) -> List[Dict[str, Any]]:
        """Workflow automation tasks"""
        
        return [
            {
                'name': 'email_processing_workflow',
                'type': 'workflow_automation',
                'description': 'Create a workflow to automatically categorize and respond to customer support emails.',
                'context': 'Design a multi-step process for email handling.',
                'steps': [
                    'Email classification',
                    'Priority assignment', 
                    'Response generation',
                    'Escalation handling'
                ],
                'difficulty': 'medium'
            },
            {
                'name': 'data_pipeline_design',
                'type': 'workflow_automation',
                'description': 'Design a data processing pipeline for real-time analytics.',
                'context': 'Create an end-to-end data workflow.',
                'steps': [
                    'Data ingestion',
                    'Data validation',
                    'Data transformation',
                    'Analytics computation',
                    'Result storage'
                ],
                'difficulty': 'hard'
            },
            {
                'name': 'content_moderation_workflow',
                'type': 'workflow_automation',
                'description': 'Design an automated content moderation system for social media posts.',
                'context': 'Create a workflow for content review and action.',
                'steps': [
                    'Content analysis',
                    'Policy checking',
                    'Risk assessment',
                    'Action determination'
                ],
                'difficulty': 'medium'
            }
        ]
    
    def _get_creative_tasks(self) -> List[Dict[str, Any]]:
        """Creative writing and generation tasks"""
        
        return [
            {
                'name': 'story_generation',
                'type': 'creative_writing',
                'description': 'Write a short story about a time traveler who accidentally changes history.',
                'context': 'Create an engaging narrative with character development.',
                'requirements': [
                    'Clear plot structure',
                    'Character development',
                    'Engaging dialogue',
                    'Satisfying resolution'
                ],
                'difficulty': 'medium'
            },
            {
                'name': 'marketing_copy',
                'type': 'creative_writing',
                'description': 'Create compelling marketing copy for a new eco-friendly smartphone.',
                'context': 'Write persuasive marketing content.',
                'requirements': [
                    'Clear value proposition',
                    'Emotional appeal',
                    'Call to action',
                    'Brand consistency'
                ],
                'difficulty': 'medium'
            },
            {
                'name': 'poem_composition',
                'type': 'creative_writing',
                'description': 'Compose a poem about the beauty of nature using metaphors and imagery.',
                'context': 'Create artistic expression through poetry.',
                'requirements': [
                    'Vivid imagery',
                    'Metaphorical language',
                    'Rhythmic flow',
                    'Emotional resonance'
                ],
                'difficulty': 'hard'
            }
        ]
    
    def _get_code_tasks(self) -> List[Dict[str, Any]]:
        """Code generation and programming tasks"""
        
        return [
            {
                'name': 'python_function_basic',
                'type': 'code_generation',
                'description': 'Write a Python function that calculates the factorial of a number.',
                'context': 'Create clean, efficient code with proper error handling.',
                'requirements': [
                    'Correct algorithm implementation',
                    'Error handling',
                    'Clear documentation',
                    'Test cases'
                ],
                'difficulty': 'easy'
            },
            {
                'name': 'api_integration',
                'type': 'code_generation',
                'description': 'Create a Python script that fetches weather data from an API and processes it.',
                'context': 'Implement API integration with data processing.',
                'requirements': [
                    'API authentication',
                    'Error handling',
                    'Data parsing',
                    'Output formatting'
                ],
                'difficulty': 'medium'
            },
            {
                'name': 'algorithm_optimization',
                'type': 'code_generation',
                'description': 'Implement an efficient sorting algorithm and analyze its time complexity.',
                'context': 'Create optimized code with complexity analysis.',
                'requirements': [
                    'Efficient implementation',
                    'Complexity analysis',
                    'Performance testing',
                    'Documentation'
                ],
                'difficulty': 'hard'
            }
        ]
    
    def _get_reasoning_tasks(self) -> List[Dict[str, Any]]:
        """Logical reasoning and problem-solving tasks"""
        
        return [
            {
                'name': 'logical_puzzle',
                'type': 'reasoning',
                'description': 'Solve this logic puzzle: Five people live in five houses of different colors. Each person drinks a different beverage and owns a different pet. Use the given clues to determine who owns the fish.',
                'context': 'Apply logical deduction to solve the puzzle.',
                'clues': [
                    'The British person lives in the red house',
                    'The Swedish person keeps dogs as pets',
                    'The Danish person drinks tea',
                    'The green house is on the left of the white house',
                    'The green house owner drinks coffee'
                ],
                'difficulty': 'hard'
            },
            {
                'name': 'mathematical_reasoning',
                'type': 'reasoning',
                'description': 'If a train travels 120 miles in 2 hours, and then increases its speed by 50% for the next 3 hours, how far does it travel in total?',
                'context': 'Apply mathematical reasoning to solve the problem step by step.',
                'expected_answer': 390,
                'difficulty': 'medium'
            },
            {
                'name': 'causal_reasoning',
                'type': 'reasoning',
                'description': 'Analyze the potential causes and effects of implementing a 4-day work week in a technology company.',
                'context': 'Use causal reasoning to analyze complex relationships.',
                'aspects': [
                    'Employee productivity',
                    'Work-life balance',
                    'Company costs',
                    'Customer satisfaction',
                    'Competitive advantage'
                ],
                'difficulty': 'hard'
            }
        ]
    
    def get_tasks_by_category(self, category: str) -> List[Dict[str, Any]]:
        """Get tasks by category"""
        return self.tasks.get(category, [])
    
    def get_all_tasks(self) -> List[Dict[str, Any]]:
        """Get all tasks across categories"""
        all_tasks = []
        for category_tasks in self.tasks.values():
            all_tasks.extend(category_tasks)
        return all_tasks
    
    def get_tasks_by_difficulty(self, difficulty: str) -> List[Dict[str, Any]]:
        """Get tasks by difficulty level"""
        filtered_tasks = []
        for category_tasks in self.tasks.values():
            for task in category_tasks:
                if task.get('difficulty') == difficulty:
                    filtered_tasks.append(task)
        return filtered_tasks
    
    def get_evaluation_suite(self, categories: List[str] = None, 
                           difficulties: List[str] = None,
                           max_tasks_per_category: int = 2) -> List[Dict[str, Any]]:
        """Get a balanced evaluation suite"""
        
        if categories is None:
            categories = list(self.tasks.keys())
        
        if difficulties is None:
            difficulties = ['easy', 'medium', 'hard']
        
        evaluation_tasks = []
        
        for category in categories:
            category_tasks = self.get_tasks_by_category(category)
            
            # Filter by difficulty if specified
            if difficulties:
                category_tasks = [
                    task for task in category_tasks 
                    if task.get('difficulty') in difficulties
                ]
            
            # Limit number of tasks per category
            selected_tasks = category_tasks[:max_tasks_per_category]
            evaluation_tasks.extend(selected_tasks)
        
        return evaluation_tasks
    
    def create_custom_task(self, name: str, task_type: str, description: str,
                          context: str = "", difficulty: str = "medium",
                          **kwargs) -> Dict[str, Any]:
        """Create a custom task"""
        
        task = {
            'name': name,
            'type': task_type,
            'description': description,
            'context': context,
            'difficulty': difficulty,
            **kwargs
        }
        
        return task
    
    def save_tasks_to_file(self, filepath: str):
        """Save all tasks to JSON file"""
        with open(filepath, 'w') as f:
            json.dump(self.tasks, f, indent=2)
    
    def load_tasks_from_file(self, filepath: str):
        """Load tasks from JSON file"""
        with open(filepath, 'r') as f:
            self.tasks = json.load(f)
    
    def get_task_statistics(self) -> Dict[str, Any]:
        """Get statistics about the task collection"""
        
        stats = {
            'total_tasks': len(self.get_all_tasks()),
            'categories': list(self.tasks.keys()),
            'tasks_per_category': {
                category: len(tasks) 
                for category, tasks in self.tasks.items()
            },
            'difficulty_distribution': {}
        }
        
        # Count difficulty distribution
        difficulty_counts = {'easy': 0, 'medium': 0, 'hard': 0}
        for task in self.get_all_tasks():
            difficulty = task.get('difficulty', 'unknown')
            if difficulty in difficulty_counts:
                difficulty_counts[difficulty] += 1
        
        stats['difficulty_distribution'] = difficulty_counts
        
        return stats