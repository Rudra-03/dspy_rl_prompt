"""Main application for RL-LLM Instruction Optimizer"""
import asyncio
import os
import sys
from typing import Dict, Any, List, Optional
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn
from loguru import logger
import numpy as np

# Add project root to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from utils.config import SystemConfig, load_config
from environment.rl_environment import LLMOptimizationEnvironment
from models.rl_agent import RLAgent
from experiments.benchmark_tasks import BenchmarkTasks

# Configure logging
logger.add("logs/rl_llm_optimizer.log", rotation="1 day", retention="7 days")

# FastAPI app
app = FastAPI(
    title="RL-LLM Instruction Optimizer",
    description="Model-Agnostic Reinforcement Learning for LLM Instruction Optimization",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global state
system_config: Optional[SystemConfig] = None
environment: Optional[LLMOptimizationEnvironment] = None
rl_agent: Optional[RLAgent] = None
benchmark_tasks: Optional[BenchmarkTasks] = None

# Pydantic models for API
class TaskRequest(BaseModel):
    name: str
    type: str
    description: str
    context: Optional[str] = ""
    expected_output: Optional[str] = None
    tools: Optional[List[Dict[str, Any]]] = None

class TrainingRequest(BaseModel):
    total_timesteps: int = 10000
    evaluation_tasks: Optional[List[str]] = None
    save_model: bool = True

class EvaluationRequest(BaseModel):
    task_categories: Optional[List[str]] = None
    difficulties: Optional[List[str]] = None
    num_episodes_per_task: int = 3

class OptimizationRequest(BaseModel):
    base_task: str
    context: Optional[str] = ""
    task_type: str = "general"

# Startup and shutdown events
@app.on_event("startup")
async def startup_event():
    """Initialize system components"""
    global system_config, environment, rl_agent, benchmark_tasks
    
    try:
        logger.info("Starting RL-LLM Instruction Optimizer...")
        
        # Load configuration
        system_config = load_config()
        logger.info("Configuration loaded")
        
        # Initialize environment
        environment = LLMOptimizationEnvironment(system_config)
        logger.info("Environment initialized")
        
        # Initialize RL agent
        rl_agent = RLAgent(system_config.rl_config, environment)
        logger.info("RL agent initialized")
        
        # Initialize benchmark tasks
        benchmark_tasks = BenchmarkTasks()
        logger.info("Benchmark tasks loaded")
        
        # Health check
        health_status = await environment.health_check()
        logger.info(f"System health check: {health_status}")
        
        logger.info("System startup completed successfully")
        
    except Exception as e:
        logger.error(f"Startup failed: {str(e)}")
        raise

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup system resources"""
    global environment, rl_agent
    
    logger.info("Shutting down RL-LLM Instruction Optimizer...")
    
    if environment:
        environment.close()
    
    logger.info("Shutdown completed")

# API endpoints
@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "RL-LLM Instruction Optimizer API",
        "version": "1.0.0",
        "status": "running"
    }

@app.get("/health")
async def health_check():
    """System health check"""
    if not environment:
        raise HTTPException(status_code=503, detail="System not initialized")
    
    health_status = await environment.health_check()
    
    return {
        "status": "healthy" if all(health_status.values()) else "unhealthy",
        "components": health_status,
        "timestamp": asyncio.get_event_loop().time()
    }

@app.get("/config")
async def get_config():
    """Get system configuration"""
    if not system_config:
        raise HTTPException(status_code=503, detail="System not initialized")
    
    return system_config.dict()

@app.post("/tasks/custom")
async def create_custom_task(task: TaskRequest):
    """Create a custom task"""
    if not benchmark_tasks:
        raise HTTPException(status_code=503, detail="System not initialized")
    
    custom_task = benchmark_tasks.create_custom_task(
        name=task.name,
        task_type=task.type,
        description=task.description,
        context=task.context,
        expected_output=task.expected_output,
        tools=task.tools
    )
    
    return {"message": "Custom task created", "task": custom_task}

@app.get("/tasks/benchmark")
async def get_benchmark_tasks(category: Optional[str] = None, difficulty: Optional[str] = None):
    """Get benchmark tasks"""
    if not benchmark_tasks:
        raise HTTPException(status_code=503, detail="System not initialized")
    
    if category:
        tasks = benchmark_tasks.get_tasks_by_category(category)
    elif difficulty:
        tasks = benchmark_tasks.get_tasks_by_difficulty(difficulty)
    else:
        tasks = benchmark_tasks.get_all_tasks()
    
    return {
        "tasks": tasks,
        "count": len(tasks),
        "statistics": benchmark_tasks.get_task_statistics()
    }

@app.post("/optimize")
async def optimize_instruction(request: OptimizationRequest):
    """Optimize instruction using trained RL agent"""
    if not rl_agent or not environment:
        raise HTTPException(status_code=503, detail="System not initialized")
    
    try:
        # Create task from request
        task = {
            'name': 'custom_optimization',
            'type': request.task_type,
            'description': request.base_task,
            'context': request.context
        }
        
        # Reset environment with task
        obs, info = await environment.reset(task)
        
        # Get optimized action from RL agent
        action, _ = rl_agent.predict_action(obs, deterministic=True)
        
        # Execute step to get optimized instruction
        new_obs, reward, terminated, truncated, step_info = await environment.step(action)
        
        return {
            "optimized_instruction": step_info['instruction'],
            "base_instruction": request.base_task,
            "response": step_info['response'],
            "reward": reward,
            "action_summary": step_info['action_summary'],
            "reward_breakdown": step_info['reward_breakdown'],
            "success": step_info['task_success']
        }
        
    except Exception as e:
        logger.error(f"Optimization failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Optimization failed: {str(e)}")

@app.post("/train")
async def train_agent(request: TrainingRequest, background_tasks: BackgroundTasks):
    """Train RL agent"""
    if not rl_agent or not benchmark_tasks:
        raise HTTPException(status_code=503, detail="System not initialized")
    
    # Get evaluation tasks if specified
    evaluation_tasks = None
    if request.evaluation_tasks:
        evaluation_tasks = []
        for task_name in request.evaluation_tasks:
            # Find task by name in benchmark tasks
            all_tasks = benchmark_tasks.get_all_tasks()
            task = next((t for t in all_tasks if t['name'] == task_name), None)
            if task:
                evaluation_tasks.append(task)
    
    # Start training in background
    background_tasks.add_task(
        _train_agent_background,
        request.total_timesteps,
        evaluation_tasks,
        request.save_model
    )
    
    return {
        "message": "Training started",
        "total_timesteps": request.total_timesteps,
        "evaluation_tasks": len(evaluation_tasks) if evaluation_tasks else 0
    }

async def _train_agent_background(total_timesteps: int, 
                                evaluation_tasks: Optional[List[Dict[str, Any]]],
                                save_model: bool):
    """Background training task"""
    try:
        logger.info(f"Starting background training for {total_timesteps} timesteps")
        
        await rl_agent.train(total_timesteps, evaluation_tasks)
        
        if save_model:
            model_path = f"./models/rl_agent_{int(asyncio.get_event_loop().time())}"
            rl_agent.save_model(model_path)
            logger.info(f"Model saved to {model_path}")
        
        logger.info("Background training completed")
        
    except Exception as e:
        logger.error(f"Background training failed: {str(e)}")

@app.post("/evaluate")
async def evaluate_agent(request: EvaluationRequest):
    """Evaluate RL agent performance"""
    if not rl_agent or not benchmark_tasks:
        raise HTTPException(status_code=503, detail="System not initialized")
    
    try:
        # Get evaluation tasks
        evaluation_tasks = benchmark_tasks.get_evaluation_suite(
            categories=request.task_categories,
            difficulties=request.difficulties,
            max_tasks_per_category=3
        )
        
        # Run evaluation
        results = await rl_agent.evaluate(evaluation_tasks, request.num_episodes_per_task)
        
        return {
            "evaluation_results": results,
            "tasks_evaluated": len(evaluation_tasks),
            "total_episodes": results['overall_stats']['total_episodes']
        }
        
    except Exception as e:
        logger.error(f"Evaluation failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Evaluation failed: {str(e)}")

@app.get("/stats/training")
async def get_training_stats():
    """Get training statistics"""
    if not rl_agent:
        raise HTTPException(status_code=503, detail="System not initialized")
    
    return rl_agent.get_training_stats()

@app.get("/stats/environment")
async def get_environment_stats():
    """Get environment performance statistics"""
    if not environment:
        raise HTTPException(status_code=503, detail="System not initialized")
    
    return environment.get_performance_summary()

@app.post("/models/save")
async def save_model(path: str = "models/current_model"):
    """Save current model"""
    if not rl_agent:
        raise HTTPException(status_code=503, detail="System not initialized")
    
    try:
        rl_agent.save_model(path)
        return {"message": f"Model saved to {path}"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save model: {str(e)}")

@app.post("/models/load")
async def load_model(path: str):
    """Load model from path"""
    if not rl_agent:
        raise HTTPException(status_code=503, detail="System not initialized")
    
    try:
        rl_agent.load_model(path)
        return {"message": f"Model loaded from {path}"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to load model: {str(e)}")

@app.get("/demo")
async def demo_optimization():
    """Demo endpoint showing the optimization process"""
    if not rl_agent or not environment or not benchmark_tasks:
        raise HTTPException(status_code=503, detail="System not initialized")
    
    try:
        # Get a sample task
        sample_tasks = benchmark_tasks.get_tasks_by_difficulty('medium')
        if not sample_tasks:
            raise HTTPException(status_code=404, detail="No sample tasks available")
        
        demo_task = sample_tasks[0]
        
        # Reset environment
        obs, info = await environment.reset(demo_task)
        
        # Get baseline response (random action)
        random_action = rl_agent.action_decoder.sample_random_action()
        baseline_obs, baseline_reward, _, _, baseline_info = await environment.step(random_action)
        
        # Reset for optimized response
        obs, info = await environment.reset(demo_task)
        
        # Get optimized response
        optimized_action, _ = rl_agent.predict_action(obs, deterministic=True)
        optimized_obs, optimized_reward, _, _, optimized_info = await environment.step(optimized_action)
        
        return {
            "task": demo_task,
            "baseline": {
                "instruction": baseline_info['instruction'],
                "response": baseline_info['response'],
                "reward": baseline_reward,
                "action_summary": baseline_info['action_summary']
            },
            "optimized": {
                "instruction": optimized_info['instruction'],
                "response": optimized_info['response'],
                "reward": optimized_reward,
                "action_summary": optimized_info['action_summary']
            },
            "improvement": optimized_reward - baseline_reward
        }
        
    except Exception as e:
        logger.error(f"Demo failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Demo failed: {str(e)}")

# Main execution
if __name__ == "__main__":
    # Create necessary directories
    os.makedirs("logs", exist_ok=True)
    os.makedirs("models", exist_ok=True)
    os.makedirs("tensorboard_logs", exist_ok=True)
    
    # Run the application
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )