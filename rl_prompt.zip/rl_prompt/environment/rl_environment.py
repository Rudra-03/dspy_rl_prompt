"""RL Environment for LLM instruction optimization"""
import gymnasium as gym
import numpy as np
from typing import Dict, Any, List, Optional, Tuple
import asyncio
from loguru import logger
import time
import json

from ..utils.state_encoder import StateEncoder
from ..utils.action_decoder import ActionDecoder
from ..models.instructor_llm import InstructorLLM
from ..models.responder_llm import ResponderLLM
from .reward_calculator import RewardCalculator
from ..utils.config import SystemConfig

class LLMOptimizationEnvironment(gym.Env):
    """RL Environment for optimizing LLM instructions"""
    
    def __init__(self, config: SystemConfig):
        super().__init__()
        
        self.config = config
        
        # Initialize components
        self.state_encoder = StateEncoder(
            history_length=config.env_config.state_history_length
        )
        self.action_decoder = ActionDecoder(
            action_dim=config.env_config.action_space_size
        )
        self.reward_calculator = RewardCalculator()
        
        # Initialize LLMs
        self.instructor_llm = InstructorLLM(config.instructor_llm)
        self.responder_llm = ResponderLLM(config.responder_llm)
        
        # Define action and observation spaces
        self.action_space = gym.spaces.Box(
            low=-1.0, 
            high=1.0, 
            shape=(config.env_config.action_space_size,),
            dtype=np.float32
        )
        
        self.observation_space = gym.spaces.Box(
            low=-np.inf,
            high=np.inf,
            shape=(self.state_encoder.get_state_dimension(),),
            dtype=np.float32
        )
        
        # Environment state
        self.current_task = None
        self.episode_step = 0
        self.max_episode_steps = config.env_config.max_episode_length
        self.episode_history = []
        self.total_episodes = 0
        
        # Performance tracking
        self.performance_history = []
        
    async def reset(self, task: Optional[Dict[str, Any]] = None) -> Tuple[np.ndarray, Dict[str, Any]]:
        """Reset environment for new episode"""
        
        self.episode_step = 0
        self.episode_history = []
        self.state_encoder.reset()
        
        # Set task for this episode
        if task:
            self.current_task = task
        else:
            self.current_task = self._get_default_task()
        
        # Get initial state (empty history)
        initial_state = self.state_encoder.get_current_state()
        
        info = {
            'episode': self.total_episodes,
            'task': self.current_task,
            'step': self.episode_step
        }
        
        logger.info(f"Episode {self.total_episodes} reset with task: {self.current_task['name']}")
        
        return initial_state, info
    
    async def step(self, action: np.ndarray) -> Tuple[np.ndarray, float, bool, bool, Dict[str, Any]]:
        """Execute one step in the environment"""
        
        step_start_time = time.time()
        
        try:
            # Decode action
            decoded_action = self.action_decoder.decode_action(action)
            
            # Generate optimized instruction using instructor LLM
            instruction_result = await self.instructor_llm.generate_optimized_instruction(
                base_task=self.current_task['description'],
                rl_action=action,
                context=self.current_task.get('context'),
                task_type=self.current_task.get('type', 'general')
            )
            
            # Process instruction using responder LLM
            response_result = await self.responder_llm.process_instruction(
                instruction=instruction_result['instruction'],
                task_context=self.current_task.get('context_dict'),
                tools=self.current_task.get('tools')
            )
            
            # Calculate reward
            reward_result = self.reward_calculator.calculate_reward(
                instruction=instruction_result['instruction'],
                response=response_result['response'],
                task_definition=self.current_task['description'],
                execution_metadata={
                    **response_result['metadata'],
                    'instruction_execution_time': instruction_result['execution_time'],
                    'response_execution_time': response_result['execution_time'],
                    'total_execution_time': time.time() - step_start_time,
                    'decoded_action': decoded_action,
                    'success': response_result['success']
                },
                ground_truth=self.current_task.get('expected_output')
            )
            
            reward = reward_result['total_reward']
            
            # Update state encoder with new experience
            self.state_encoder.update_history(
                instruction=instruction_result['instruction'],
                outcome=response_result['response'],
                reward=reward,
                metadata=reward_result['metadata']
            )
            
            # Get new state
            new_state = self.state_encoder.get_current_state()
            
            # Update episode tracking
            self.episode_step += 1
            step_info = {
                'instruction': instruction_result['instruction'],
                'response': response_result['response'],
                'reward': reward,
                'decoded_action': decoded_action,
                'reward_components': reward_result['components'],
                'execution_time': time.time() - step_start_time
            }
            self.episode_history.append(step_info)
            
            # Check if episode is done
            terminated = self._check_termination(reward, response_result)
            truncated = self.episode_step >= self.max_episode_steps
            done = terminated or truncated
            
            # Prepare info dict
            info = {
                'step': self.episode_step,
                'reward_breakdown': reward_result,
                'instruction_metadata': instruction_result,
                'response_metadata': response_result,
                'action_summary': self.action_decoder.action_to_string(decoded_action),
                'terminated': terminated,
                'truncated': truncated,
                'task_success': reward > self.config.env_config.reward_threshold
            }
            
            # Log step information
            logger.info(
                f"Step {self.episode_step}: Reward={reward:.3f}, "
                f"Success={info['task_success']}, "
                f"Time={info['instruction_metadata']['execution_time'] + info['response_metadata']['execution_time']:.2f}s"
            )
            
            # If episode is done, finalize
            if done:
                await self._finalize_episode()
            
            return new_state, reward, terminated, truncated, info
            
        except Exception as e:
            logger.error(f"Error in environment step: {str(e)}")
            
            # Return error state
            error_state = self.state_encoder.get_current_state()
            error_reward = -0.5  # Penalty for errors
            
            info = {
                'error': str(e),
                'step': self.episode_step,
                'terminated': True,
                'truncated': False,
                'task_success': False
            }
            
            return error_state, error_reward, True, False, info
    
    def _check_termination(self, reward: float, response_result: Dict[str, Any]) -> bool:
        """Check if episode should terminate early"""
        
        # Terminate if task is successfully completed
        if reward > self.config.env_config.reward_threshold:
            return True
        
        # Terminate if there's a critical error
        if not response_result['success']:
            return True
        
        # Terminate if reward is consistently very low
        if len(self.episode_history) >= 3:
            recent_rewards = [step['reward'] for step in self.episode_history[-3:]]
            if all(r < 0.2 for r in recent_rewards):
                return True
        
        return False
    
    async def _finalize_episode(self):
        """Finalize episode and update performance tracking"""
        
        self.total_episodes += 1
        
        # Calculate episode statistics
        episode_rewards = [step['reward'] for step in self.episode_history]
        episode_stats = {
            'episode': self.total_episodes,
            'steps': self.episode_step,
            'total_reward': sum(episode_rewards),
            'avg_reward': np.mean(episode_rewards) if episode_rewards else 0,
            'max_reward': max(episode_rewards) if episode_rewards else 0,
            'min_reward': min(episode_rewards) if episode_rewards else 0,
            'success': max(episode_rewards) > self.config.env_config.reward_threshold if episode_rewards else False,
            'task_type': self.current_task.get('type', 'general'),
            'total_execution_time': sum(step['execution_time'] for step in self.episode_history)
        }
        
        self.performance_history.append(episode_stats)
        
        # Update reward calculator baselines
        recent_metadata = [step.get('metadata', {}) for step in self.episode_history[-10:]]
        self.reward_calculator.update_baselines(recent_metadata)
        
        logger.info(
            f"Episode {self.total_episodes} completed: "
            f"Steps={episode_stats['steps']}, "
            f"Avg Reward={episode_stats['avg_reward']:.3f}, "
            f"Success={episode_stats['success']}"
        )
    
    def _get_default_task(self) -> Dict[str, Any]:
        """Get default task for testing"""
        
        return {
            'name': 'general_qa',
            'type': 'question_answering',
            'description': 'Answer the following question accurately and comprehensively: What are the key principles of machine learning?',
            'context': 'This is a general knowledge question about machine learning fundamentals.',
            'expected_output': None,  # No ground truth for open-ended questions
            'tools': None
        }
    
    def get_performance_summary(self) -> Dict[str, Any]:
        """Get performance summary across all episodes"""
        
        if not self.performance_history:
            return {}
        
        recent_episodes = self.performance_history[-50:]  # Last 50 episodes
        
        summary = {
            'total_episodes': self.total_episodes,
            'recent_success_rate': np.mean([ep['success'] for ep in recent_episodes]),
            'recent_avg_reward': np.mean([ep['avg_reward'] for ep in recent_episodes]),
            'recent_avg_steps': np.mean([ep['steps'] for ep in recent_episodes]),
            'best_episode_reward': max([ep['max_reward'] for ep in self.performance_history]),
            'instructor_llm_stats': self.instructor_llm.get_performance_stats(),
            'responder_llm_stats': self.responder_llm.get_performance_stats()
        }
        
        return summary
    
    def set_task(self, task: Dict[str, Any]):
        """Set current task for the environment"""
        self.current_task = task
    
    def get_current_task(self) -> Dict[str, Any]:
        """Get current task"""
        return self.current_task
    
    async def health_check(self) -> Dict[str, bool]:
        """Check health of all components"""
        
        health_status = {
            'instructor_llm': await self.instructor_llm.health_check(),
            'responder_llm': await self.responder_llm.health_check(),
            'environment': True  # Environment is always healthy if this method runs
        }
        
        return health_status
    
    def render(self, mode='human'):
        """Render environment state (for debugging)"""
        
        if mode == 'human':
            print(f"Episode: {self.total_episodes}, Step: {self.episode_step}")
            if self.current_task:
                print(f"Current Task: {self.current_task['name']}")
            if self.episode_history:
                last_step = self.episode_history[-1]
                print(f"Last Reward: {last_step['reward']:.3f}")
                print(f"Last Action: {last_step['decoded_action']}")
        
        return None
    
    def close(self):
        """Clean up environment resources"""
        # Clean up any resources if needed
        pass