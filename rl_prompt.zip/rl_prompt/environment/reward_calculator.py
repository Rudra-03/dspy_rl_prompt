"""Reward calculation for RL environment"""
import numpy as np
from typing import Dict, Any, List, Optional
import re
import json
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
import time

class RewardCalculator:
    """Calculates rewards for instruction-outcome pairs"""
    
    def __init__(self):
        self.sentence_model = SentenceTransformer('all-MiniLM-L6-v2')
        
        # Reward components weights
        self.weights = {
            'task_completion': 0.4,
            'response_quality': 0.3,
            'efficiency': 0.15,
            'instruction_clarity': 0.15
        }
        
        # Performance baselines for normalization
        self.baselines = {
            'avg_response_length': 200,
            'avg_execution_time': 2.0,
            'avg_token_count': 500
        }
    
    def calculate_reward(self, 
                        instruction: str,
                        response: str,
                        task_definition: str,
                        execution_metadata: Dict[str, Any],
                        ground_truth: Optional[str] = None) -> Dict[str, Any]:
        """Calculate comprehensive reward for instruction-response pair"""
        
        reward_components = {}
        
        # 1. Task Completion Score
        task_completion = self._calculate_task_completion(
            response, task_definition, ground_truth
        )
        reward_components['task_completion'] = task_completion
        
        # 2. Response Quality Score
        response_quality = self._calculate_response_quality(
            response, instruction, execution_metadata
        )
        reward_components['response_quality'] = response_quality
        
        # 3. Efficiency Score
        efficiency = self._calculate_efficiency(execution_metadata)
        reward_components['efficiency'] = efficiency
        
        # 4. Instruction Clarity Score
        instruction_clarity = self._calculate_instruction_clarity(
            instruction, response, execution_metadata
        )
        reward_components['instruction_clarity'] = instruction_clarity
        
        # Calculate weighted total reward
        total_reward = sum(
            self.weights[component] * score 
            for component, score in reward_components.items()
        )
        
        # Apply bonus/penalty modifiers
        modifiers = self._calculate_modifiers(
            instruction, response, execution_metadata
        )
        
        final_reward = np.clip(total_reward + modifiers['total'], 0.0, 1.0)
        
        return {
            'total_reward': final_reward,
            'components': reward_components,
            'modifiers': modifiers,
            'weights': self.weights,
            'metadata': {
                'calculation_time': time.time(),
                'response_length': len(response),
                'instruction_length': len(instruction)
            }
        }
    
    def _calculate_task_completion(self, response: str, task_definition: str, 
                                 ground_truth: Optional[str] = None) -> float:
        """Calculate how well the task was completed"""
        
        if ground_truth:
            # If ground truth is available, use semantic similarity
            response_emb = self.sentence_model.encode([response])
            truth_emb = self.sentence_model.encode([ground_truth])
            similarity = cosine_similarity(response_emb, truth_emb)[0][0]
            return float(np.clip(similarity, 0, 1))
        
        # Otherwise, use heuristic scoring
        task_keywords = self._extract_task_keywords(task_definition)
        response_lower = response.lower()
        
        # Check keyword coverage
        keyword_coverage = sum(
            1 for keyword in task_keywords 
            if keyword.lower() in response_lower
        ) / max(len(task_keywords), 1)
        
        # Check response completeness
        completeness_indicators = [
            len(response) > 50,  # Minimum response length
            '.' in response,     # Has sentences
            not response.strip().endswith('...'),  # Not truncated
            'error' not in response_lower,  # No errors
            'sorry' not in response_lower   # Not apologetic
        ]
        
        completeness_score = sum(completeness_indicators) / len(completeness_indicators)
        
        # Combine scores
        task_completion = 0.6 * keyword_coverage + 0.4 * completeness_score
        
        return float(np.clip(task_completion, 0, 1))
    
    def _calculate_response_quality(self, response: str, instruction: str,
                                  metadata: Dict[str, Any]) -> float:
        """Calculate response quality score"""
        
        quality_factors = []
        
        # 1. Length appropriateness
        response_length = len(response)
        if 50 <= response_length <= 2000:
            length_score = 1.0
        elif response_length < 50:
            length_score = response_length / 50
        else:
            length_score = max(0.5, 2000 / response_length)
        
        quality_factors.append(length_score)
        
        # 2. Structure and formatting
        structure_indicators = [
            '\n' in response,  # Has line breaks
            any(marker in response for marker in ['1.', '2.', '-', '*']),  # Has lists
            response.count('.') >= 2,  # Multiple sentences
            response.count(',') >= 1   # Has commas
        ]
        structure_score = sum(structure_indicators) / len(structure_indicators)
        quality_factors.append(structure_score)
        
        # 3. Relevance to instruction
        instruction_emb = self.sentence_model.encode([instruction])
        response_emb = self.sentence_model.encode([response])
        relevance = cosine_similarity(instruction_emb, response_emb)[0][0]
        quality_factors.append(float(np.clip(relevance, 0, 1)))
        
        # 4. Error indicators (negative scoring)
        error_indicators = [
            'error' in response.lower(),
            'failed' in response.lower(),
            'cannot' in response.lower(),
            'unable' in response.lower()
        ]
        error_penalty = sum(error_indicators) * 0.2
        
        # 5. Success indicators from metadata
        success_bonus = 0.0
        if metadata.get('success', True):
            success_bonus = 0.2
        
        quality_score = np.mean(quality_factors) + success_bonus - error_penalty
        
        return float(np.clip(quality_score, 0, 1))
    
    def _calculate_efficiency(self, metadata: Dict[str, Any]) -> float:
        """Calculate efficiency score based on execution metadata"""
        
        efficiency_factors = []
        
        # 1. Execution time efficiency
        execution_time = metadata.get('execution_time', self.baselines['avg_execution_time'])
        time_efficiency = min(1.0, self.baselines['avg_execution_time'] / max(execution_time, 0.1))
        efficiency_factors.append(time_efficiency)
        
        # 2. Token efficiency
        token_count = metadata.get('token_count', self.baselines['avg_token_count'])
        token_efficiency = min(1.0, self.baselines['avg_token_count'] / max(token_count, 1))
        efficiency_factors.append(token_efficiency)
        
        # 3. API call efficiency
        api_calls = metadata.get('api_calls', 1)
        call_efficiency = min(1.0, 2.0 / max(api_calls, 1))  # Prefer fewer calls
        efficiency_factors.append(call_efficiency)
        
        # 4. Tool usage efficiency
        tool_calls = len(metadata.get('tool_calls', []))
        if tool_calls > 0:
            # Bonus for successful tool usage
            tool_success = metadata.get('tool_success_rate', 0.5)
            tool_efficiency = tool_success
        else:
            # Neutral if no tools needed
            tool_efficiency = 0.7
        
        efficiency_factors.append(tool_efficiency)
        
        return float(np.mean(efficiency_factors))
    
    def _calculate_instruction_clarity(self, instruction: str, response: str,
                                     metadata: Dict[str, Any]) -> float:
        """Calculate how clear and effective the instruction was"""
        
        clarity_factors = []
        
        # 1. Instruction length appropriateness
        instruction_length = len(instruction)
        if 100 <= instruction_length <= 1000:
            length_score = 1.0
        elif instruction_length < 100:
            length_score = instruction_length / 100
        else:
            length_score = max(0.3, 1000 / instruction_length)
        
        clarity_factors.append(length_score)
        
        # 2. Instruction specificity
        specificity_indicators = [
            any(word in instruction.lower() for word in ['specific', 'exactly', 'precisely']),
            any(word in instruction.lower() for word in ['step', 'process', 'method']),
            any(word in instruction.lower() for word in ['format', 'structure', 'organize']),
            '?' in instruction,  # Has questions
            ':' in instruction   # Has colons (structure)
        ]
        specificity_score = sum(specificity_indicators) / len(specificity_indicators)
        clarity_factors.append(specificity_score)
        
        # 3. Response alignment with instruction
        # Check if response follows instruction format/structure
        alignment_score = 0.5  # Default neutral
        
        if 'json' in instruction.lower():
            try:
                json.loads(response)
                alignment_score = 1.0
            except:
                alignment_score = 0.2
        elif 'list' in instruction.lower() or 'bullet' in instruction.lower():
            if any(marker in response for marker in ['-', '*', '1.', '2.']):
                alignment_score = 1.0
            else:
                alignment_score = 0.3
        elif 'step' in instruction.lower():
            if any(word in response.lower() for word in ['first', 'second', 'then', 'next', 'finally']):
                alignment_score = 1.0
            else:
                alignment_score = 0.4
        
        clarity_factors.append(alignment_score)
        
        # 4. Instruction complexity appropriateness
        complexity_words = len([w for w in instruction.split() if len(w) > 6])
        total_words = len(instruction.split())
        complexity_ratio = complexity_words / max(total_words, 1)
        
        # Moderate complexity is good (0.2-0.4)
        if 0.2 <= complexity_ratio <= 0.4:
            complexity_score = 1.0
        else:
            complexity_score = max(0.3, 1.0 - abs(complexity_ratio - 0.3) * 2)
        
        clarity_factors.append(complexity_score)
        
        return float(np.mean(clarity_factors))
    
    def _calculate_modifiers(self, instruction: str, response: str,
                           metadata: Dict[str, Any]) -> Dict[str, float]:
        """Calculate bonus/penalty modifiers"""
        
        modifiers = {}
        
        # Creativity bonus
        creativity_indicators = [
            'creative' in instruction.lower(),
            'innovative' in response.lower(),
            'novel' in response.lower(),
            len(set(response.lower().split())) / max(len(response.split()), 1) > 0.7  # Vocabulary diversity
        ]
        modifiers['creativity_bonus'] = sum(creativity_indicators) * 0.05
        
        # Error penalty
        error_count = sum([
            'error' in response.lower(),
            'failed' in response.lower(),
            metadata.get('success', True) == False
        ])
        modifiers['error_penalty'] = -error_count * 0.1
        
        # Tool usage bonus
        if metadata.get('tool_calls'):
            tool_success_rate = metadata.get('tool_success_rate', 0.5)
            modifiers['tool_bonus'] = tool_success_rate * 0.1
        else:
            modifiers['tool_bonus'] = 0.0
        
        # Speed bonus
        execution_time = metadata.get('execution_time', 5.0)
        if execution_time < 1.0:
            modifiers['speed_bonus'] = 0.05
        else:
            modifiers['speed_bonus'] = 0.0
        
        # Calculate total modifier
        modifiers['total'] = sum(modifiers.values())
        
        return modifiers
    
    def _extract_task_keywords(self, task_definition: str) -> List[str]:
        """Extract key task-related words"""
        
        # Remove common stop words and extract meaningful terms
        stop_words = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by'}
        
        words = re.findall(r'\b\w+\b', task_definition.lower())
        keywords = [word for word in words if len(word) > 3 and word not in stop_words]
        
        return keywords[:10]  # Top 10 keywords
    
    def update_baselines(self, recent_metadata: List[Dict[str, Any]]):
        """Update performance baselines based on recent data"""
        
        if not recent_metadata:
            return
        
        # Update execution time baseline
        execution_times = [m.get('execution_time', 0) for m in recent_metadata if m.get('execution_time')]
        if execution_times:
            self.baselines['avg_execution_time'] = np.mean(execution_times)
        
        # Update token count baseline
        token_counts = [m.get('token_count', 0) for m in recent_metadata if m.get('token_count')]
        if token_counts:
            self.baselines['avg_token_count'] = np.mean(token_counts)
        
        # Update response length baseline
        response_lengths = [m.get('response_length', 0) for m in recent_metadata if m.get('response_length')]
        if response_lengths:
            self.baselines['avg_response_length'] = np.mean(response_lengths)
    
    def get_reward_explanation(self, reward_result: Dict[str, Any]) -> str:
        """Generate human-readable explanation of reward calculation"""
        
        explanation_parts = [
            f"Total Reward: {reward_result['total_reward']:.3f}",
            "",
            "Component Breakdown:"
        ]
        
        for component, score in reward_result['components'].items():
            weight = self.weights[component]
            contribution = weight * score
            explanation_parts.append(
                f"  {component.replace('_', ' ').title()}: {score:.3f} "
                f"(weight: {weight:.2f}, contribution: {contribution:.3f})"
            )
        
        if reward_result['modifiers']['total'] != 0:
            explanation_parts.extend([
                "",
                "Modifiers:"
            ])
            for modifier, value in reward_result['modifiers'].items():
                if modifier != 'total' and value != 0:
                    explanation_parts.append(f"  {modifier.replace('_', ' ').title()}: {value:+.3f}")
        
        return "\n".join(explanation_parts)