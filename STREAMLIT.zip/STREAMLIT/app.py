import streamlit as st
from openai import AzureOpenAI

# ==============================
# Config
# ==============================
st.set_page_config(page_title="Agent", page_icon="🤖", layout="centered")

# Initialize Azure client
client = AzureOpenAI(
    api_key=st.secrets["OPENAI_API_KEY"],
    azure_endpoint=st.secrets["AZURE_ENDPOINT"],
    api_version=st.secrets["API_VERSION"]
)

# ==============================
# Sidebar Controls
# ==============================
st.sidebar.title("⚙️ Settings")

# System prompt setting
system_prompt = st.sidebar.text_area(
    "System Prompt:",
    value="You are a helpful AI assistant.",
    height=100
)

# Clear chat button
if st.sidebar.button("🗑️ Clear Chat"):
    st.session_state.messages = [
        {"role": "system", "content": system_prompt},
        {"role": "assistant", "content": "Chat cleared. How can I help you?"}
    ]

# ==============================
# Initialize Session State
# ==============================
if "messages" not in st.session_state:
    st.session_state.messages = [
        {"role": "system", "content": system_prompt},
        {"role": "assistant", "content": "Hello! How can I help you today?"}
    ]

# ==============================
# Display Messages
# ==============================
for msg in st.session_state.messages:
    if msg["role"] != "system":  # don’t show system prompt in chat
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

# ==============================
# Chat Input
# ==============================
if prompt := st.chat_input("Type your message..."):
    # Store user input
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    # Assistant response
    with st.chat_message("assistant"):
        response_placeholder = st.empty()
        full_response = ""

        stream = client.chat.completions.create(
            model="gpt-4o",   # Or your Azure deployment name
            messages=st.session_state.messages,
            stream=True,
        )

        for event in stream:
            if event.choices[0].delta.content is not None:
                full_response += event.choices[0].delta.content
                response_placeholder.markdown(full_response + "▌")

        response_placeholder.markdown(full_response)

    # Store assistant response
    st.session_state.messages.append({"role": "assistant", "content": full_response})
